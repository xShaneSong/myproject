﻿import Poderosa.Macro;
var env = new Environment();

env.Util.MessageBox("Hello World!\nYou can automate various operations by using Poderosa Macro feature.\nSince the macro is executed on .NET Framework, you can utilize many features including file I/O, regular expressions, and database access. \nIf you are interested in macro, please see several samples located in 'macro/sample' subdirectory.");
