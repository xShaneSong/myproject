﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PrintService.Domain.Interfaces;
using PrintService.Domain.Entities;

using System.Diagnostics;

namespace PrintService.Domain.Context
{
    public class ProductRespository : IProductRepository
    {
        private ProductDbContext context = new ProductDbContext();
        
        public IEnumerable<Product> Products
        {
            get { return context.Products; }
        }

        public Product FindProductById(string id)
        {
            return context.Products.Find(id);
        }
    }
}
