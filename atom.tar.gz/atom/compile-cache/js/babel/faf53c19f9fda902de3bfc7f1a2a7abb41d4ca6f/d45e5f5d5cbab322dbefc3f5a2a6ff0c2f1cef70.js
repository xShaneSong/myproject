Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _atom = require('atom');

var _check = require('./check');

var _executor = require('./executor');

var _pathhelper = require('./pathhelper');

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _os = require('os');

var _os2 = _interopRequireDefault(_os);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

'use babel';

var Locator = (function () {
  function Locator(options) {
    var _this = this;

    _classCallCheck(this, Locator);

    this.subscriptions = new _atom.CompositeDisposable();
    this.environmentFn = null;
    this.executor = null;
    this.executableSuffix = '';
    this.pathKey = 'PATH';
    if (_os2['default'].platform() === 'win32') {
      this.executableSuffix = '.exe';
      this.pathKey = 'Path';
    }
    this.goExecutables = ['go' + this.executableSuffix, 'goapp' + this.executableSuffix];
    this.pathhelper = new _pathhelper.PathHelper();
    this.readyFn = null;
    if ((0, _check.isTruthy)(options)) {
      if ((0, _check.isTruthy)(options.environment)) {
        this.environmentFn = options.environment;
      }
      if ((0, _check.isTruthy)(options.ready)) {
        this.readyFn = options.ready;
      }
      if ((0, _check.isTruthy)(options.executor)) {
        this.executor = options.executor;
      }
    }

    if (this.executor === null) {
      this.executor = new _executor.Executor({ environmentFn: this.environment.bind(this) });
    }

    this.subscriptions.add(this.executor);
    this.goLocators = [
    // Avoid using gorootLocator / GOROOT unless you know what you're doing
    // (and assume you don't know what you're unless you have significant
    // go experience)
    function () {
      return _this.gorootLocator();
    }, function () {
      return _this.editorconfigLocator();
    }, function () {
      return _this.configLocator();
    }, function () {
      return _this.pathLocator();
    }, function () {
      return _this.defaultLocator();
    }];

    this.setKnownToolStrategies();
    this.setKnownToolLocations();
  }

  _createClass(Locator, [{
    key: 'dispose',
    value: function dispose() {
      this.resetRuntimes();
      if (this.subscriptions) {
        this.subscriptions.dispose();
      }
      this.goLocators = null;
      this.executableSuffix = null;
      this.pathKey = null;
      this.goExecutables = null;
      this.subscriptions = null;
      this.environmentFn = null;
      this.executor = null;
      this.readyFn = null;
      this.toolLocations = null;
      this.toolStrategies = null;
    }

    // Public
  }, {
    key: 'runtimes',
    value: function runtimes(project, options) {
      var _this2 = this;

      if ((0, _check.isTruthy)(this.runtimesCache)) {
        return Promise.resolve(this.runtimesCache);
      }

      return new Promise(function (resolve, reject) {
        var candidates = _this2.runtimeCandidates(project);
        if ((0, _check.isFalsy)(candidates) || candidates.constructor !== Array || candidates.length < 1) {
          return resolve([]);
        }

        var viableCandidates = [];
        for (var candidate of candidates) {
          var goversion = _this2.executor.execSync(candidate, ['version'], { cwd: _path2['default'].dirname(candidate) });
          if ((0, _check.isTruthy)(goversion) && goversion.code === 0 && goversion.stdout.startsWith('go ')) {
            var v = { path: candidate, version: goversion.stdout.replace(/\r?\n|\r/g, '') };
            var versionComponents = v.version.split(' ');
            v.name = versionComponents[2];
            v.semver = versionComponents[2];
            if (v.semver.startsWith('go')) {
              v.semver = v.semver.substring(2, v.semver.length);
            }
            viableCandidates.push(v);
          }
        }

        var finalCandidates = [];
        for (var viableCandidate of viableCandidates) {
          var goenv = _this2.executor.execSync(viableCandidate.path, ['env'], { cwd: _path2['default'].dirname(viableCandidate.path) });
          if ((0, _check.isTruthy)(goenv) && goenv.code === 0 && goenv.stdout.trim() !== '') {
            var items = goenv.stdout.split('\n');
            for (var item of items) {
              item = item.replace(/[\n\r]/g, '');
              if (item.includes('=')) {
                var tuple = item.split('=');
                var key = tuple[0];
                var value = tuple[1];
                if (tuple.length > 2) {
                  value = tuple.slice(1, tuple.length + 1).join('=');
                }
                if (_os2['default'].platform() === 'win32') {
                  if (key.startsWith('set ')) {
                    key = key.substring(4, key.length);
                  }
                } else {
                  if (value.length > 2) {
                    value = value.substring(1, value.length - 1);
                  } else {
                    value = '';
                  }
                }
                viableCandidate[key] = value;
              }
            }
            finalCandidates.push(viableCandidate);
          }
        }

        _this2.runtimesCache = finalCandidates;
        resolve(_this2.runtimesCache);
      });
    }
  }, {
    key: 'resetRuntimes',
    value: function resetRuntimes() {
      this.runtimesCache = null;
    }
  }, {
    key: 'statishSync',
    value: function statishSync(pathValue) {
      var stat = false;
      if ((0, _check.isTruthy)(pathValue) && !(pathValue.trim() === '')) {
        try {
          stat = _fs2['default'].statSync(pathValue);
        } catch (e) {}
      }
      return stat;
    }
  }, {
    key: 'stat',
    value: function stat(p) {
      var _this3 = this;

      if ((0, _check.isFalsy)(p) || p.constructor !== String || p.trim() === '') {
        return Promise.resolve(false);
      }

      return new Promise(function (resolve, reject) {
        _fs2['default'].stat(p, function (err, stat) {
          if ((0, _check.isTruthy)(err)) {
            _this3.handleError(err);
            resolve(false);
            return;
          }
          resolve(stat);
        });
      });
    }
  }, {
    key: 'pathExists',
    value: function pathExists(p) {
      return this.exists(p).then(function (e) {
        if ((0, _check.isFalsy)(e)) {
          return false;
        }
        return p;
      });
    }
  }, {
    key: 'fileExists',
    value: function fileExists(p) {
      return this.stat(p).then(function (s) {
        if ((0, _check.isFalsy)(s)) {
          return false;
        }

        if (s.isFile()) {
          return p;
        }

        return false;
      });
    }
  }, {
    key: 'directoryExists',
    value: function directoryExists(p) {
      return this.stat(p).then(function (s) {
        if ((0, _check.isFalsy)(s)) {
          return false;
        }

        if (s.isDirectory()) {
          return p;
        }

        return false;
      });
    }
  }, {
    key: 'exists',
    value: function exists(p) {
      return this.stat(p).then(function (s) {
        if ((0, _check.isFalsy)(s)) {
          return false;
        }

        return true;
      });
    }
  }, {
    key: 'runtimeCandidates',
    value: function runtimeCandidates(project) {
      var candidates = [];
      for (var locator of this.goLocators) {
        var c = locator(project);
        if ((0, _check.isTruthy)(c) && c.constructor === Array && c.length > 0) {
          candidates = _lodash2['default'].union(candidates, c);
        }
      }
      return candidates;
    }
  }, {
    key: 'editorconfigLocator',
    value: function editorconfigLocator(project) {
      // TODO: .editorconfig
      return false;
    }
  }, {
    key: 'configLocator',
    value: function configLocator(project) {
      var goinstallation = atom.config.get('go-plus.goInstallation');
      var stat = this.statishSync(goinstallation);
      if ((0, _check.isTruthy)(stat)) {
        var d = goinstallation;
        if (stat.isFile()) {
          d = _path2['default'].dirname(goinstallation);
        }
        return this.findExecutablesInPath(d, this.executables);
      }

      return [];
    }
  }, {
    key: 'gorootLocator',
    value: function gorootLocator() {
      if ((0, _check.isFalsy)(this.environment().GOROOT) || this.environment().GOROOT.trim() === '') {
        return [];
      }
      return this.findExecutablesInPath(_path2['default'].join(this.environment().GOROOT, 'bin'), this.goExecutables);
    }
  }, {
    key: 'pathLocator',
    value: function pathLocator() {
      return this.findExecutablesInPath(this.environment()[this.pathKey], this.goExecutables);
    }
  }, {
    key: 'defaultLocator',
    value: function defaultLocator() {
      var installPaths = [];
      if (_os2['default'].platform() === 'win32') {
        /*
        c:\go\bin = Binary Distribution
        c:\tools\go\bin = Chocolatey
        */
        installPaths.push(_path2['default'].join('c:', 'go', 'bin'));
        installPaths.push(_path2['default'].join('c:', 'tools', 'go', 'bin'));
      } else {
        /*
        /usr/local/go/bin = Binary Distribution
        /usr/local/bin = Homebrew
        */
        installPaths.push(_path2['default'].join('/', 'usr', 'local', 'go', 'bin'));
        installPaths.push(_path2['default'].join('/', 'usr', 'local', 'bin'));
      }
      return this.findExecutablesInPath(installPaths.join(_path2['default'].delimiter), this.goExecutables);
    }
  }, {
    key: 'findExecutablesInPath',
    value: function findExecutablesInPath(pathValue, executables) {
      var candidates = [];
      if ((0, _check.isFalsy)(pathValue) || pathValue.constructor !== String || pathValue.trim() === '') {
        return candidates;
      }

      if ((0, _check.isFalsy)(executables) || executables.constructor !== Array || executables.length < 1) {
        return candidates;
      }

      var elements = this.pathhelper.expand(this.environment(), pathValue).split(_path2['default'].delimiter);
      for (var element of elements) {
        for (var executable of executables) {
          var candidate = _path2['default'].join(element, executable);
          var stat = this.statishSync(candidate);
          if ((0, _check.isTruthy)(stat) && stat.isFile()) {
            candidates.push(candidate);
          }
        }
      }
      return candidates;
    }

    // Public
  }, {
    key: 'gopath',
    value: function gopath(options) {
      var e = this.environment();
      if ((0, _check.isFalsy)(e.GOPATH) || e.GOPATH.trim() === '') {
        return false;
      }

      return this.pathhelper.expand(e, e.GOPATH);
    }
  }, {
    key: 'environment',
    value: function environment() {
      if ((0, _check.isFalsy)(this.environmentFn)) {
        return process.env;
      }

      var e = this.environmentFn();
      if ((0, _check.isFalsy)(e)) {
        return process.env;
      }
      return e;
    }
  }, {
    key: 'ready',
    value: function ready() {
      if ((0, _check.isFalsy)(this.readyFn)) {
        return true;
      }
      return this.readyFn();
    }
  }, {
    key: 'setKnownToolLocations',
    value: function setKnownToolLocations() {
      this.toolLocations = new Map();
      this.toolLocations.set('goimports', 'golang.org/x/tools/cmd/goimports');
      this.toolLocations.set('goreturns', 'sourcegraph.com/sqs/goreturns');
      this.toolLocations.set('gometalinter', 'github.com/alecthomas/gometalinter');
      this.toolLocations.set('godebug', 'github.com/mailgun/godebug');
      this.toolLocations.set('oracle', 'golang.org/x/tools/cmd/oracle');
      this.toolLocations.set('gocode', 'github.com/nsf/gocode');
    }
  }, {
    key: 'setKnownToolStrategies',
    value: function setKnownToolStrategies() {
      this.toolStrategies = new Map();

      // Built-In Tools
      this.toolStrategies.set('go', 'GOROOTBIN');
      this.toolStrategies.set('gofmt', 'GOROOTBIN');
      this.toolStrategies.set('godoc', 'GOROOTBIN');
      this.toolStrategies.set('addr2line', 'GOTOOLDIR');
      this.toolStrategies.set('api', 'GOTOOLDIR');
      this.toolStrategies.set('asm', 'GOTOOLDIR');
      this.toolStrategies.set('cgo', 'GOTOOLDIR');
      this.toolStrategies.set('compile', 'GOTOOLDIR');
      this.toolStrategies.set('cover', 'GOTOOLDIR');
      this.toolStrategies.set('dist', 'GOTOOLDIR');
      this.toolStrategies.set('doc', 'GOTOOLDIR');
      this.toolStrategies.set('fix', 'GOTOOLDIR');
      this.toolStrategies.set('link', 'GOTOOLDIR');
      this.toolStrategies.set('nm', 'GOTOOLDIR');
      this.toolStrategies.set('objdump', 'GOTOOLDIR');
      this.toolStrategies.set('pack', 'GOTOOLDIR');
      this.toolStrategies.set('pprof', 'GOTOOLDIR');
      this.toolStrategies.set('tour', 'GOTOOLDIR');
      this.toolStrategies.set('trace', 'GOTOOLDIR');
      this.toolStrategies.set('vet', 'GOTOOLDIR');
      this.toolStrategies.set('yacc', 'GOTOOLDIR');

      // External Tools
      this.toolStrategies.set('git', 'PATH');

      // Other Tools Are Assumed To Be In PATH or GOBIN or GOPATH/bin
      // GOPATHBIN Can Be Used In The Future As A Strategy, If Required
      // GOPATHBIN Will Understand GO15VENDOREXPERIMENT
    }

    // Public
  }, {
    key: 'runtimeForProject',
    value: function runtimeForProject(project) {
      if ((0, _check.isTruthy)(project) && project.constructor === String || name.trim() !== '') {
        // Do something specific for the project
      }

      return this.runtimes(project).then(function (r) {
        if ((0, _check.isFalsy)(r) || r.length < 1) {
          return false;
        } else {
          return r[0];
        }
      });
    }

    // Public
  }, {
    key: 'findTool',
    value: function findTool(name, project, options) {
      var _this4 = this;

      if ((0, _check.isFalsy)(name) || name.constructor !== String || name.trim() === '') {
        return Promise.resolve(false);
      }

      var strategy = false;
      return Promise.resolve(null).then(function () {
        if ((0, _check.isTruthy)(project)) {
          // Do something here
        }
        if (_this4.toolStrategies.has(name)) {
          strategy = _this4.toolStrategies.get(name);
        }
        if ((0, _check.isFalsy)(strategy)) {
          strategy = 'DEFAULT';
        }
      }).then(function () {
        if (strategy !== 'GOROOTBIN' && strategy !== 'GOTOOLDIR') {
          return false;
        }

        return _this4.runtimeForProject(project).then(function (runtime) {
          if ((0, _check.isFalsy)(runtime)) {
            return false;
          }

          if (strategy === 'GOROOTBIN') {
            return _path2['default'].join(runtime.GOROOT, 'bin', name + runtime.GOEXE);
          } else if (strategy === 'GOTOOLDIR') {
            return _path2['default'].join(runtime.GOTOOLDIR, name + runtime.GOEXE);
          }
          return false;
        });
      }).then(function (specificTool) {
        if ((0, _check.isTruthy)(specificTool)) {
          return _this4.stat(specificTool).then(function (s) {
            if ((0, _check.isTruthy)(s) && s.isFile()) {
              return specificTool;
            }
          })['catch'](function (err) {
            _this4.handleError(err);
            return false;
          });
        }

        if (strategy === 'GOPATHBIN') {
          return _this4.findToolInDelimitedEnvironmentVariable(name, 'GOPATH', project);
        }

        if (strategy === 'PATH') {
          return _this4.findToolInDelimitedEnvironmentVariable(name, _this4.pathKey, project);
        }

        return _this4.findToolWithDefaultStrategy(name, project);
      });
    }
  }, {
    key: 'handleError',
    value: function handleError(err) {
      if ((0, _check.isTruthy)(err.handle)) {
        err.handle();
      }
      // console.log(err)
    }
  }, {
    key: 'handleAndReject',
    value: function handleAndReject(err, reject) {
      this.handleError(err);
      reject(err);
    }
  }, {
    key: 'findToolWithDefaultStrategy',
    value: function findToolWithDefaultStrategy(name, project, options) {
      var _this5 = this;

      if ((0, _check.isFalsy)(name) || name.constructor !== String || name.trim() === '') {
        return Promise.resolve(false);
      }

      // Default Strategy Is: Look For The Tool In GOPATH, Then Look In PATH
      return Promise.resolve().then(function () {
        return _this5.findToolInDelimitedEnvironmentVariable(name, 'GOPATH', project);
      }).then(function (tool) {
        if ((0, _check.isTruthy)(tool)) {
          return tool;
        }
        return _this5.findToolInDelimitedEnvironmentVariable(name, _this5.pathKey, project);
      });
    }
  }, {
    key: 'findToolInDelimitedEnvironmentVariable',
    value: function findToolInDelimitedEnvironmentVariable(toolName, key, project) {
      var _this6 = this;

      if ((0, _check.isFalsy)(toolName) || toolName.constructor !== String || toolName.trim() === '') {
        return Promise.resolve(false);
      }

      var p = this.environment()[key];
      if ((0, _check.isFalsy)(p)) {
        return Promise.resolve(false);
      }

      return Promise.resolve(false).then(function () {
        var elements = p.split(_path2['default'].delimiter);
        if (key === 'GOPATH' && (0, _check.isTruthy)(_this6.environment()['GO15VENDOREXPERIMENT'])) {
          // TODO: Understand Vendor Experiment Paths Better
          // elements.unshift('vendor')
        }
        for (var element of elements) {
          var item = '';
          if (key === 'GOPATH') {
            item = _path2['default'].join(element, 'bin', toolName + _this6.executableSuffix);
          } else {
            item = _path2['default'].join(element, toolName + _this6.executableSuffix);
          }

          if (_fs2['default'].existsSync(item) && _fs2['default'].statSync(item).isFile()) {
            return item;
          }
        }

        return false;
      });
    }
  }, {
    key: 'getTool',
    value: function getTool(name, project, options) {
      return new Promise(function (resolve, reject) {
        resolve(false);
      });
    }

    // Public
  }, {
    key: 'promptForTool',
    value: function promptForTool(name, project, options) {
      return false;
    }
  }]);

  return Locator;
})();

exports.Locator = Locator;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL3NoYW5lLy5hdG9tL3BhY2thZ2VzL2dvLWNvbmZpZy9saWIvbG9jYXRvci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O29CQUVrQyxNQUFNOztxQkFDUixTQUFTOzt3QkFDbEIsWUFBWTs7MEJBQ1YsY0FBYzs7c0JBQ3pCLFFBQVE7Ozs7a0JBQ1AsSUFBSTs7OztrQkFDSixJQUFJOzs7O29CQUNGLE1BQU07Ozs7QUFUdkIsV0FBVyxDQUFBOztJQVdMLE9BQU87QUFDQyxXQURSLE9BQU8sQ0FDRSxPQUFPLEVBQUU7OzswQkFEbEIsT0FBTzs7QUFFVCxRQUFJLENBQUMsYUFBYSxHQUFHLCtCQUF5QixDQUFBO0FBQzlDLFFBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFBO0FBQ3pCLFFBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFBO0FBQ3BCLFFBQUksQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLENBQUE7QUFDMUIsUUFBSSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUE7QUFDckIsUUFBSSxnQkFBRyxRQUFRLEVBQUUsS0FBSyxPQUFPLEVBQUU7QUFDN0IsVUFBSSxDQUFDLGdCQUFnQixHQUFHLE1BQU0sQ0FBQTtBQUM5QixVQUFJLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQTtLQUN0QjtBQUNELFFBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLE9BQU8sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtBQUNwRixRQUFJLENBQUMsVUFBVSxHQUFHLDRCQUFnQixDQUFBO0FBQ2xDLFFBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFBO0FBQ25CLFFBQUkscUJBQVMsT0FBTyxDQUFDLEVBQUU7QUFDckIsVUFBSSxxQkFBUyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7QUFDakMsWUFBSSxDQUFDLGFBQWEsR0FBRyxPQUFPLENBQUMsV0FBVyxDQUFBO09BQ3pDO0FBQ0QsVUFBSSxxQkFBUyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7QUFDM0IsWUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFBO09BQzdCO0FBQ0QsVUFBSSxxQkFBUyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUU7QUFDOUIsWUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFBO09BQ2pDO0tBQ0Y7O0FBRUQsUUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLElBQUksRUFBRTtBQUMxQixVQUFJLENBQUMsUUFBUSxHQUFHLHVCQUFhLEVBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsQ0FBQTtLQUMzRTs7QUFFRCxRQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDckMsUUFBSSxDQUFDLFVBQVUsR0FBRzs7OztBQUloQixnQkFBTTtBQUFFLGFBQU8sTUFBSyxhQUFhLEVBQUUsQ0FBQTtLQUFFLEVBQ3JDLFlBQU07QUFBRSxhQUFPLE1BQUssbUJBQW1CLEVBQUUsQ0FBQTtLQUFFLEVBQzNDLFlBQU07QUFBRSxhQUFPLE1BQUssYUFBYSxFQUFFLENBQUE7S0FBRSxFQUNyQyxZQUFNO0FBQUUsYUFBTyxNQUFLLFdBQVcsRUFBRSxDQUFBO0tBQUUsRUFDbkMsWUFBTTtBQUFFLGFBQU8sTUFBSyxjQUFjLEVBQUUsQ0FBQTtLQUFFLENBQ3ZDLENBQUE7O0FBRUQsUUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUE7QUFDN0IsUUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUE7R0FDN0I7O2VBNUNHLE9BQU87O1dBOENILG1CQUFHO0FBQ1QsVUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFBO0FBQ3BCLFVBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtBQUN0QixZQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxDQUFBO09BQzdCO0FBQ0QsVUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUE7QUFDdEIsVUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQTtBQUM1QixVQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQTtBQUNuQixVQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQTtBQUN6QixVQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQTtBQUN6QixVQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQTtBQUN6QixVQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQTtBQUNwQixVQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQTtBQUNuQixVQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQTtBQUN6QixVQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQTtLQUMzQjs7Ozs7V0FHUSxrQkFBQyxPQUFPLEVBQUUsT0FBTyxFQUFFOzs7QUFDMUIsVUFBSSxxQkFBUyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUU7QUFDaEMsZUFBTyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQTtPQUMzQzs7QUFFRCxhQUFPLElBQUksT0FBTyxDQUFDLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBSztBQUN0QyxZQUFJLFVBQVUsR0FBRyxPQUFLLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFBO0FBQ2hELFlBQUksb0JBQVEsVUFBVSxDQUFDLElBQUksVUFBVSxDQUFDLFdBQVcsS0FBSyxLQUFLLElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7QUFDcEYsaUJBQU8sT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFBO1NBQ25COztBQUVELFlBQUksZ0JBQWdCLEdBQUcsRUFBRSxDQUFBO0FBQ3pCLGFBQUssSUFBSSxTQUFTLElBQUksVUFBVSxFQUFFO0FBQ2hDLGNBQUksU0FBUyxHQUFHLE9BQUssUUFBUSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxTQUFTLENBQUMsRUFBRSxFQUFDLEdBQUcsRUFBRSxrQkFBSyxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUMsQ0FBQyxDQUFBO0FBQzlGLGNBQUkscUJBQVMsU0FBUyxDQUFDLElBQUksU0FBUyxDQUFDLElBQUksS0FBSyxDQUFDLElBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLEVBQUU7QUFDckYsZ0JBQUksQ0FBQyxHQUFHLEVBQUMsSUFBSSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQyxFQUFDLENBQUE7QUFDN0UsZ0JBQUksaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDNUMsYUFBQyxDQUFDLElBQUksR0FBRyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUM3QixhQUFDLENBQUMsTUFBTSxHQUFHLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFBO0FBQy9CLGdCQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQzdCLGVBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUE7YUFDbEQ7QUFDRCw0QkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7V0FDekI7U0FDRjs7QUFFRCxZQUFJLGVBQWUsR0FBRyxFQUFFLENBQUE7QUFDeEIsYUFBSyxJQUFJLGVBQWUsSUFBSSxnQkFBZ0IsRUFBRTtBQUM1QyxjQUFJLEtBQUssR0FBRyxPQUFLLFFBQVEsQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUMsR0FBRyxFQUFFLGtCQUFLLE9BQU8sQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxDQUFBO0FBQzVHLGNBQUkscUJBQVMsS0FBSyxDQUFDLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUU7QUFDckUsZ0JBQUksS0FBSyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ3BDLGlCQUFLLElBQUksSUFBSSxJQUFJLEtBQUssRUFBRTtBQUN0QixrQkFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFBO0FBQ2xDLGtCQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7QUFDdEIsb0JBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDM0Isb0JBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUNsQixvQkFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBQ3BCLG9CQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO0FBQ3BCLHVCQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7aUJBQ25EO0FBQ0Qsb0JBQUksZ0JBQUcsUUFBUSxFQUFFLEtBQUssT0FBTyxFQUFFO0FBQzdCLHNCQUFJLEdBQUcsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEVBQUU7QUFDMUIsdUJBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUE7bUJBQ25DO2lCQUNGLE1BQU07QUFDTCxzQkFBSSxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtBQUNwQix5QkFBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUE7bUJBQzdDLE1BQU07QUFDTCx5QkFBSyxHQUFHLEVBQUUsQ0FBQTttQkFDWDtpQkFDRjtBQUNELCtCQUFlLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFBO2VBQzdCO2FBQ0Y7QUFDRCwyQkFBZSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQTtXQUN0QztTQUNGOztBQUVELGVBQUssYUFBYSxHQUFHLGVBQWUsQ0FBQTtBQUNwQyxlQUFPLENBQUMsT0FBSyxhQUFhLENBQUMsQ0FBQTtPQUM1QixDQUFDLENBQUE7S0FDSDs7O1dBRWEseUJBQUc7QUFDZixVQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQTtLQUMxQjs7O1dBRVcscUJBQUMsU0FBUyxFQUFFO0FBQ3RCLFVBQUksSUFBSSxHQUFHLEtBQUssQ0FBQTtBQUNoQixVQUFJLHFCQUFTLFNBQVMsQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQSxBQUFDLEVBQUU7QUFDckQsWUFBSTtBQUFFLGNBQUksR0FBRyxnQkFBRyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUE7U0FBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUc7T0FDcEQ7QUFDRCxhQUFPLElBQUksQ0FBQTtLQUNaOzs7V0FFSSxjQUFDLENBQUMsRUFBRTs7O0FBQ1AsVUFBSSxvQkFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxLQUFLLE1BQU0sSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFO0FBQzdELGVBQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQTtPQUM5Qjs7QUFFRCxhQUFPLElBQUksT0FBTyxDQUFDLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBSztBQUN0Qyx3QkFBRyxJQUFJLENBQUMsQ0FBQyxFQUFFLFVBQUMsR0FBRyxFQUFFLElBQUksRUFBSztBQUN4QixjQUFJLHFCQUFTLEdBQUcsQ0FBQyxFQUFFO0FBQ2pCLG1CQUFLLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUNyQixtQkFBTyxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQ2QsbUJBQU07V0FDUDtBQUNELGlCQUFPLENBQUMsSUFBSSxDQUFDLENBQUE7U0FDZCxDQUFDLENBQUE7T0FDSCxDQUFDLENBQUE7S0FDSDs7O1dBRVUsb0JBQUMsQ0FBQyxFQUFFO0FBQ2IsYUFBTyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFDLENBQUMsRUFBSztBQUNoQyxZQUFJLG9CQUFRLENBQUMsQ0FBQyxFQUFFO0FBQ2QsaUJBQU8sS0FBSyxDQUFBO1NBQ2I7QUFDRCxlQUFPLENBQUMsQ0FBQTtPQUNULENBQUMsQ0FBQTtLQUNIOzs7V0FFVSxvQkFBQyxDQUFDLEVBQUU7QUFDYixhQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQzlCLFlBQUksb0JBQVEsQ0FBQyxDQUFDLEVBQUU7QUFDZCxpQkFBTyxLQUFLLENBQUE7U0FDYjs7QUFFRCxZQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRTtBQUNkLGlCQUFPLENBQUMsQ0FBQTtTQUNUOztBQUVELGVBQU8sS0FBSyxDQUFBO09BQ2IsQ0FBQyxDQUFBO0tBQ0g7OztXQUVlLHlCQUFDLENBQUMsRUFBRTtBQUNsQixhQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQzlCLFlBQUksb0JBQVEsQ0FBQyxDQUFDLEVBQUU7QUFDZCxpQkFBTyxLQUFLLENBQUE7U0FDYjs7QUFFRCxZQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsRUFBRTtBQUNuQixpQkFBTyxDQUFDLENBQUE7U0FDVDs7QUFFRCxlQUFPLEtBQUssQ0FBQTtPQUNiLENBQUMsQ0FBQTtLQUNIOzs7V0FFTSxnQkFBQyxDQUFDLEVBQUU7QUFDVCxhQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQzlCLFlBQUksb0JBQVEsQ0FBQyxDQUFDLEVBQUU7QUFDZCxpQkFBTyxLQUFLLENBQUE7U0FDYjs7QUFFRCxlQUFPLElBQUksQ0FBQTtPQUNaLENBQUMsQ0FBQTtLQUNIOzs7V0FFaUIsMkJBQUMsT0FBTyxFQUFFO0FBQzFCLFVBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQTtBQUNuQixXQUFLLElBQUksT0FBTyxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7QUFDbkMsWUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFBO0FBQ3hCLFlBQUkscUJBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7QUFDMUQsb0JBQVUsR0FBRyxvQkFBRSxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFBO1NBQ3BDO09BQ0Y7QUFDRCxhQUFPLFVBQVUsQ0FBQTtLQUNsQjs7O1dBRW1CLDZCQUFDLE9BQU8sRUFBRTs7QUFFNUIsYUFBTyxLQUFLLENBQUE7S0FDYjs7O1dBRWEsdUJBQUMsT0FBTyxFQUFFO0FBQ3RCLFVBQUksY0FBYyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUE7QUFDOUQsVUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsQ0FBQTtBQUMzQyxVQUFJLHFCQUFTLElBQUksQ0FBQyxFQUFFO0FBQ2xCLFlBQUksQ0FBQyxHQUFHLGNBQWMsQ0FBQTtBQUN0QixZQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRTtBQUNqQixXQUFDLEdBQUcsa0JBQUssT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFBO1NBQ2pDO0FBQ0QsZUFBTyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQTtPQUN2RDs7QUFFRCxhQUFPLEVBQUUsQ0FBQTtLQUNWOzs7V0FFYSx5QkFBRztBQUNmLFVBQUksb0JBQVEsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFO0FBQ2pGLGVBQU8sRUFBRSxDQUFBO09BQ1Y7QUFDRCxhQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxrQkFBSyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUE7S0FDbkc7OztXQUVXLHVCQUFHO0FBQ2IsYUFBTyxJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUE7S0FDeEY7OztXQUVjLDBCQUFHO0FBQ2hCLFVBQUksWUFBWSxHQUFHLEVBQUUsQ0FBQTtBQUNyQixVQUFJLGdCQUFHLFFBQVEsRUFBRSxLQUFLLE9BQU8sRUFBRTs7Ozs7QUFLN0Isb0JBQVksQ0FBQyxJQUFJLENBQUMsa0JBQUssSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQTtBQUMvQyxvQkFBWSxDQUFDLElBQUksQ0FBQyxrQkFBSyxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQTtPQUN6RCxNQUFNOzs7OztBQUtMLG9CQUFZLENBQUMsSUFBSSxDQUFDLGtCQUFLLElBQUksQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQTtBQUM5RCxvQkFBWSxDQUFDLElBQUksQ0FBQyxrQkFBSyxJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQTtPQUN6RDtBQUNELGFBQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsa0JBQUssU0FBUyxDQUFDLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFBO0tBQ3pGOzs7V0FFcUIsK0JBQUMsU0FBUyxFQUFFLFdBQVcsRUFBRTtBQUM3QyxVQUFJLFVBQVUsR0FBRyxFQUFFLENBQUE7QUFDbkIsVUFBSSxvQkFBUSxTQUFTLENBQUMsSUFBSSxTQUFTLENBQUMsV0FBVyxLQUFLLE1BQU0sSUFBSSxTQUFTLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFO0FBQ3JGLGVBQU8sVUFBVSxDQUFBO09BQ2xCOztBQUVELFVBQUksb0JBQVEsV0FBVyxDQUFDLElBQUksV0FBVyxDQUFDLFdBQVcsS0FBSyxLQUFLLElBQUksV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7QUFDdkYsZUFBTyxVQUFVLENBQUE7T0FDbEI7O0FBRUQsVUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxFQUFFLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxrQkFBSyxTQUFTLENBQUMsQ0FBQTtBQUMxRixXQUFLLElBQUksT0FBTyxJQUFJLFFBQVEsRUFBRTtBQUM1QixhQUFLLElBQUksVUFBVSxJQUFJLFdBQVcsRUFBRTtBQUNsQyxjQUFJLFNBQVMsR0FBRyxrQkFBSyxJQUFJLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxDQUFBO0FBQzlDLGNBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUE7QUFDdEMsY0FBSSxxQkFBUyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUU7QUFDbkMsc0JBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUE7V0FDM0I7U0FDRjtPQUNGO0FBQ0QsYUFBTyxVQUFVLENBQUE7S0FDbEI7Ozs7O1dBR00sZ0JBQUMsT0FBTyxFQUFFO0FBQ2YsVUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFBO0FBQzFCLFVBQUksb0JBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFO0FBQy9DLGVBQU8sS0FBSyxDQUFBO09BQ2I7O0FBRUQsYUFBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0tBQzNDOzs7V0FFVyx1QkFBRztBQUNiLFVBQUksb0JBQVEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFO0FBQy9CLGVBQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQTtPQUNuQjs7QUFFRCxVQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUE7QUFDNUIsVUFBSSxvQkFBUSxDQUFDLENBQUMsRUFBRTtBQUNkLGVBQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQTtPQUNuQjtBQUNELGFBQU8sQ0FBQyxDQUFBO0tBQ1Q7OztXQUVLLGlCQUFHO0FBQ1AsVUFBSSxvQkFBUSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUU7QUFDekIsZUFBTyxJQUFJLENBQUE7T0FDWjtBQUNELGFBQU8sSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFBO0tBQ3RCOzs7V0FFcUIsaUNBQUc7QUFDdkIsVUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFBO0FBQzlCLFVBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxrQ0FBa0MsQ0FBQyxDQUFBO0FBQ3ZFLFVBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSwrQkFBK0IsQ0FBQyxDQUFBO0FBQ3BFLFVBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLGNBQWMsRUFBRSxvQ0FBb0MsQ0FBQyxDQUFBO0FBQzVFLFVBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSw0QkFBNEIsQ0FBQyxDQUFBO0FBQy9ELFVBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSwrQkFBK0IsQ0FBQyxDQUFBO0FBQ2pFLFVBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSx1QkFBdUIsQ0FBQyxDQUFBO0tBQzFEOzs7V0FFc0Isa0NBQUc7QUFDeEIsVUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFBOzs7QUFHL0IsVUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFBO0FBQzFDLFVBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQTtBQUM3QyxVQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUE7QUFDN0MsVUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLFdBQVcsQ0FBQyxDQUFBO0FBQ2pELFVBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQTtBQUMzQyxVQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUE7QUFDM0MsVUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFBO0FBQzNDLFVBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQTtBQUMvQyxVQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUE7QUFDN0MsVUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFBO0FBQzVDLFVBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQTtBQUMzQyxVQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUE7QUFDM0MsVUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFBO0FBQzVDLFVBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQTtBQUMxQyxVQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUE7QUFDL0MsVUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFBO0FBQzVDLFVBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQTtBQUM3QyxVQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUE7QUFDNUMsVUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFBO0FBQzdDLFVBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQTtBQUMzQyxVQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUE7OztBQUc1QyxVQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUE7Ozs7O0tBS3ZDOzs7OztXQUdpQiwyQkFBQyxPQUFPLEVBQUU7QUFDMUIsVUFBSSxxQkFBUyxPQUFPLENBQUMsSUFBSSxPQUFPLENBQUMsV0FBVyxLQUFLLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFOztPQUU5RTs7QUFFRCxhQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQ3hDLFlBQUksb0JBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7QUFDOUIsaUJBQU8sS0FBSyxDQUFBO1NBQ2IsTUFBTTtBQUNMLGlCQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtTQUNaO09BQ0YsQ0FBQyxDQUFBO0tBQ0g7Ozs7O1dBR1Esa0JBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUU7OztBQUNoQyxVQUFJLG9CQUFRLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUU7QUFDdEUsZUFBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFBO09BQzlCOztBQUVELFVBQUksUUFBUSxHQUFHLEtBQUssQ0FBQTtBQUNwQixhQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQU07QUFDdEMsWUFBSSxxQkFBUyxPQUFPLENBQUMsRUFBRTs7U0FFdEI7QUFDRCxZQUFJLE9BQUssY0FBYyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNqQyxrQkFBUSxHQUFHLE9BQUssY0FBYyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQTtTQUN6QztBQUNELFlBQUksb0JBQVEsUUFBUSxDQUFDLEVBQUU7QUFDckIsa0JBQVEsR0FBRyxTQUFTLENBQUE7U0FDckI7T0FDRixDQUFDLENBQUMsSUFBSSxDQUFDLFlBQU07QUFDWixZQUFJLFFBQVEsS0FBSyxXQUFXLElBQUksUUFBUSxLQUFLLFdBQVcsRUFBRTtBQUN4RCxpQkFBTyxLQUFLLENBQUE7U0FDYjs7QUFFRCxlQUFPLE9BQUssaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsT0FBTyxFQUFLO0FBQ3ZELGNBQUksb0JBQVEsT0FBTyxDQUFDLEVBQUU7QUFDcEIsbUJBQU8sS0FBSyxDQUFBO1dBQ2I7O0FBRUQsY0FBSSxRQUFRLEtBQUssV0FBVyxFQUFFO0FBQzVCLG1CQUFPLGtCQUFLLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxJQUFJLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFBO1dBQzlELE1BQU0sSUFBSSxRQUFRLEtBQUssV0FBVyxFQUFFO0FBQ25DLG1CQUFPLGtCQUFLLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLElBQUksR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUE7V0FDMUQ7QUFDRCxpQkFBTyxLQUFLLENBQUE7U0FDYixDQUFDLENBQUE7T0FDSCxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsWUFBWSxFQUFLO0FBQ3hCLFlBQUkscUJBQVMsWUFBWSxDQUFDLEVBQUU7QUFDMUIsaUJBQU8sT0FBSyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQ3pDLGdCQUFJLHFCQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRTtBQUM3QixxQkFBTyxZQUFZLENBQUE7YUFDcEI7V0FDRixDQUFDLFNBQU0sQ0FBQyxVQUFDLEdBQUcsRUFBSztBQUNoQixtQkFBSyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDckIsbUJBQU8sS0FBSyxDQUFBO1dBQ2IsQ0FBQyxDQUFBO1NBQ0g7O0FBRUQsWUFBSSxRQUFRLEtBQUssV0FBVyxFQUFFO0FBQzVCLGlCQUFPLE9BQUssc0NBQXNDLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQTtTQUM1RTs7QUFFRCxZQUFJLFFBQVEsS0FBSyxNQUFNLEVBQUU7QUFDdkIsaUJBQU8sT0FBSyxzQ0FBc0MsQ0FBQyxJQUFJLEVBQUUsT0FBSyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUE7U0FDaEY7O0FBRUQsZUFBTyxPQUFLLDJCQUEyQixDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQTtPQUN2RCxDQUFDLENBQUE7S0FDSDs7O1dBRVcscUJBQUMsR0FBRyxFQUFFO0FBQ2hCLFVBQUkscUJBQVMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQ3hCLFdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQTtPQUNiOztLQUVGOzs7V0FFZSx5QkFBQyxHQUFHLEVBQUUsTUFBTSxFQUFFO0FBQzVCLFVBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDckIsWUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0tBQ1o7OztXQUUyQixxQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRTs7O0FBQ25ELFVBQUksb0JBQVEsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRTtBQUN0RSxlQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUE7T0FDOUI7OztBQUdELGFBQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFNO0FBQ2xDLGVBQU8sT0FBSyxzQ0FBc0MsQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFBO09BQzVFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxJQUFJLEVBQUs7QUFDaEIsWUFBSSxxQkFBUyxJQUFJLENBQUMsRUFBRTtBQUNsQixpQkFBTyxJQUFJLENBQUE7U0FDWjtBQUNELGVBQU8sT0FBSyxzQ0FBc0MsQ0FBQyxJQUFJLEVBQUUsT0FBSyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUE7T0FDaEYsQ0FBQyxDQUFBO0tBQ0g7OztXQUVzQyxnREFBQyxRQUFRLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRTs7O0FBQzlELFVBQUksb0JBQVEsUUFBUSxDQUFDLElBQUksUUFBUSxDQUFDLFdBQVcsS0FBSyxNQUFNLElBQUksUUFBUSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRTtBQUNsRixlQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUE7T0FDOUI7O0FBRUQsVUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQy9CLFVBQUksb0JBQVEsQ0FBQyxDQUFDLEVBQUU7QUFDZCxlQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUE7T0FDOUI7O0FBRUQsYUFBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFNO0FBQ3ZDLFlBQUksUUFBUSxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsa0JBQUssU0FBUyxDQUFDLENBQUE7QUFDdEMsWUFBSSxHQUFHLEtBQUssUUFBUSxJQUFJLHFCQUFTLE9BQUssV0FBVyxFQUFFLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxFQUFFOzs7U0FHN0U7QUFDRCxhQUFLLElBQUksT0FBTyxJQUFJLFFBQVEsRUFBRTtBQUM1QixjQUFJLElBQUksR0FBRyxFQUFFLENBQUE7QUFDYixjQUFJLEdBQUcsS0FBSyxRQUFRLEVBQUU7QUFDcEIsZ0JBQUksR0FBRyxrQkFBSyxJQUFJLENBQUMsT0FBTyxFQUFFLEtBQUssRUFBRSxRQUFRLEdBQUcsT0FBSyxnQkFBZ0IsQ0FBQyxDQUFBO1dBQ25FLE1BQU07QUFDTCxnQkFBSSxHQUFHLGtCQUFLLElBQUksQ0FBQyxPQUFPLEVBQUUsUUFBUSxHQUFHLE9BQUssZ0JBQWdCLENBQUMsQ0FBQTtXQUM1RDs7QUFFRCxjQUFJLGdCQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxnQkFBRyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUU7QUFDckQsbUJBQU8sSUFBSSxDQUFBO1dBQ1o7U0FDRjs7QUFFRCxlQUFPLEtBQUssQ0FBQTtPQUNiLENBQUMsQ0FBQTtLQUNIOzs7V0FFTyxpQkFBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRTtBQUMvQixhQUFPLElBQUksT0FBTyxDQUFDLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBSztBQUN0QyxlQUFPLENBQUMsS0FBSyxDQUFDLENBQUE7T0FDZixDQUFDLENBQUE7S0FDSDs7Ozs7V0FHYSx1QkFBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRTtBQUNyQyxhQUFPLEtBQUssQ0FBQTtLQUNiOzs7U0F2ZkcsT0FBTzs7O1FBMGZMLE9BQU8sR0FBUCxPQUFPIiwiZmlsZSI6Ii9ob21lL3NoYW5lLy5hdG9tL3BhY2thZ2VzL2dvLWNvbmZpZy9saWIvbG9jYXRvci5qcyIsInNvdXJjZXNDb250ZW50IjpbIid1c2UgYmFiZWwnXG5cbmltcG9ydCB7Q29tcG9zaXRlRGlzcG9zYWJsZX0gZnJvbSAnYXRvbSdcbmltcG9ydCB7aXNUcnV0aHksIGlzRmFsc3l9IGZyb20gJy4vY2hlY2snXG5pbXBvcnQge0V4ZWN1dG9yfSBmcm9tICcuL2V4ZWN1dG9yJ1xuaW1wb3J0IHtQYXRoSGVscGVyfSBmcm9tICcuL3BhdGhoZWxwZXInXG5pbXBvcnQgXyBmcm9tICdsb2Rhc2gnXG5pbXBvcnQgZnMgZnJvbSAnZnMnXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJ1xuXG5jbGFzcyBMb2NhdG9yIHtcbiAgY29uc3RydWN0b3IgKG9wdGlvbnMpIHtcbiAgICB0aGlzLnN1YnNjcmlwdGlvbnMgPSBuZXcgQ29tcG9zaXRlRGlzcG9zYWJsZSgpXG4gICAgdGhpcy5lbnZpcm9ubWVudEZuID0gbnVsbFxuICAgIHRoaXMuZXhlY3V0b3IgPSBudWxsXG4gICAgdGhpcy5leGVjdXRhYmxlU3VmZml4ID0gJydcbiAgICB0aGlzLnBhdGhLZXkgPSAnUEFUSCdcbiAgICBpZiAob3MucGxhdGZvcm0oKSA9PT0gJ3dpbjMyJykge1xuICAgICAgdGhpcy5leGVjdXRhYmxlU3VmZml4ID0gJy5leGUnXG4gICAgICB0aGlzLnBhdGhLZXkgPSAnUGF0aCdcbiAgICB9XG4gICAgdGhpcy5nb0V4ZWN1dGFibGVzID0gWydnbycgKyB0aGlzLmV4ZWN1dGFibGVTdWZmaXgsICdnb2FwcCcgKyB0aGlzLmV4ZWN1dGFibGVTdWZmaXhdXG4gICAgdGhpcy5wYXRoaGVscGVyID0gbmV3IFBhdGhIZWxwZXIoKVxuICAgIHRoaXMucmVhZHlGbiA9IG51bGxcbiAgICBpZiAoaXNUcnV0aHkob3B0aW9ucykpIHtcbiAgICAgIGlmIChpc1RydXRoeShvcHRpb25zLmVudmlyb25tZW50KSkge1xuICAgICAgICB0aGlzLmVudmlyb25tZW50Rm4gPSBvcHRpb25zLmVudmlyb25tZW50XG4gICAgICB9XG4gICAgICBpZiAoaXNUcnV0aHkob3B0aW9ucy5yZWFkeSkpIHtcbiAgICAgICAgdGhpcy5yZWFkeUZuID0gb3B0aW9ucy5yZWFkeVxuICAgICAgfVxuICAgICAgaWYgKGlzVHJ1dGh5KG9wdGlvbnMuZXhlY3V0b3IpKSB7XG4gICAgICAgIHRoaXMuZXhlY3V0b3IgPSBvcHRpb25zLmV4ZWN1dG9yXG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuZXhlY3V0b3IgPT09IG51bGwpIHtcbiAgICAgIHRoaXMuZXhlY3V0b3IgPSBuZXcgRXhlY3V0b3Ioe2Vudmlyb25tZW50Rm46IHRoaXMuZW52aXJvbm1lbnQuYmluZCh0aGlzKX0pXG4gICAgfVxuXG4gICAgdGhpcy5zdWJzY3JpcHRpb25zLmFkZCh0aGlzLmV4ZWN1dG9yKVxuICAgIHRoaXMuZ29Mb2NhdG9ycyA9IFtcbiAgICAgIC8vIEF2b2lkIHVzaW5nIGdvcm9vdExvY2F0b3IgLyBHT1JPT1QgdW5sZXNzIHlvdSBrbm93IHdoYXQgeW91J3JlIGRvaW5nXG4gICAgICAvLyAoYW5kIGFzc3VtZSB5b3UgZG9uJ3Qga25vdyB3aGF0IHlvdSdyZSB1bmxlc3MgeW91IGhhdmUgc2lnbmlmaWNhbnRcbiAgICAgIC8vIGdvIGV4cGVyaWVuY2UpXG4gICAgICAoKSA9PiB7IHJldHVybiB0aGlzLmdvcm9vdExvY2F0b3IoKSB9LFxuICAgICAgKCkgPT4geyByZXR1cm4gdGhpcy5lZGl0b3Jjb25maWdMb2NhdG9yKCkgfSxcbiAgICAgICgpID0+IHsgcmV0dXJuIHRoaXMuY29uZmlnTG9jYXRvcigpIH0sXG4gICAgICAoKSA9PiB7IHJldHVybiB0aGlzLnBhdGhMb2NhdG9yKCkgfSxcbiAgICAgICgpID0+IHsgcmV0dXJuIHRoaXMuZGVmYXVsdExvY2F0b3IoKSB9XG4gICAgXVxuXG4gICAgdGhpcy5zZXRLbm93blRvb2xTdHJhdGVnaWVzKClcbiAgICB0aGlzLnNldEtub3duVG9vbExvY2F0aW9ucygpXG4gIH1cblxuICBkaXNwb3NlICgpIHtcbiAgICB0aGlzLnJlc2V0UnVudGltZXMoKVxuICAgIGlmICh0aGlzLnN1YnNjcmlwdGlvbnMpIHtcbiAgICAgIHRoaXMuc3Vic2NyaXB0aW9ucy5kaXNwb3NlKClcbiAgICB9XG4gICAgdGhpcy5nb0xvY2F0b3JzID0gbnVsbFxuICAgIHRoaXMuZXhlY3V0YWJsZVN1ZmZpeCA9IG51bGxcbiAgICB0aGlzLnBhdGhLZXkgPSBudWxsXG4gICAgdGhpcy5nb0V4ZWN1dGFibGVzID0gbnVsbFxuICAgIHRoaXMuc3Vic2NyaXB0aW9ucyA9IG51bGxcbiAgICB0aGlzLmVudmlyb25tZW50Rm4gPSBudWxsXG4gICAgdGhpcy5leGVjdXRvciA9IG51bGxcbiAgICB0aGlzLnJlYWR5Rm4gPSBudWxsXG4gICAgdGhpcy50b29sTG9jYXRpb25zID0gbnVsbFxuICAgIHRoaXMudG9vbFN0cmF0ZWdpZXMgPSBudWxsXG4gIH1cblxuICAvLyBQdWJsaWNcbiAgcnVudGltZXMgKHByb2plY3QsIG9wdGlvbnMpIHtcbiAgICBpZiAoaXNUcnV0aHkodGhpcy5ydW50aW1lc0NhY2hlKSkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh0aGlzLnJ1bnRpbWVzQ2FjaGUpXG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGxldCBjYW5kaWRhdGVzID0gdGhpcy5ydW50aW1lQ2FuZGlkYXRlcyhwcm9qZWN0KVxuICAgICAgaWYgKGlzRmFsc3koY2FuZGlkYXRlcykgfHwgY2FuZGlkYXRlcy5jb25zdHJ1Y3RvciAhPT0gQXJyYXkgfHwgY2FuZGlkYXRlcy5sZW5ndGggPCAxKSB7XG4gICAgICAgIHJldHVybiByZXNvbHZlKFtdKVxuICAgICAgfVxuXG4gICAgICBsZXQgdmlhYmxlQ2FuZGlkYXRlcyA9IFtdXG4gICAgICBmb3IgKGxldCBjYW5kaWRhdGUgb2YgY2FuZGlkYXRlcykge1xuICAgICAgICBsZXQgZ292ZXJzaW9uID0gdGhpcy5leGVjdXRvci5leGVjU3luYyhjYW5kaWRhdGUsIFsndmVyc2lvbiddLCB7Y3dkOiBwYXRoLmRpcm5hbWUoY2FuZGlkYXRlKX0pXG4gICAgICAgIGlmIChpc1RydXRoeShnb3ZlcnNpb24pICYmIGdvdmVyc2lvbi5jb2RlID09PSAwICYmIGdvdmVyc2lvbi5zdGRvdXQuc3RhcnRzV2l0aCgnZ28gJykpIHtcbiAgICAgICAgICBsZXQgdiA9IHtwYXRoOiBjYW5kaWRhdGUsIHZlcnNpb246IGdvdmVyc2lvbi5zdGRvdXQucmVwbGFjZSgvXFxyP1xcbnxcXHIvZywgJycpfVxuICAgICAgICAgIGxldCB2ZXJzaW9uQ29tcG9uZW50cyA9IHYudmVyc2lvbi5zcGxpdCgnICcpXG4gICAgICAgICAgdi5uYW1lID0gdmVyc2lvbkNvbXBvbmVudHNbMl1cbiAgICAgICAgICB2LnNlbXZlciA9IHZlcnNpb25Db21wb25lbnRzWzJdXG4gICAgICAgICAgaWYgKHYuc2VtdmVyLnN0YXJ0c1dpdGgoJ2dvJykpIHtcbiAgICAgICAgICAgIHYuc2VtdmVyID0gdi5zZW12ZXIuc3Vic3RyaW5nKDIsIHYuc2VtdmVyLmxlbmd0aClcbiAgICAgICAgICB9XG4gICAgICAgICAgdmlhYmxlQ2FuZGlkYXRlcy5wdXNoKHYpXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgbGV0IGZpbmFsQ2FuZGlkYXRlcyA9IFtdXG4gICAgICBmb3IgKGxldCB2aWFibGVDYW5kaWRhdGUgb2YgdmlhYmxlQ2FuZGlkYXRlcykge1xuICAgICAgICBsZXQgZ29lbnYgPSB0aGlzLmV4ZWN1dG9yLmV4ZWNTeW5jKHZpYWJsZUNhbmRpZGF0ZS5wYXRoLCBbJ2VudiddLCB7Y3dkOiBwYXRoLmRpcm5hbWUodmlhYmxlQ2FuZGlkYXRlLnBhdGgpfSlcbiAgICAgICAgaWYgKGlzVHJ1dGh5KGdvZW52KSAmJiBnb2Vudi5jb2RlID09PSAwICYmIGdvZW52LnN0ZG91dC50cmltKCkgIT09ICcnKSB7XG4gICAgICAgICAgbGV0IGl0ZW1zID0gZ29lbnYuc3Rkb3V0LnNwbGl0KCdcXG4nKVxuICAgICAgICAgIGZvciAobGV0IGl0ZW0gb2YgaXRlbXMpIHtcbiAgICAgICAgICAgIGl0ZW0gPSBpdGVtLnJlcGxhY2UoL1tcXG5cXHJdL2csICcnKVxuICAgICAgICAgICAgaWYgKGl0ZW0uaW5jbHVkZXMoJz0nKSkge1xuICAgICAgICAgICAgICBsZXQgdHVwbGUgPSBpdGVtLnNwbGl0KCc9JylcbiAgICAgICAgICAgICAgbGV0IGtleSA9IHR1cGxlWzBdXG4gICAgICAgICAgICAgIGxldCB2YWx1ZSA9IHR1cGxlWzFdXG4gICAgICAgICAgICAgIGlmICh0dXBsZS5sZW5ndGggPiAyKSB7XG4gICAgICAgICAgICAgICAgdmFsdWUgPSB0dXBsZS5zbGljZSgxLCB0dXBsZS5sZW5ndGggKyAxKS5qb2luKCc9JylcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZiAob3MucGxhdGZvcm0oKSA9PT0gJ3dpbjMyJykge1xuICAgICAgICAgICAgICAgIGlmIChrZXkuc3RhcnRzV2l0aCgnc2V0ICcpKSB7XG4gICAgICAgICAgICAgICAgICBrZXkgPSBrZXkuc3Vic3RyaW5nKDQsIGtleS5sZW5ndGgpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmICh2YWx1ZS5sZW5ndGggPiAyKSB7XG4gICAgICAgICAgICAgICAgICB2YWx1ZSA9IHZhbHVlLnN1YnN0cmluZygxLCB2YWx1ZS5sZW5ndGggLSAxKVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICB2YWx1ZSA9ICcnXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHZpYWJsZUNhbmRpZGF0ZVtrZXldID0gdmFsdWVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgZmluYWxDYW5kaWRhdGVzLnB1c2godmlhYmxlQ2FuZGlkYXRlKVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHRoaXMucnVudGltZXNDYWNoZSA9IGZpbmFsQ2FuZGlkYXRlc1xuICAgICAgcmVzb2x2ZSh0aGlzLnJ1bnRpbWVzQ2FjaGUpXG4gICAgfSlcbiAgfVxuXG4gIHJlc2V0UnVudGltZXMgKCkge1xuICAgIHRoaXMucnVudGltZXNDYWNoZSA9IG51bGxcbiAgfVxuXG4gIHN0YXRpc2hTeW5jIChwYXRoVmFsdWUpIHtcbiAgICBsZXQgc3RhdCA9IGZhbHNlXG4gICAgaWYgKGlzVHJ1dGh5KHBhdGhWYWx1ZSkgJiYgIShwYXRoVmFsdWUudHJpbSgpID09PSAnJykpIHtcbiAgICAgIHRyeSB7IHN0YXQgPSBmcy5zdGF0U3luYyhwYXRoVmFsdWUpIH0gY2F0Y2ggKGUpIHsgfVxuICAgIH1cbiAgICByZXR1cm4gc3RhdFxuICB9XG5cbiAgc3RhdCAocCkge1xuICAgIGlmIChpc0ZhbHN5KHApIHx8IHAuY29uc3RydWN0b3IgIT09IFN0cmluZyB8fCBwLnRyaW0oKSA9PT0gJycpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoZmFsc2UpXG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGZzLnN0YXQocCwgKGVyciwgc3RhdCkgPT4ge1xuICAgICAgICBpZiAoaXNUcnV0aHkoZXJyKSkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlRXJyb3IoZXJyKVxuICAgICAgICAgIHJlc29sdmUoZmFsc2UpXG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cbiAgICAgICAgcmVzb2x2ZShzdGF0KVxuICAgICAgfSlcbiAgICB9KVxuICB9XG5cbiAgcGF0aEV4aXN0cyAocCkge1xuICAgIHJldHVybiB0aGlzLmV4aXN0cyhwKS50aGVuKChlKSA9PiB7XG4gICAgICBpZiAoaXNGYWxzeShlKSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICAgIHJldHVybiBwXG4gICAgfSlcbiAgfVxuXG4gIGZpbGVFeGlzdHMgKHApIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0KHApLnRoZW4oKHMpID0+IHtcbiAgICAgIGlmIChpc0ZhbHN5KHMpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuXG4gICAgICBpZiAocy5pc0ZpbGUoKSkge1xuICAgICAgICByZXR1cm4gcFxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9KVxuICB9XG5cbiAgZGlyZWN0b3J5RXhpc3RzIChwKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdChwKS50aGVuKChzKSA9PiB7XG4gICAgICBpZiAoaXNGYWxzeShzKSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cblxuICAgICAgaWYgKHMuaXNEaXJlY3RvcnkoKSkge1xuICAgICAgICByZXR1cm4gcFxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9KVxuICB9XG5cbiAgZXhpc3RzIChwKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdChwKS50aGVuKChzKSA9PiB7XG4gICAgICBpZiAoaXNGYWxzeShzKSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRydWVcbiAgICB9KVxuICB9XG5cbiAgcnVudGltZUNhbmRpZGF0ZXMgKHByb2plY3QpIHtcbiAgICBsZXQgY2FuZGlkYXRlcyA9IFtdXG4gICAgZm9yIChsZXQgbG9jYXRvciBvZiB0aGlzLmdvTG9jYXRvcnMpIHtcbiAgICAgIGxldCBjID0gbG9jYXRvcihwcm9qZWN0KVxuICAgICAgaWYgKGlzVHJ1dGh5KGMpICYmIGMuY29uc3RydWN0b3IgPT09IEFycmF5ICYmIGMubGVuZ3RoID4gMCkge1xuICAgICAgICBjYW5kaWRhdGVzID0gXy51bmlvbihjYW5kaWRhdGVzLCBjKVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gY2FuZGlkYXRlc1xuICB9XG5cbiAgZWRpdG9yY29uZmlnTG9jYXRvciAocHJvamVjdCkge1xuICAgIC8vIFRPRE86IC5lZGl0b3Jjb25maWdcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIGNvbmZpZ0xvY2F0b3IgKHByb2plY3QpIHtcbiAgICBsZXQgZ29pbnN0YWxsYXRpb24gPSBhdG9tLmNvbmZpZy5nZXQoJ2dvLXBsdXMuZ29JbnN0YWxsYXRpb24nKVxuICAgIGxldCBzdGF0ID0gdGhpcy5zdGF0aXNoU3luYyhnb2luc3RhbGxhdGlvbilcbiAgICBpZiAoaXNUcnV0aHkoc3RhdCkpIHtcbiAgICAgIGxldCBkID0gZ29pbnN0YWxsYXRpb25cbiAgICAgIGlmIChzdGF0LmlzRmlsZSgpKSB7XG4gICAgICAgIGQgPSBwYXRoLmRpcm5hbWUoZ29pbnN0YWxsYXRpb24pXG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5maW5kRXhlY3V0YWJsZXNJblBhdGgoZCwgdGhpcy5leGVjdXRhYmxlcylcbiAgICB9XG5cbiAgICByZXR1cm4gW11cbiAgfVxuXG4gIGdvcm9vdExvY2F0b3IgKCkge1xuICAgIGlmIChpc0ZhbHN5KHRoaXMuZW52aXJvbm1lbnQoKS5HT1JPT1QpIHx8IHRoaXMuZW52aXJvbm1lbnQoKS5HT1JPT1QudHJpbSgpID09PSAnJykge1xuICAgICAgcmV0dXJuIFtdXG4gICAgfVxuICAgIHJldHVybiB0aGlzLmZpbmRFeGVjdXRhYmxlc0luUGF0aChwYXRoLmpvaW4odGhpcy5lbnZpcm9ubWVudCgpLkdPUk9PVCwgJ2JpbicpLCB0aGlzLmdvRXhlY3V0YWJsZXMpXG4gIH1cblxuICBwYXRoTG9jYXRvciAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZmluZEV4ZWN1dGFibGVzSW5QYXRoKHRoaXMuZW52aXJvbm1lbnQoKVt0aGlzLnBhdGhLZXldLCB0aGlzLmdvRXhlY3V0YWJsZXMpXG4gIH1cblxuICBkZWZhdWx0TG9jYXRvciAoKSB7XG4gICAgbGV0IGluc3RhbGxQYXRocyA9IFtdXG4gICAgaWYgKG9zLnBsYXRmb3JtKCkgPT09ICd3aW4zMicpIHtcbiAgICAgIC8qXG4gICAgICBjOlxcZ29cXGJpbiA9IEJpbmFyeSBEaXN0cmlidXRpb25cbiAgICAgIGM6XFx0b29sc1xcZ29cXGJpbiA9IENob2NvbGF0ZXlcbiAgICAgICovXG4gICAgICBpbnN0YWxsUGF0aHMucHVzaChwYXRoLmpvaW4oJ2M6JywgJ2dvJywgJ2JpbicpKVxuICAgICAgaW5zdGFsbFBhdGhzLnB1c2gocGF0aC5qb2luKCdjOicsICd0b29scycsICdnbycsICdiaW4nKSlcbiAgICB9IGVsc2Uge1xuICAgICAgLypcbiAgICAgIC91c3IvbG9jYWwvZ28vYmluID0gQmluYXJ5IERpc3RyaWJ1dGlvblxuICAgICAgL3Vzci9sb2NhbC9iaW4gPSBIb21lYnJld1xuICAgICAgKi9cbiAgICAgIGluc3RhbGxQYXRocy5wdXNoKHBhdGguam9pbignLycsICd1c3InLCAnbG9jYWwnLCAnZ28nLCAnYmluJykpXG4gICAgICBpbnN0YWxsUGF0aHMucHVzaChwYXRoLmpvaW4oJy8nLCAndXNyJywgJ2xvY2FsJywgJ2JpbicpKVxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5maW5kRXhlY3V0YWJsZXNJblBhdGgoaW5zdGFsbFBhdGhzLmpvaW4ocGF0aC5kZWxpbWl0ZXIpLCB0aGlzLmdvRXhlY3V0YWJsZXMpXG4gIH1cblxuICBmaW5kRXhlY3V0YWJsZXNJblBhdGggKHBhdGhWYWx1ZSwgZXhlY3V0YWJsZXMpIHtcbiAgICBsZXQgY2FuZGlkYXRlcyA9IFtdXG4gICAgaWYgKGlzRmFsc3kocGF0aFZhbHVlKSB8fCBwYXRoVmFsdWUuY29uc3RydWN0b3IgIT09IFN0cmluZyB8fCBwYXRoVmFsdWUudHJpbSgpID09PSAnJykge1xuICAgICAgcmV0dXJuIGNhbmRpZGF0ZXNcbiAgICB9XG5cbiAgICBpZiAoaXNGYWxzeShleGVjdXRhYmxlcykgfHwgZXhlY3V0YWJsZXMuY29uc3RydWN0b3IgIT09IEFycmF5IHx8IGV4ZWN1dGFibGVzLmxlbmd0aCA8IDEpIHtcbiAgICAgIHJldHVybiBjYW5kaWRhdGVzXG4gICAgfVxuXG4gICAgbGV0IGVsZW1lbnRzID0gdGhpcy5wYXRoaGVscGVyLmV4cGFuZCh0aGlzLmVudmlyb25tZW50KCksIHBhdGhWYWx1ZSkuc3BsaXQocGF0aC5kZWxpbWl0ZXIpXG4gICAgZm9yIChsZXQgZWxlbWVudCBvZiBlbGVtZW50cykge1xuICAgICAgZm9yIChsZXQgZXhlY3V0YWJsZSBvZiBleGVjdXRhYmxlcykge1xuICAgICAgICBsZXQgY2FuZGlkYXRlID0gcGF0aC5qb2luKGVsZW1lbnQsIGV4ZWN1dGFibGUpXG4gICAgICAgIGxldCBzdGF0ID0gdGhpcy5zdGF0aXNoU3luYyhjYW5kaWRhdGUpXG4gICAgICAgIGlmIChpc1RydXRoeShzdGF0KSAmJiBzdGF0LmlzRmlsZSgpKSB7XG4gICAgICAgICAgY2FuZGlkYXRlcy5wdXNoKGNhbmRpZGF0ZSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gY2FuZGlkYXRlc1xuICB9XG5cbiAgLy8gUHVibGljXG4gIGdvcGF0aCAob3B0aW9ucykge1xuICAgIGxldCBlID0gdGhpcy5lbnZpcm9ubWVudCgpXG4gICAgaWYgKGlzRmFsc3koZS5HT1BBVEgpIHx8IGUuR09QQVRILnRyaW0oKSA9PT0gJycpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIHJldHVybiB0aGlzLnBhdGhoZWxwZXIuZXhwYW5kKGUsIGUuR09QQVRIKVxuICB9XG5cbiAgZW52aXJvbm1lbnQgKCkge1xuICAgIGlmIChpc0ZhbHN5KHRoaXMuZW52aXJvbm1lbnRGbikpIHtcbiAgICAgIHJldHVybiBwcm9jZXNzLmVudlxuICAgIH1cblxuICAgIGxldCBlID0gdGhpcy5lbnZpcm9ubWVudEZuKClcbiAgICBpZiAoaXNGYWxzeShlKSkge1xuICAgICAgcmV0dXJuIHByb2Nlc3MuZW52XG4gICAgfVxuICAgIHJldHVybiBlXG4gIH1cblxuICByZWFkeSAoKSB7XG4gICAgaWYgKGlzRmFsc3kodGhpcy5yZWFkeUZuKSkge1xuICAgICAgcmV0dXJuIHRydWVcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucmVhZHlGbigpXG4gIH1cblxuICBzZXRLbm93blRvb2xMb2NhdGlvbnMgKCkge1xuICAgIHRoaXMudG9vbExvY2F0aW9ucyA9IG5ldyBNYXAoKVxuICAgIHRoaXMudG9vbExvY2F0aW9ucy5zZXQoJ2dvaW1wb3J0cycsICdnb2xhbmcub3JnL3gvdG9vbHMvY21kL2dvaW1wb3J0cycpXG4gICAgdGhpcy50b29sTG9jYXRpb25zLnNldCgnZ29yZXR1cm5zJywgJ3NvdXJjZWdyYXBoLmNvbS9zcXMvZ29yZXR1cm5zJylcbiAgICB0aGlzLnRvb2xMb2NhdGlvbnMuc2V0KCdnb21ldGFsaW50ZXInLCAnZ2l0aHViLmNvbS9hbGVjdGhvbWFzL2dvbWV0YWxpbnRlcicpXG4gICAgdGhpcy50b29sTG9jYXRpb25zLnNldCgnZ29kZWJ1ZycsICdnaXRodWIuY29tL21haWxndW4vZ29kZWJ1ZycpXG4gICAgdGhpcy50b29sTG9jYXRpb25zLnNldCgnb3JhY2xlJywgJ2dvbGFuZy5vcmcveC90b29scy9jbWQvb3JhY2xlJylcbiAgICB0aGlzLnRvb2xMb2NhdGlvbnMuc2V0KCdnb2NvZGUnLCAnZ2l0aHViLmNvbS9uc2YvZ29jb2RlJylcbiAgfVxuXG4gIHNldEtub3duVG9vbFN0cmF0ZWdpZXMgKCkge1xuICAgIHRoaXMudG9vbFN0cmF0ZWdpZXMgPSBuZXcgTWFwKClcblxuICAgIC8vIEJ1aWx0LUluIFRvb2xzXG4gICAgdGhpcy50b29sU3RyYXRlZ2llcy5zZXQoJ2dvJywgJ0dPUk9PVEJJTicpXG4gICAgdGhpcy50b29sU3RyYXRlZ2llcy5zZXQoJ2dvZm10JywgJ0dPUk9PVEJJTicpXG4gICAgdGhpcy50b29sU3RyYXRlZ2llcy5zZXQoJ2dvZG9jJywgJ0dPUk9PVEJJTicpXG4gICAgdGhpcy50b29sU3RyYXRlZ2llcy5zZXQoJ2FkZHIybGluZScsICdHT1RPT0xESVInKVxuICAgIHRoaXMudG9vbFN0cmF0ZWdpZXMuc2V0KCdhcGknLCAnR09UT09MRElSJylcbiAgICB0aGlzLnRvb2xTdHJhdGVnaWVzLnNldCgnYXNtJywgJ0dPVE9PTERJUicpXG4gICAgdGhpcy50b29sU3RyYXRlZ2llcy5zZXQoJ2NnbycsICdHT1RPT0xESVInKVxuICAgIHRoaXMudG9vbFN0cmF0ZWdpZXMuc2V0KCdjb21waWxlJywgJ0dPVE9PTERJUicpXG4gICAgdGhpcy50b29sU3RyYXRlZ2llcy5zZXQoJ2NvdmVyJywgJ0dPVE9PTERJUicpXG4gICAgdGhpcy50b29sU3RyYXRlZ2llcy5zZXQoJ2Rpc3QnLCAnR09UT09MRElSJylcbiAgICB0aGlzLnRvb2xTdHJhdGVnaWVzLnNldCgnZG9jJywgJ0dPVE9PTERJUicpXG4gICAgdGhpcy50b29sU3RyYXRlZ2llcy5zZXQoJ2ZpeCcsICdHT1RPT0xESVInKVxuICAgIHRoaXMudG9vbFN0cmF0ZWdpZXMuc2V0KCdsaW5rJywgJ0dPVE9PTERJUicpXG4gICAgdGhpcy50b29sU3RyYXRlZ2llcy5zZXQoJ25tJywgJ0dPVE9PTERJUicpXG4gICAgdGhpcy50b29sU3RyYXRlZ2llcy5zZXQoJ29iamR1bXAnLCAnR09UT09MRElSJylcbiAgICB0aGlzLnRvb2xTdHJhdGVnaWVzLnNldCgncGFjaycsICdHT1RPT0xESVInKVxuICAgIHRoaXMudG9vbFN0cmF0ZWdpZXMuc2V0KCdwcHJvZicsICdHT1RPT0xESVInKVxuICAgIHRoaXMudG9vbFN0cmF0ZWdpZXMuc2V0KCd0b3VyJywgJ0dPVE9PTERJUicpXG4gICAgdGhpcy50b29sU3RyYXRlZ2llcy5zZXQoJ3RyYWNlJywgJ0dPVE9PTERJUicpXG4gICAgdGhpcy50b29sU3RyYXRlZ2llcy5zZXQoJ3ZldCcsICdHT1RPT0xESVInKVxuICAgIHRoaXMudG9vbFN0cmF0ZWdpZXMuc2V0KCd5YWNjJywgJ0dPVE9PTERJUicpXG5cbiAgICAvLyBFeHRlcm5hbCBUb29sc1xuICAgIHRoaXMudG9vbFN0cmF0ZWdpZXMuc2V0KCdnaXQnLCAnUEFUSCcpXG5cbiAgICAvLyBPdGhlciBUb29scyBBcmUgQXNzdW1lZCBUbyBCZSBJbiBQQVRIIG9yIEdPQklOIG9yIEdPUEFUSC9iaW5cbiAgICAvLyBHT1BBVEhCSU4gQ2FuIEJlIFVzZWQgSW4gVGhlIEZ1dHVyZSBBcyBBIFN0cmF0ZWd5LCBJZiBSZXF1aXJlZFxuICAgIC8vIEdPUEFUSEJJTiBXaWxsIFVuZGVyc3RhbmQgR08xNVZFTkRPUkVYUEVSSU1FTlRcbiAgfVxuXG4gIC8vIFB1YmxpY1xuICBydW50aW1lRm9yUHJvamVjdCAocHJvamVjdCkge1xuICAgIGlmIChpc1RydXRoeShwcm9qZWN0KSAmJiBwcm9qZWN0LmNvbnN0cnVjdG9yID09PSBTdHJpbmcgfHwgbmFtZS50cmltKCkgIT09ICcnKSB7XG4gICAgICAvLyBEbyBzb21ldGhpbmcgc3BlY2lmaWMgZm9yIHRoZSBwcm9qZWN0XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMucnVudGltZXMocHJvamVjdCkudGhlbigocikgPT4ge1xuICAgICAgaWYgKGlzRmFsc3kocikgfHwgci5sZW5ndGggPCAxKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJbMF1cbiAgICAgIH1cbiAgICB9KVxuICB9XG5cbiAgLy8gUHVibGljXG4gIGZpbmRUb29sIChuYW1lLCBwcm9qZWN0LCBvcHRpb25zKSB7XG4gICAgaWYgKGlzRmFsc3kobmFtZSkgfHwgbmFtZS5jb25zdHJ1Y3RvciAhPT0gU3RyaW5nIHx8IG5hbWUudHJpbSgpID09PSAnJykge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShmYWxzZSlcbiAgICB9XG5cbiAgICBsZXQgc3RyYXRlZ3kgPSBmYWxzZVxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUobnVsbCkudGhlbigoKSA9PiB7XG4gICAgICBpZiAoaXNUcnV0aHkocHJvamVjdCkpIHtcbiAgICAgICAgLy8gRG8gc29tZXRoaW5nIGhlcmVcbiAgICAgIH1cbiAgICAgIGlmICh0aGlzLnRvb2xTdHJhdGVnaWVzLmhhcyhuYW1lKSkge1xuICAgICAgICBzdHJhdGVneSA9IHRoaXMudG9vbFN0cmF0ZWdpZXMuZ2V0KG5hbWUpXG4gICAgICB9XG4gICAgICBpZiAoaXNGYWxzeShzdHJhdGVneSkpIHtcbiAgICAgICAgc3RyYXRlZ3kgPSAnREVGQVVMVCdcbiAgICAgIH1cbiAgICB9KS50aGVuKCgpID0+IHtcbiAgICAgIGlmIChzdHJhdGVneSAhPT0gJ0dPUk9PVEJJTicgJiYgc3RyYXRlZ3kgIT09ICdHT1RPT0xESVInKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5ydW50aW1lRm9yUHJvamVjdChwcm9qZWN0KS50aGVuKChydW50aW1lKSA9PiB7XG4gICAgICAgIGlmIChpc0ZhbHN5KHJ1bnRpbWUpKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoc3RyYXRlZ3kgPT09ICdHT1JPT1RCSU4nKSB7XG4gICAgICAgICAgcmV0dXJuIHBhdGguam9pbihydW50aW1lLkdPUk9PVCwgJ2JpbicsIG5hbWUgKyBydW50aW1lLkdPRVhFKVxuICAgICAgICB9IGVsc2UgaWYgKHN0cmF0ZWd5ID09PSAnR09UT09MRElSJykge1xuICAgICAgICAgIHJldHVybiBwYXRoLmpvaW4ocnVudGltZS5HT1RPT0xESVIsIG5hbWUgKyBydW50aW1lLkdPRVhFKVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfSlcbiAgICB9KS50aGVuKChzcGVjaWZpY1Rvb2wpID0+IHtcbiAgICAgIGlmIChpc1RydXRoeShzcGVjaWZpY1Rvb2wpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnN0YXQoc3BlY2lmaWNUb29sKS50aGVuKChzKSA9PiB7XG4gICAgICAgICAgaWYgKGlzVHJ1dGh5KHMpICYmIHMuaXNGaWxlKCkpIHtcbiAgICAgICAgICAgIHJldHVybiBzcGVjaWZpY1Rvb2xcbiAgICAgICAgICB9XG4gICAgICAgIH0pLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICB0aGlzLmhhbmRsZUVycm9yKGVycilcbiAgICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgICAgfSlcbiAgICAgIH1cblxuICAgICAgaWYgKHN0cmF0ZWd5ID09PSAnR09QQVRIQklOJykge1xuICAgICAgICByZXR1cm4gdGhpcy5maW5kVG9vbEluRGVsaW1pdGVkRW52aXJvbm1lbnRWYXJpYWJsZShuYW1lLCAnR09QQVRIJywgcHJvamVjdClcbiAgICAgIH1cblxuICAgICAgaWYgKHN0cmF0ZWd5ID09PSAnUEFUSCcpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZmluZFRvb2xJbkRlbGltaXRlZEVudmlyb25tZW50VmFyaWFibGUobmFtZSwgdGhpcy5wYXRoS2V5LCBwcm9qZWN0KVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5maW5kVG9vbFdpdGhEZWZhdWx0U3RyYXRlZ3kobmFtZSwgcHJvamVjdClcbiAgICB9KVxuICB9XG5cbiAgaGFuZGxlRXJyb3IgKGVycikge1xuICAgIGlmIChpc1RydXRoeShlcnIuaGFuZGxlKSkge1xuICAgICAgZXJyLmhhbmRsZSgpXG4gICAgfVxuICAgIC8vIGNvbnNvbGUubG9nKGVycilcbiAgfVxuXG4gIGhhbmRsZUFuZFJlamVjdCAoZXJyLCByZWplY3QpIHtcbiAgICB0aGlzLmhhbmRsZUVycm9yKGVycilcbiAgICByZWplY3QoZXJyKVxuICB9XG5cbiAgZmluZFRvb2xXaXRoRGVmYXVsdFN0cmF0ZWd5IChuYW1lLCBwcm9qZWN0LCBvcHRpb25zKSB7XG4gICAgaWYgKGlzRmFsc3kobmFtZSkgfHwgbmFtZS5jb25zdHJ1Y3RvciAhPT0gU3RyaW5nIHx8IG5hbWUudHJpbSgpID09PSAnJykge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShmYWxzZSlcbiAgICB9XG5cbiAgICAvLyBEZWZhdWx0IFN0cmF0ZWd5IElzOiBMb29rIEZvciBUaGUgVG9vbCBJbiBHT1BBVEgsIFRoZW4gTG9vayBJbiBQQVRIXG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpLnRoZW4oKCkgPT4ge1xuICAgICAgcmV0dXJuIHRoaXMuZmluZFRvb2xJbkRlbGltaXRlZEVudmlyb25tZW50VmFyaWFibGUobmFtZSwgJ0dPUEFUSCcsIHByb2plY3QpXG4gICAgfSkudGhlbigodG9vbCkgPT4ge1xuICAgICAgaWYgKGlzVHJ1dGh5KHRvb2wpKSB7XG4gICAgICAgIHJldHVybiB0b29sXG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5maW5kVG9vbEluRGVsaW1pdGVkRW52aXJvbm1lbnRWYXJpYWJsZShuYW1lLCB0aGlzLnBhdGhLZXksIHByb2plY3QpXG4gICAgfSlcbiAgfVxuXG4gIGZpbmRUb29sSW5EZWxpbWl0ZWRFbnZpcm9ubWVudFZhcmlhYmxlICh0b29sTmFtZSwga2V5LCBwcm9qZWN0KSB7XG4gICAgaWYgKGlzRmFsc3kodG9vbE5hbWUpIHx8IHRvb2xOYW1lLmNvbnN0cnVjdG9yICE9PSBTdHJpbmcgfHwgdG9vbE5hbWUudHJpbSgpID09PSAnJykge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShmYWxzZSlcbiAgICB9XG5cbiAgICBsZXQgcCA9IHRoaXMuZW52aXJvbm1lbnQoKVtrZXldXG4gICAgaWYgKGlzRmFsc3kocCkpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoZmFsc2UpXG4gICAgfVxuXG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShmYWxzZSkudGhlbigoKSA9PiB7XG4gICAgICBsZXQgZWxlbWVudHMgPSBwLnNwbGl0KHBhdGguZGVsaW1pdGVyKVxuICAgICAgaWYgKGtleSA9PT0gJ0dPUEFUSCcgJiYgaXNUcnV0aHkodGhpcy5lbnZpcm9ubWVudCgpWydHTzE1VkVORE9SRVhQRVJJTUVOVCddKSkge1xuICAgICAgICAvLyBUT0RPOiBVbmRlcnN0YW5kIFZlbmRvciBFeHBlcmltZW50IFBhdGhzIEJldHRlclxuICAgICAgICAvLyBlbGVtZW50cy51bnNoaWZ0KCd2ZW5kb3InKVxuICAgICAgfVxuICAgICAgZm9yIChsZXQgZWxlbWVudCBvZiBlbGVtZW50cykge1xuICAgICAgICBsZXQgaXRlbSA9ICcnXG4gICAgICAgIGlmIChrZXkgPT09ICdHT1BBVEgnKSB7XG4gICAgICAgICAgaXRlbSA9IHBhdGguam9pbihlbGVtZW50LCAnYmluJywgdG9vbE5hbWUgKyB0aGlzLmV4ZWN1dGFibGVTdWZmaXgpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaXRlbSA9IHBhdGguam9pbihlbGVtZW50LCB0b29sTmFtZSArIHRoaXMuZXhlY3V0YWJsZVN1ZmZpeClcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChmcy5leGlzdHNTeW5jKGl0ZW0pICYmIGZzLnN0YXRTeW5jKGl0ZW0pLmlzRmlsZSgpKSB7XG4gICAgICAgICAgcmV0dXJuIGl0ZW1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9KVxuICB9XG5cbiAgZ2V0VG9vbCAobmFtZSwgcHJvamVjdCwgb3B0aW9ucykge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICByZXNvbHZlKGZhbHNlKVxuICAgIH0pXG4gIH1cblxuICAvLyBQdWJsaWNcbiAgcHJvbXB0Rm9yVG9vbCAobmFtZSwgcHJvamVjdCwgb3B0aW9ucykge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG59XG5cbmV4cG9ydCB7TG9jYXRvcn1cbiJdfQ==
//# sourceURL=/home/shane/.atom/packages/go-config/lib/locator.js
