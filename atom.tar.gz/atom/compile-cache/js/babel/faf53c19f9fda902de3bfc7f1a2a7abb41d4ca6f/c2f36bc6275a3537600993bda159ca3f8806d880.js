Object.defineProperty(exports, '__esModule', {
  value: true
});

var _atom = require('atom');

var _environment = require('./environment');

'use babel';

exports['default'] = {
  environment: null,
  subscriptions: null,

  activate: function activate() {
    this.subscriptions = new _atom.CompositeDisposable();
    this.environment = new _environment.Environment();
    this.subscriptions.add(this.environment);
  },

  deactivate: function deactivate() {
    this.subscriptions.dispose();
    this.environment = null;
    this.subscriptions = null;
  },

  provide: function provide() {
    return this.environment.current();
  }
};
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL3NoYW5lLy5hdG9tL3BhY2thZ2VzL2Vudmlyb25tZW50L2xpYi9tYWluLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7b0JBRWtDLE1BQU07OzJCQUNkLGVBQWU7O0FBSHpDLFdBQVcsQ0FBQTs7cUJBS0k7QUFDYixhQUFXLEVBQUUsSUFBSTtBQUNqQixlQUFhLEVBQUUsSUFBSTs7QUFFbkIsVUFBUSxFQUFDLG9CQUFHO0FBQ1YsUUFBSSxDQUFDLGFBQWEsR0FBRywrQkFBeUIsQ0FBQTtBQUM5QyxRQUFJLENBQUMsV0FBVyxHQUFHLDhCQUFpQixDQUFBO0FBQ3BDLFFBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQTtHQUN6Qzs7QUFFRCxZQUFVLEVBQUMsc0JBQUc7QUFDWixRQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxDQUFBO0FBQzVCLFFBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFBO0FBQ3ZCLFFBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFBO0dBQzFCOztBQUVELFNBQU8sRUFBQyxtQkFBRztBQUNULFdBQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsQ0FBQTtHQUNsQztDQUNGIiwiZmlsZSI6Ii9ob21lL3NoYW5lLy5hdG9tL3BhY2thZ2VzL2Vudmlyb25tZW50L2xpYi9tYWluLmpzIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBiYWJlbCdcblxuaW1wb3J0IHtDb21wb3NpdGVEaXNwb3NhYmxlfSBmcm9tICdhdG9tJ1xuaW1wb3J0IHtFbnZpcm9ubWVudH0gZnJvbSAnLi9lbnZpcm9ubWVudCdcblxuZXhwb3J0IGRlZmF1bHQge1xuICBlbnZpcm9ubWVudDogbnVsbCxcbiAgc3Vic2NyaXB0aW9uczogbnVsbCxcblxuICBhY3RpdmF0ZSAoKSB7XG4gICAgdGhpcy5zdWJzY3JpcHRpb25zID0gbmV3IENvbXBvc2l0ZURpc3Bvc2FibGUoKVxuICAgIHRoaXMuZW52aXJvbm1lbnQgPSBuZXcgRW52aXJvbm1lbnQoKVxuICAgIHRoaXMuc3Vic2NyaXB0aW9ucy5hZGQodGhpcy5lbnZpcm9ubWVudClcbiAgfSxcblxuICBkZWFjdGl2YXRlICgpIHtcbiAgICB0aGlzLnN1YnNjcmlwdGlvbnMuZGlzcG9zZSgpXG4gICAgdGhpcy5lbnZpcm9ubWVudCA9IG51bGxcbiAgICB0aGlzLnN1YnNjcmlwdGlvbnMgPSBudWxsXG4gIH0sXG5cbiAgcHJvdmlkZSAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZW52aXJvbm1lbnQuY3VycmVudCgpXG4gIH1cbn1cbiJdfQ==
//# sourceURL=/home/shane/.atom/packages/environment/lib/main.js
