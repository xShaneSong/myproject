Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _os = require('os');

var _os2 = _interopRequireDefault(_os);

var _osHomedir = require('os-homedir');

var _osHomedir2 = _interopRequireDefault(_osHomedir);

var _check = require('./check');

'use babel';

var PathHelper = (function () {
  function PathHelper() {
    _classCallCheck(this, PathHelper);
  }

  _createClass(PathHelper, [{
    key: 'expand',
    value: function expand(env, thepath) {
      var _this = this;

      if ((0, _check.isFalsy)(thepath) || thepath.trim() === '') {
        return '';
      }

      if ((0, _check.isFalsy)(env)) {
        return thepath;
      }

      thepath = thepath.replace(/(~|\$[^\\/:]*|%[^\\;%]*%)+?/gim, function (text, match) {
        if (match === '~') {
          return _this.home();
        } else {
          var m = match;
          if (_os2['default'].platform() === 'win32') {
            m = match.replace(/%/g, '');
          } else {
            m = match.replace(/\$/g, '');
          }

          if (typeof env[m] !== 'undefined') {
            if (m === 'GOPATH' && env[m].indexOf(_path2['default'].delimiter) !== -1) {
              return _this.expand(env, env[m].split(_path2['default'].delimiter)[0].trim());
            } else {
              return _this.expand(env, env[m]);
            }
          } else {
            return match;
          }
        }
      });

      if (thepath.indexOf(_path2['default'].delimiter) === -1) {
        return this.resolveAndNormalize(thepath);
      }

      var paths = thepath.split(_path2['default'].delimiter);
      var result = '';
      for (var pathItem of paths) {
        pathItem = this.resolveAndNormalize(pathItem);
        if (result === '') {
          result = pathItem;
        } else {
          result = result + _path2['default'].delimiter + pathItem;
        }
      }

      return result;
    }
  }, {
    key: 'resolveAndNormalize',
    value: function resolveAndNormalize(pathitem) {
      if ((0, _check.isFalsy)(pathitem) || pathitem.trim() === '') {
        return '';
      }
      var result = _path2['default'].resolve(_path2['default'].normalize(pathitem));
      return result;
    }
  }, {
    key: 'home',
    value: function home() {
      return (0, _osHomedir2['default'])();
    }
  }]);

  return PathHelper;
})();

exports.PathHelper = PathHelper;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL3NoYW5lLy5hdG9tL3BhY2thZ2VzL2dvLWNvbmZpZy9saWIvcGF0aGhlbHBlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O29CQUVpQixNQUFNOzs7O2tCQUNSLElBQUk7Ozs7eUJBQ0csWUFBWTs7OztxQkFDWixTQUFTOztBQUwvQixXQUFXLENBQUE7O0lBT0wsVUFBVTtBQUNGLFdBRFIsVUFBVSxHQUNDOzBCQURYLFVBQVU7R0FFYjs7ZUFGRyxVQUFVOztXQUlQLGdCQUFDLEdBQUcsRUFBRSxPQUFPLEVBQUU7OztBQUNwQixVQUFJLG9CQUFRLE9BQU8sQ0FBQyxJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUU7QUFDN0MsZUFBTyxFQUFFLENBQUE7T0FDVjs7QUFFRCxVQUFJLG9CQUFRLEdBQUcsQ0FBQyxFQUFFO0FBQ2hCLGVBQU8sT0FBTyxDQUFBO09BQ2Y7O0FBRUQsYUFBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsZ0NBQWdDLEVBQUUsVUFBQyxJQUFJLEVBQUUsS0FBSyxFQUFLO0FBQzNFLFlBQUksS0FBSyxLQUFLLEdBQUcsRUFBRTtBQUNqQixpQkFBTyxNQUFLLElBQUksRUFBRSxDQUFBO1NBQ25CLE1BQU07QUFDTCxjQUFJLENBQUMsR0FBRyxLQUFLLENBQUE7QUFDYixjQUFJLGdCQUFHLFFBQVEsRUFBRSxLQUFLLE9BQU8sRUFBRTtBQUM3QixhQUFDLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUE7V0FDNUIsTUFBTTtBQUNMLGFBQUMsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQTtXQUM3Qjs7QUFFRCxjQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsRUFBRTtBQUNqQyxnQkFBSSxDQUFDLEtBQUssUUFBUSxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsa0JBQUssU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7QUFDM0QscUJBQU8sTUFBSyxNQUFNLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsa0JBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQTthQUNoRSxNQUFNO0FBQ0wscUJBQU8sTUFBSyxNQUFNLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO2FBQ2hDO1dBQ0YsTUFBTTtBQUNMLG1CQUFPLEtBQUssQ0FBQTtXQUNiO1NBQ0Y7T0FDRixDQUFDLENBQUE7O0FBRUYsVUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLGtCQUFLLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFO0FBQzFDLGVBQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxDQUFBO09BQ3pDOztBQUVELFVBQUksS0FBSyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsa0JBQUssU0FBUyxDQUFDLENBQUE7QUFDekMsVUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFBO0FBQ2YsV0FBSyxJQUFJLFFBQVEsSUFBSSxLQUFLLEVBQUU7QUFDMUIsZ0JBQVEsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDN0MsWUFBSSxNQUFNLEtBQUssRUFBRSxFQUFFO0FBQ2pCLGdCQUFNLEdBQUcsUUFBUSxDQUFBO1NBQ2xCLE1BQU07QUFDTCxnQkFBTSxHQUFHLE1BQU0sR0FBRyxrQkFBSyxTQUFTLEdBQUcsUUFBUSxDQUFBO1NBQzVDO09BQ0Y7O0FBRUQsYUFBTyxNQUFNLENBQUE7S0FDZDs7O1dBRW1CLDZCQUFDLFFBQVEsRUFBRTtBQUM3QixVQUFJLG9CQUFRLFFBQVEsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUU7QUFDL0MsZUFBTyxFQUFFLENBQUE7T0FDVjtBQUNELFVBQUksTUFBTSxHQUFHLGtCQUFLLE9BQU8sQ0FBQyxrQkFBSyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQTtBQUNuRCxhQUFPLE1BQU0sQ0FBQTtLQUNkOzs7V0FFSSxnQkFBRztBQUNOLGFBQU8sNkJBQVcsQ0FBQTtLQUNuQjs7O1NBaEVHLFVBQVU7OztRQWtFUixVQUFVLEdBQVYsVUFBVSIsImZpbGUiOiIvaG9tZS9zaGFuZS8uYXRvbS9wYWNrYWdlcy9nby1jb25maWcvbGliL3BhdGhoZWxwZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIGJhYmVsJ1xuXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJ1xuaW1wb3J0IG9zIGZyb20gJ29zJ1xuaW1wb3J0IG9zSG9tZWRpciBmcm9tICdvcy1ob21lZGlyJ1xuaW1wb3J0IHtpc0ZhbHN5fSBmcm9tICcuL2NoZWNrJ1xuXG5jbGFzcyBQYXRoSGVscGVyIHtcbiAgY29uc3RydWN0b3IgKCkge1xuICB9XG5cbiAgZXhwYW5kIChlbnYsIHRoZXBhdGgpIHtcbiAgICBpZiAoaXNGYWxzeSh0aGVwYXRoKSB8fCB0aGVwYXRoLnRyaW0oKSA9PT0gJycpIHtcbiAgICAgIHJldHVybiAnJ1xuICAgIH1cblxuICAgIGlmIChpc0ZhbHN5KGVudikpIHtcbiAgICAgIHJldHVybiB0aGVwYXRoXG4gICAgfVxuXG4gICAgdGhlcGF0aCA9IHRoZXBhdGgucmVwbGFjZSgvKH58XFwkW15cXFxcLzpdKnwlW15cXFxcOyVdKiUpKz8vZ2ltLCAodGV4dCwgbWF0Y2gpID0+IHtcbiAgICAgIGlmIChtYXRjaCA9PT0gJ34nKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmhvbWUoKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbGV0IG0gPSBtYXRjaFxuICAgICAgICBpZiAob3MucGxhdGZvcm0oKSA9PT0gJ3dpbjMyJykge1xuICAgICAgICAgIG0gPSBtYXRjaC5yZXBsYWNlKC8lL2csICcnKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG0gPSBtYXRjaC5yZXBsYWNlKC9cXCQvZywgJycpXG4gICAgICAgIH1cblxuICAgICAgICBpZiAodHlwZW9mIGVudlttXSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICBpZiAobSA9PT0gJ0dPUEFUSCcgJiYgZW52W21dLmluZGV4T2YocGF0aC5kZWxpbWl0ZXIpICE9PSAtMSkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZXhwYW5kKGVudiwgZW52W21dLnNwbGl0KHBhdGguZGVsaW1pdGVyKVswXS50cmltKCkpXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmV4cGFuZChlbnYsIGVudlttXSlcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIG1hdGNoXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuXG4gICAgaWYgKHRoZXBhdGguaW5kZXhPZihwYXRoLmRlbGltaXRlcikgPT09IC0xKSB7XG4gICAgICByZXR1cm4gdGhpcy5yZXNvbHZlQW5kTm9ybWFsaXplKHRoZXBhdGgpXG4gICAgfVxuXG4gICAgbGV0IHBhdGhzID0gdGhlcGF0aC5zcGxpdChwYXRoLmRlbGltaXRlcilcbiAgICBsZXQgcmVzdWx0ID0gJydcbiAgICBmb3IgKGxldCBwYXRoSXRlbSBvZiBwYXRocykge1xuICAgICAgcGF0aEl0ZW0gPSB0aGlzLnJlc29sdmVBbmROb3JtYWxpemUocGF0aEl0ZW0pXG4gICAgICBpZiAocmVzdWx0ID09PSAnJykge1xuICAgICAgICByZXN1bHQgPSBwYXRoSXRlbVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVzdWx0ID0gcmVzdWx0ICsgcGF0aC5kZWxpbWl0ZXIgKyBwYXRoSXRlbVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiByZXN1bHRcbiAgfVxuXG4gIHJlc29sdmVBbmROb3JtYWxpemUgKHBhdGhpdGVtKSB7XG4gICAgaWYgKGlzRmFsc3kocGF0aGl0ZW0pIHx8IHBhdGhpdGVtLnRyaW0oKSA9PT0gJycpIHtcbiAgICAgIHJldHVybiAnJ1xuICAgIH1cbiAgICBsZXQgcmVzdWx0ID0gcGF0aC5yZXNvbHZlKHBhdGgubm9ybWFsaXplKHBhdGhpdGVtKSlcbiAgICByZXR1cm4gcmVzdWx0XG4gIH1cblxuICBob21lICgpIHtcbiAgICByZXR1cm4gb3NIb21lZGlyKClcbiAgfVxufVxuZXhwb3J0IHtQYXRoSGVscGVyfVxuIl19
//# sourceURL=/home/shane/.atom/packages/go-config/lib/pathhelper.js
