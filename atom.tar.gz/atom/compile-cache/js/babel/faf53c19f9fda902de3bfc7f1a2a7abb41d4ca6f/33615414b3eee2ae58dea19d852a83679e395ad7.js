function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _libCheck = require('./../lib/check');

var _libExecutor = require('./../lib/executor');

var _libPathhelper = require('./../lib/pathhelper');

var _libLocator = require('./../lib/locator');

var _temp = require('temp');

var _temp2 = _interopRequireDefault(_temp);

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _os = require('os');

var _os2 = _interopRequireDefault(_os);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _touch = require('touch');

var _touch2 = _interopRequireDefault(_touch);

'use babel';

describe('Locator', function () {
  var env = null;
  var environmentFn = null;
  var executor = null;
  var platform = null;
  var arch = null;
  var executableSuffix = null;
  var pathhelper = null;
  var pathkey = null;
  var readyFn = null;
  var locator = null;

  beforeEach(function () {
    _temp2['default'].track();
    pathhelper = new _libPathhelper.PathHelper();
    env = process.env;
    if ((0, _libCheck.isTruthy)(env.GOROOT)) {
      delete env.GOROOT;
    }
    environmentFn = function () {
      return env;
    };
    readyFn = function () {
      return true;
    };
    platform = process.platform;
    if (process.arch === 'arm') {
      arch = 'arm';
    } else if (process.arch === 'ia32') {
      // Ugh, Atom is 32-bit on Windows... for now.
      if (platform === 'win32') {
        arch = 'amd64';
      } else {
        arch = '386';
      }
    } else {
      arch = 'amd64';
    }
    executor = new _libExecutor.Executor({ environmentFn: environmentFn });
    executableSuffix = '';
    pathkey = 'PATH';
    if (process.platform === 'win32') {
      platform = 'windows';
      executableSuffix = '.exe';
      pathkey = 'Path';
    }

    locator = new _libLocator.Locator({
      environment: environmentFn,
      executor: executor,
      ready: readyFn
    });
  });

  afterEach(function () {
    if (executor !== null) {
      executor.dispose();
      executor = null;
    }

    if (locator !== null) {
      locator.dispose();
      locator = null;
    }

    arch = null;
    platform = null;
    environmentFn = null;
    executableSuffix = null;
    pathkey = null;
    readyFn = null;
  });

  describe('when the environment is process.env', function () {
    it('findExecutablesInPath returns an empty array if its arguments are invalid', function () {
      expect(locator.findExecutablesInPath).toBeDefined();
      expect(locator.findExecutablesInPath(false, false).length).toBe(0);
      expect(locator.findExecutablesInPath('', false).length).toBe(0);
      expect(locator.findExecutablesInPath('abcd', false).length).toBe(0);
      expect(locator.findExecutablesInPath('abcd', { bleh: 'abcd' }).length).toBe(0);
      expect(locator.findExecutablesInPath('abcd', 'abcd').length).toBe(0);
      expect(locator.findExecutablesInPath('abcd', []).length).toBe(0);
      expect(locator.findExecutablesInPath([], []).length).toBe(0);
    });

    it('findExecutablesInPath returns an array with elements if its arguments are valid', function () {
      expect(locator.findExecutablesInPath).toBeDefined();
      if (_os2['default'].platform() === 'win32') {
        expect(locator.findExecutablesInPath('c:\\windows\\system32', ['cmd.exe']).length).toBe(1);
        expect(locator.findExecutablesInPath('c:\\windows\\system32', ['cmd.exe'])[0]).toBe('c:\\windows\\system32\\cmd.exe');
      } else {
        expect(locator.findExecutablesInPath('/bin', ['sh']).length).toBe(1);
        expect(locator.findExecutablesInPath('/bin', ['sh'])[0]).toBe('/bin/sh');
      }
    });
  });

  describe('when the environment has a GOPATH that includes a tilde', function () {
    beforeEach(function () {
      env.GOPATH = _path2['default'].join('~', 'go');
    });

    it('is defined', function () {
      expect(locator).toBeDefined();
      expect(locator).toBeTruthy();
    });

    it('gopath() returns a path with the home directory expanded', function () {
      expect(locator.gopath).toBeDefined();
      expect(locator.gopath()).toBe(_path2['default'].join(pathhelper.home(), 'go'));
    });
  });

  describe('when the environment has an empty GOPATH', function () {
    beforeEach(function () {
      if ((0, _libCheck.isTruthy)(env.GOPATH)) {
        delete env.GOPATH;
      }
    });

    it('gopath() returns false', function () {
      expect(locator.gopath).toBeDefined();
      expect(locator.gopath()).toBe(false);
    });
  });

  describe('when the environment has a GOPATH that is whitespace', function () {
    beforeEach(function () {
      env.GOPATH = '        ';
    });

    it('gopath() returns false', function () {
      expect(locator.gopath).toBeDefined();
      expect(locator.gopath()).toBe(false);
    });
  });

  describe('when the PATH has a single directory with a go runtime in it', function () {
    var godir = null;
    var go = null;
    beforeEach(function () {
      godir = _temp2['default'].mkdirSync('go-');
      go = _path2['default'].join(godir, 'go' + executableSuffix);
      _fsExtra2['default'].writeFileSync(go, '', { encoding: 'utf8', mode: 511 });
      env[pathkey] = godir;
      env.GOPATH = _path2['default'].join('~', 'go');
    });

    it('runtimeCandidates() finds the runtime', function () {
      expect(locator.runtimeCandidates).toBeDefined();
      var candidates = locator.runtimeCandidates();
      expect(candidates).toBeTruthy();
      expect(candidates.length).toBeGreaterThan(0);
      expect(candidates[0]).toBe(go);
    });
  });

  describe('when GOROOT is set and the go tool is available within $GOROOT/bin', function () {
    var godir = null;
    var go = null;
    var gorootgo = null;
    var gorootdir = null;
    var gorootbindir = null;

    beforeEach(function () {
      gorootdir = _temp2['default'].mkdirSync('goroot-');
      gorootbindir = _path2['default'].join(gorootdir, 'bin');
      _fsExtra2['default'].mkdirSync(gorootbindir);
      gorootgo = _path2['default'].join(gorootbindir, 'go' + executableSuffix);
      godir = _temp2['default'].mkdirSync('go-');
      go = _path2['default'].join(godir, 'go' + executableSuffix);
      _fsExtra2['default'].writeFileSync(gorootgo, '', { encoding: 'utf8', mode: 511 });
      _fsExtra2['default'].writeFileSync(go, '', { encoding: 'utf8', mode: 511 });
      env[pathkey] = godir;
      env.GOROOT = gorootdir;
      env.GOPATH = _path2['default'].join('~', 'go');
    });

    afterEach(function () {
      env.GOROOT = '';
    });

    it('runtimeCandidates() finds the runtime and orders the go in $GOROOT/bin before the go in PATH', function () {
      expect(locator.runtimeCandidates).toBeDefined();
      var candidates = locator.runtimeCandidates();
      expect(candidates).toBeTruthy();
      expect(candidates.length).toBeGreaterThan(0);
      expect(candidates[0]).toBe(gorootgo);
      expect(candidates[1]).toBe(go);
    });
  });

  describe('when the PATH has multiple directories with a go runtime in it', function () {
    var godir = null;
    var go1dir = null;
    var go = null;
    var go1 = null;
    beforeEach(function () {
      godir = _temp2['default'].mkdirSync('go-');
      go1dir = _temp2['default'].mkdirSync('go1-');
      go = _path2['default'].join(godir, 'go' + executableSuffix);
      go1 = _path2['default'].join(go1dir, 'go' + executableSuffix);
      _fsExtra2['default'].writeFileSync(go, '', { encoding: 'utf8', mode: 511 });
      _fsExtra2['default'].writeFileSync(go1, '', { encoding: 'utf8', mode: 511 });
      env[pathkey] = godir + _path2['default'].delimiter + go1dir;
    });

    it('runtimeCandidates() returns the candidates in the correct order', function () {
      expect(locator.runtimeCandidates).toBeDefined();
      var candidates = locator.runtimeCandidates();
      expect(candidates).toBeTruthy();
      expect(candidates.length).toBeGreaterThan(1);
      expect(candidates[0]).toBe(go);
      expect(candidates[1]).toBe(go1);
    });

    it('runtimeCandidates() returns candidates in the correct order when a candidate occurs multiple times in the path', function () {
      env[pathkey] = godir + _path2['default'].delimiter + go1dir + _path2['default'].delimiter + godir;
      expect(locator.runtimeCandidates).toBeDefined();
      var candidates = locator.runtimeCandidates();
      expect(candidates).toBeTruthy();
      expect(candidates.length).toBeGreaterThan(1);
      expect(candidates[0]).toBe(go);
      expect(candidates[1]).toBe(go1);
      if (candidates.length > 2) {
        expect(candidates[2]).not.toBe(go);
      }
    });
  });

  describe('when the path includes a directory with go 1.5.1 in it', function () {
    var godir = null;
    var gopathdir = null;
    var gorootdir = null;
    var gorootbindir = null;
    var gotooldir = null;
    var go = null;
    var gorootbintools = null;
    var gotooldirtools = null;
    beforeEach(function () {
      gorootbintools = ['go', 'godoc', 'gofmt'];
      gotooldirtools = ['addr2line', 'cgo', 'dist', 'link', 'pack', 'trace', 'api', 'compile', 'doc', 'nm', 'pprof', 'vet', 'asm', 'cover', 'fix', 'objdump', 'yacc'];
      godir = _temp2['default'].mkdirSync('go-');
      gopathdir = _temp2['default'].mkdirSync('gopath-');
      gorootdir = _temp2['default'].mkdirSync('goroot-');
      gorootbindir = _path2['default'].join(gorootdir, 'bin');
      _fsExtra2['default'].mkdirSync(gorootbindir);
      gotooldir = _path2['default'].join(gorootdir, 'pkg', 'tool', platform + '_' + arch);
      _fsExtra2['default'].mkdirsSync(gotooldir);
      var fakeexecutable = 'go_' + platform + '_' + arch + executableSuffix;
      var go151json = _path2['default'].join(__dirname, 'fixtures', 'go-151-' + platform + '.json');
      var fakego = _path2['default'].join(__dirname, 'tools', 'go', fakeexecutable);
      go = _path2['default'].join(gorootbindir, 'go' + executableSuffix);
      _fsExtra2['default'].copySync(fakego, go);
      _fsExtra2['default'].copySync(go151json, _path2['default'].join(gorootbindir, 'go.json'));
      env[pathkey] = godir;
      env['GOPATH'] = gopathdir;
      env['GOROOT'] = gorootdir;
      for (var tool of gorootbintools) {
        if (tool !== 'go') {
          _touch2['default'].sync(_path2['default'].join(gorootbindir, tool + executableSuffix));
        }
      }
      for (var tool of gotooldirtools) {
        var toolpath = _path2['default'].join(gotooldir, tool + executableSuffix);
        _touch2['default'].sync(toolpath);
      }
    });

    it('runtimeCandidates() finds the runtime', function () {
      expect(locator.runtimeCandidates).toBeDefined();
      var candidates = locator.runtimeCandidates();
      expect(candidates).toBeTruthy();
      expect(candidates.length).toBeGreaterThan(0);
      expect(candidates[0]).toBe(go);
    });

    it('runtimes() returns the runtime', function () {
      expect(locator.runtimes).toBeDefined();
      var runtimes = null;
      var done = locator.runtimes().then(function (r) {
        runtimes = r;
      });

      waitsForPromise(function () {
        return done;
      });

      runs(function () {
        expect(runtimes).toBeTruthy();
        expect(runtimes.length).toBeGreaterThan(0);
        expect(runtimes[0].name).toBe('go1.5.1');
        expect(runtimes[0].semver).toBe('1.5.1');
        expect(runtimes[0].version).toBe('go version go1.5.1 ' + platform + '/' + arch);
        expect(runtimes[0].path).toBe(go);
        expect(runtimes[0].GOARCH).toBe(arch);
        expect(runtimes[0].GOBIN).toBe('');
        if (platform === 'windows') {
          expect(runtimes[0].GOEXE).toBe('.exe');
        } else {
          expect(runtimes[0].GOEXE).toBe('');
        }
        expect(runtimes[0].GOHOSTARCH).toBe(arch);
        expect(runtimes[0].GOHOSTOS).toBe(platform);
        expect(runtimes[0].GOOS).toBe(platform);
        expect(runtimes[0].GOPATH).toBe(gopathdir);
        expect(runtimes[0].GORACE).toBe('');
        expect(runtimes[0].GOROOT).toBe(gorootdir);
        expect(runtimes[0].GOTOOLDIR).toBe(gotooldir);
        if (platform === 'windows') {
          expect(runtimes[0].CC).toBe('gcc');
          expect(runtimes[0].GOGCCFLAGS).toBe('-m64 -mthreads -fmessage-length=0');
          expect(runtimes[0].CXX).toBe('g++');
        } else if (platform === 'darwin') {
          expect(runtimes[0].CC).toBe('clang');
          expect(runtimes[0].GOGCCFLAGS).toBe('-fPIC -m64 -pthread -fno-caret-diagnostics -Qunused-arguments -fmessage-length=0 -fno-common');
          expect(runtimes[0].CXX).toBe('clang++');
        } else if (_os2['default'].platform() === 'linux') {
          expect(runtimes[0].CC).toBe('gcc');
          expect(runtimes[0].GOGCCFLAGS).toBe('-fPIC -m64 -pthread -fmessage-length=0');
          expect(runtimes[0].CXX).toBe('g++');
        }
        expect(runtimes[0].GO15VENDOREXPERIMENT).toBe('');
        expect(runtimes[0].CGO_ENABLED).toBe('1');
      });
    });

    it('findTool() finds the go tool', function () {
      expect(locator.findTool).toBeDefined();
      var tool = null;
      var err = null;
      var done = locator.findTool('go', false, null).then(function (t) {
        tool = t;
      })['catch'](function (e) {
        err = e;
      });

      waitsForPromise(function () {
        return done;
      });

      runs(function () {
        expect(err).toBe(null);
        expect(tool).toBeTruthy();
        expect(tool).toBe(_path2['default'].join(gorootbindir, 'go' + executableSuffix));
      });
    });

    it('findTool() finds tools in GOROOT', function () {
      var tools = ['go', 'godoc', 'gofmt'];
      var runtime = false;
      var tool = null;
      var toolPath = false;
      var done = locator.runtimeForProject(false).then(function (r) {
        runtime = r;
      });

      waitsForPromise(function () {
        return done;
      });

      runs(function () {
        for (var toolItem of tools) {
          tool = null;
          done = null;
          toolPath = _path2['default'].join(runtime.GOROOT, 'bin', toolItem + runtime.GOEXE);
          done = locator.findTool(toolItem, false, null).then(function (t) {
            tool = t;
          });
          waitsForPromise(function () {
            return done;
          });

          runs(function () {
            expect(tool).toBeTruthy();
            expect(tool).toBe(toolPath);
          });
        }
      });
    });

    it('stat() returns false for nonexistent files', function () {
      var stat = null;
      var done = locator.stat('nonexistentthing').then(function (s) {
        stat = s;
      });
      waitsForPromise(function () {
        return done;
      });

      runs(function () {
        expect(stat).toBe(false);
      });
    });

    it('findTool() finds tools in GOTOOLDIR', function () {
      var tools = ['addr2line', 'cgo', 'dist', 'link', 'pack', 'trace', 'api', 'compile', 'doc', 'nm', 'pprof', 'vet', 'asm', 'cover', 'fix', 'objdump', 'yacc'];
      var runtime = false;
      var done = locator.runtimeForProject(false).then(function (r) {
        runtime = r;
      });

      waitsForPromise(function () {
        return done;
      });

      runs(function () {
        var _loop = function (toolItem) {
          var tool = null;
          var toolPath = _path2['default'].join(runtime.GOTOOLDIR, toolItem + runtime.GOEXE);
          var done = locator.findTool(toolItem, false, null).then(function (t) {
            tool = t;
          });
          waitsForPromise(function () {
            return done;
          });

          runs(function () {
            expect(tool).toBeTruthy();
            expect(tool).toBe(toolPath);
          });
        };

        for (var toolItem of tools) {
          _loop(toolItem);
        }
      });
    });
  });

  describe('when the path includes a directory with the gometalinter tool in it', function () {
    var gopathdir = null;
    var gopathbindir = null;
    var pathdir = null;
    var pathtools = null;
    var gopathbintools = null;
    beforeEach(function () {
      pathtools = ['gometalinter', 'gb'];
      gopathbintools = ['somerandomtool', 'gb'];
      pathdir = _temp2['default'].mkdirSync('path-');
      gopathdir = _temp2['default'].mkdirSync('gopath-');
      gopathbindir = _path2['default'].join(gopathdir, 'bin');
      _fsExtra2['default'].mkdirSync(gopathbindir);
      env['GOPATH'] = gopathdir;
      env[pathkey] = pathdir + _path2['default'].delimiter + env['PATH'];
      for (var tool of pathtools) {
        _touch2['default'].sync(_path2['default'].join(pathdir, tool + executableSuffix));
      }
      for (var tool of gopathbintools) {
        _touch2['default'].sync(_path2['default'].join(gopathbindir, tool + executableSuffix));
      }
    });

    it('findTool() finds tools in PATH', function () {
      runs(function () {
        var _loop2 = function (toolItem) {
          var toolPath = false;
          var tool = null;
          var done = null;

          if (gopathbintools.indexOf(toolItem) !== -1) {
            toolPath = _path2['default'].join(gopathbindir, toolItem + executableSuffix);
          } else {
            toolPath = _path2['default'].join(pathdir, toolItem + executableSuffix);
          }

          done = locator.findTool(toolItem, false, null).then(function (t) {
            tool = t;
          });
          waitsForPromise(function () {
            return done;
          });
          runs(function () {
            done = null;
            expect(tool).toBeTruthy();
            expect(tool).toBe(toolPath);
          });
        };

        for (var toolItem of pathtools) {
          _loop2(toolItem);
        }
      });
    });

    it('findTool() finds tools in GOPATH\'s bin directory', function () {
      runs(function () {
        var _loop3 = function (toolItem) {
          var tool = null;
          var toolPath = false;
          var done = null;
          toolPath = _path2['default'].join(gopathbindir, toolItem + executableSuffix);
          done = locator.findTool(toolItem, false, null).then(function (t) {
            tool = t;
          });
          waitsForPromise(function () {
            return done;
          });
          runs(function () {
            expect(tool).toBeTruthy();
            expect(tool).toBe(toolPath);
          });
        };

        for (var toolItem of gopathbintools) {
          _loop3(toolItem);
        }
      });
    });
  });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL3NoYW5lLy5hdG9tL3BhY2thZ2VzL2dvLWNvbmZpZy9zcGVjL2xvY2F0b3Itc3BlYy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzt3QkFFdUIsZ0JBQWdCOzsyQkFDaEIsbUJBQW1COzs2QkFDakIscUJBQXFCOzswQkFDeEIsa0JBQWtCOztvQkFDdkIsTUFBTTs7Ozt1QkFDUixVQUFVOzs7O2tCQUNWLElBQUk7Ozs7b0JBQ0YsTUFBTTs7OztxQkFDTCxPQUFPOzs7O0FBVnpCLFdBQVcsQ0FBQTs7QUFZWCxRQUFRLENBQUMsU0FBUyxFQUFFLFlBQU07QUFDeEIsTUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFBO0FBQ2QsTUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFBO0FBQ3hCLE1BQUksUUFBUSxHQUFHLElBQUksQ0FBQTtBQUNuQixNQUFJLFFBQVEsR0FBRyxJQUFJLENBQUE7QUFDbkIsTUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFBO0FBQ2YsTUFBSSxnQkFBZ0IsR0FBRyxJQUFJLENBQUE7QUFDM0IsTUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFBO0FBQ3JCLE1BQUksT0FBTyxHQUFHLElBQUksQ0FBQTtBQUNsQixNQUFJLE9BQU8sR0FBRyxJQUFJLENBQUE7QUFDbEIsTUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFBOztBQUVsQixZQUFVLENBQUMsWUFBTTtBQUNmLHNCQUFLLEtBQUssRUFBRSxDQUFBO0FBQ1osY0FBVSxHQUFHLCtCQUFnQixDQUFBO0FBQzdCLE9BQUcsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFBO0FBQ2pCLFFBQUksd0JBQVMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQ3hCLGFBQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQTtLQUNsQjtBQUNELGlCQUFhLEdBQUcsWUFBTTtBQUNwQixhQUFPLEdBQUcsQ0FBQTtLQUNYLENBQUE7QUFDRCxXQUFPLEdBQUcsWUFBTTtBQUFFLGFBQU8sSUFBSSxDQUFBO0tBQUUsQ0FBQTtBQUMvQixZQUFRLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQTtBQUMzQixRQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssS0FBSyxFQUFFO0FBQzFCLFVBQUksR0FBRyxLQUFLLENBQUE7S0FDYixNQUFNLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7O0FBRWxDLFVBQUksUUFBUSxLQUFLLE9BQU8sRUFBRTtBQUN4QixZQUFJLEdBQUcsT0FBTyxDQUFBO09BQ2YsTUFBTTtBQUNMLFlBQUksR0FBRyxLQUFLLENBQUE7T0FDYjtLQUNGLE1BQU07QUFDTCxVQUFJLEdBQUcsT0FBTyxDQUFBO0tBQ2Y7QUFDRCxZQUFRLEdBQUcsMEJBQWEsRUFBQyxhQUFhLEVBQUUsYUFBYSxFQUFDLENBQUMsQ0FBQTtBQUN2RCxvQkFBZ0IsR0FBRyxFQUFFLENBQUE7QUFDckIsV0FBTyxHQUFHLE1BQU0sQ0FBQTtBQUNoQixRQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssT0FBTyxFQUFFO0FBQ2hDLGNBQVEsR0FBRyxTQUFTLENBQUE7QUFDcEIsc0JBQWdCLEdBQUcsTUFBTSxDQUFBO0FBQ3pCLGFBQU8sR0FBRyxNQUFNLENBQUE7S0FDakI7O0FBRUQsV0FBTyxHQUFHLHdCQUFZO0FBQ3BCLGlCQUFXLEVBQUUsYUFBYTtBQUMxQixjQUFRLEVBQUUsUUFBUTtBQUNsQixXQUFLLEVBQUUsT0FBTztLQUNmLENBQUMsQ0FBQTtHQUNILENBQUMsQ0FBQTs7QUFFRixXQUFTLENBQUMsWUFBTTtBQUNkLFFBQUksUUFBUSxLQUFLLElBQUksRUFBRTtBQUNyQixjQUFRLENBQUMsT0FBTyxFQUFFLENBQUE7QUFDbEIsY0FBUSxHQUFHLElBQUksQ0FBQTtLQUNoQjs7QUFFRCxRQUFJLE9BQU8sS0FBSyxJQUFJLEVBQUU7QUFDcEIsYUFBTyxDQUFDLE9BQU8sRUFBRSxDQUFBO0FBQ2pCLGFBQU8sR0FBRyxJQUFJLENBQUE7S0FDZjs7QUFFRCxRQUFJLEdBQUcsSUFBSSxDQUFBO0FBQ1gsWUFBUSxHQUFHLElBQUksQ0FBQTtBQUNmLGlCQUFhLEdBQUcsSUFBSSxDQUFBO0FBQ3BCLG9CQUFnQixHQUFHLElBQUksQ0FBQTtBQUN2QixXQUFPLEdBQUcsSUFBSSxDQUFBO0FBQ2QsV0FBTyxHQUFHLElBQUksQ0FBQTtHQUNmLENBQUMsQ0FBQTs7QUFFRixVQUFRLENBQUMscUNBQXFDLEVBQUUsWUFBTTtBQUNwRCxNQUFFLENBQUMsMkVBQTJFLEVBQUUsWUFBTTtBQUNwRixZQUFNLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUMsV0FBVyxFQUFFLENBQUE7QUFDbkQsWUFBTSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBQ2xFLFlBQU0sQ0FBQyxPQUFPLENBQUMscUJBQXFCLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUMvRCxZQUFNLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDbkUsWUFBTSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsRUFBQyxJQUFJLEVBQUUsTUFBTSxFQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDNUUsWUFBTSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBQ3BFLFlBQU0sQ0FBQyxPQUFPLENBQUMscUJBQXFCLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUNoRSxZQUFNLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7S0FDN0QsQ0FBQyxDQUFBOztBQUVGLE1BQUUsQ0FBQyxpRkFBaUYsRUFBRSxZQUFNO0FBQzFGLFlBQU0sQ0FBQyxPQUFPLENBQUMscUJBQXFCLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQTtBQUNuRCxVQUFJLGdCQUFHLFFBQVEsRUFBRSxLQUFLLE9BQU8sRUFBRTtBQUM3QixjQUFNLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLHVCQUF1QixFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDMUYsY0FBTSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyx1QkFBdUIsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0NBQWdDLENBQUMsQ0FBQTtPQUN0SCxNQUFNO0FBQ0wsY0FBTSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUNwRSxjQUFNLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUE7T0FDekU7S0FDRixDQUFDLENBQUE7R0FDSCxDQUFDLENBQUE7O0FBRUYsVUFBUSxDQUFDLHlEQUF5RCxFQUFFLFlBQU07QUFDeEUsY0FBVSxDQUFDLFlBQU07QUFDZixTQUFHLENBQUMsTUFBTSxHQUFHLGtCQUFLLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUE7S0FDbEMsQ0FBQyxDQUFBOztBQUVGLE1BQUUsQ0FBQyxZQUFZLEVBQUUsWUFBTTtBQUNyQixZQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUE7QUFDN0IsWUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFBO0tBQzdCLENBQUMsQ0FBQTs7QUFFRixNQUFFLENBQUMsMERBQTBELEVBQUUsWUFBTTtBQUNuRSxZQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFBO0FBQ3BDLFlBQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQUssSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFBO0tBQ2xFLENBQUMsQ0FBQTtHQUNILENBQUMsQ0FBQTs7QUFFRixVQUFRLENBQUMsMENBQTBDLEVBQUUsWUFBTTtBQUN6RCxjQUFVLENBQUMsWUFBTTtBQUNmLFVBQUksd0JBQVMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQ3hCLGVBQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQTtPQUNsQjtLQUNGLENBQUMsQ0FBQTs7QUFFRixNQUFFLENBQUMsd0JBQXdCLEVBQUUsWUFBTTtBQUNqQyxZQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFBO0FBQ3BDLFlBQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7S0FDckMsQ0FBQyxDQUFBO0dBQ0gsQ0FBQyxDQUFBOztBQUVGLFVBQVEsQ0FBQyxzREFBc0QsRUFBRSxZQUFNO0FBQ3JFLGNBQVUsQ0FBQyxZQUFNO0FBQ2YsU0FBRyxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUE7S0FDeEIsQ0FBQyxDQUFBOztBQUVGLE1BQUUsQ0FBQyx3QkFBd0IsRUFBRSxZQUFNO0FBQ2pDLFlBQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUE7QUFDcEMsWUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQTtLQUNyQyxDQUFDLENBQUE7R0FDSCxDQUFDLENBQUE7O0FBRUYsVUFBUSxDQUFDLDhEQUE4RCxFQUFFLFlBQU07QUFDN0UsUUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFBO0FBQ2hCLFFBQUksRUFBRSxHQUFHLElBQUksQ0FBQTtBQUNiLGNBQVUsQ0FBQyxZQUFNO0FBQ2YsV0FBSyxHQUFHLGtCQUFLLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQTtBQUM3QixRQUFFLEdBQUcsa0JBQUssSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQTtBQUM5QywyQkFBRyxhQUFhLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBQyxDQUFDLENBQUE7QUFDdkQsU0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEtBQUssQ0FBQTtBQUNwQixTQUFHLENBQUMsTUFBTSxHQUFHLGtCQUFLLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUE7S0FDbEMsQ0FBQyxDQUFBOztBQUVGLE1BQUUsQ0FBQyx1Q0FBdUMsRUFBRSxZQUFNO0FBQ2hELFlBQU0sQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQTtBQUMvQyxVQUFJLFVBQVUsR0FBRyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsQ0FBQTtBQUM1QyxZQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUE7QUFDL0IsWUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDNUMsWUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtLQUMvQixDQUFDLENBQUE7R0FDSCxDQUFDLENBQUE7O0FBRUYsVUFBUSxDQUFDLG9FQUFvRSxFQUFFLFlBQU07QUFDbkYsUUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFBO0FBQ2hCLFFBQUksRUFBRSxHQUFHLElBQUksQ0FBQTtBQUNiLFFBQUksUUFBUSxHQUFHLElBQUksQ0FBQTtBQUNuQixRQUFJLFNBQVMsR0FBRyxJQUFJLENBQUE7QUFDcEIsUUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFBOztBQUV2QixjQUFVLENBQUMsWUFBTTtBQUNmLGVBQVMsR0FBRyxrQkFBSyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUE7QUFDckMsa0JBQVksR0FBRyxrQkFBSyxJQUFJLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFBO0FBQzFDLDJCQUFHLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQTtBQUMxQixjQUFRLEdBQUcsa0JBQUssSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQTtBQUMzRCxXQUFLLEdBQUcsa0JBQUssU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQzdCLFFBQUUsR0FBRyxrQkFBSyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksR0FBRyxnQkFBZ0IsQ0FBQyxDQUFBO0FBQzlDLDJCQUFHLGFBQWEsQ0FBQyxRQUFRLEVBQUUsRUFBRSxFQUFFLEVBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFDLENBQUMsQ0FBQTtBQUM3RCwyQkFBRyxhQUFhLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBQyxDQUFDLENBQUE7QUFDdkQsU0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEtBQUssQ0FBQTtBQUNwQixTQUFHLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQTtBQUN0QixTQUFHLENBQUMsTUFBTSxHQUFHLGtCQUFLLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUE7S0FDbEMsQ0FBQyxDQUFBOztBQUVGLGFBQVMsQ0FBQyxZQUFNO0FBQ2QsU0FBRyxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUE7S0FDaEIsQ0FBQyxDQUFBOztBQUVGLE1BQUUsQ0FBQyw4RkFBOEYsRUFBRSxZQUFNO0FBQ3ZHLFlBQU0sQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQTtBQUMvQyxVQUFJLFVBQVUsR0FBRyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsQ0FBQTtBQUM1QyxZQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUE7QUFDL0IsWUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDNUMsWUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtBQUNwQyxZQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0tBQy9CLENBQUMsQ0FBQTtHQUNILENBQUMsQ0FBQTs7QUFFRixVQUFRLENBQUMsZ0VBQWdFLEVBQUUsWUFBTTtBQUMvRSxRQUFJLEtBQUssR0FBRyxJQUFJLENBQUE7QUFDaEIsUUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFBO0FBQ2pCLFFBQUksRUFBRSxHQUFHLElBQUksQ0FBQTtBQUNiLFFBQUksR0FBRyxHQUFHLElBQUksQ0FBQTtBQUNkLGNBQVUsQ0FBQyxZQUFNO0FBQ2YsV0FBSyxHQUFHLGtCQUFLLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQTtBQUM3QixZQUFNLEdBQUcsa0JBQUssU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQy9CLFFBQUUsR0FBRyxrQkFBSyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksR0FBRyxnQkFBZ0IsQ0FBQyxDQUFBO0FBQzlDLFNBQUcsR0FBRyxrQkFBSyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksR0FBRyxnQkFBZ0IsQ0FBQyxDQUFBO0FBQ2hELDJCQUFHLGFBQWEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFDLENBQUMsQ0FBQTtBQUN2RCwyQkFBRyxhQUFhLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBQyxDQUFDLENBQUE7QUFDeEQsU0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEtBQUssR0FBRyxrQkFBSyxTQUFTLEdBQUcsTUFBTSxDQUFBO0tBQy9DLENBQUMsQ0FBQTs7QUFFRixNQUFFLENBQUMsaUVBQWlFLEVBQUUsWUFBTTtBQUMxRSxZQUFNLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsV0FBVyxFQUFFLENBQUE7QUFDL0MsVUFBSSxVQUFVLEdBQUcsT0FBTyxDQUFDLGlCQUFpQixFQUFFLENBQUE7QUFDNUMsWUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFBO0FBQy9CLFlBQU0sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBQzVDLFlBQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUE7QUFDOUIsWUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTtLQUNoQyxDQUFDLENBQUE7O0FBRUYsTUFBRSxDQUFDLGdIQUFnSCxFQUFFLFlBQU07QUFDekgsU0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEtBQUssR0FBRyxrQkFBSyxTQUFTLEdBQUcsTUFBTSxHQUFHLGtCQUFLLFNBQVMsR0FBRyxLQUFLLENBQUE7QUFDdkUsWUFBTSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFBO0FBQy9DLFVBQUksVUFBVSxHQUFHLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxDQUFBO0FBQzVDLFlBQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQTtBQUMvQixZQUFNLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUM1QyxZQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQzlCLFlBQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDL0IsVUFBSSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtBQUN6QixjQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtPQUNuQztLQUNGLENBQUMsQ0FBQTtHQUNILENBQUMsQ0FBQTs7QUFFRixVQUFRLENBQUMsd0RBQXdELEVBQUUsWUFBTTtBQUN2RSxRQUFJLEtBQUssR0FBRyxJQUFJLENBQUE7QUFDaEIsUUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFBO0FBQ3BCLFFBQUksU0FBUyxHQUFHLElBQUksQ0FBQTtBQUNwQixRQUFJLFlBQVksR0FBRyxJQUFJLENBQUE7QUFDdkIsUUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFBO0FBQ3BCLFFBQUksRUFBRSxHQUFHLElBQUksQ0FBQTtBQUNiLFFBQUksY0FBYyxHQUFHLElBQUksQ0FBQTtBQUN6QixRQUFJLGNBQWMsR0FBRyxJQUFJLENBQUE7QUFDekIsY0FBVSxDQUFDLFlBQU07QUFDZixvQkFBYyxHQUFHLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQTtBQUN6QyxvQkFBYyxHQUFHLENBQUMsV0FBVyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFBO0FBQy9KLFdBQUssR0FBRyxrQkFBSyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDN0IsZUFBUyxHQUFHLGtCQUFLLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQTtBQUNyQyxlQUFTLEdBQUcsa0JBQUssU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFBO0FBQ3JDLGtCQUFZLEdBQUcsa0JBQUssSUFBSSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQTtBQUMxQywyQkFBRyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUE7QUFDMUIsZUFBUyxHQUFHLGtCQUFLLElBQUksQ0FBQyxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxRQUFRLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFBO0FBQ3RFLDJCQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQTtBQUN4QixVQUFJLGNBQWMsR0FBRyxLQUFLLEdBQUcsUUFBUSxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsZ0JBQWdCLENBQUE7QUFDckUsVUFBSSxTQUFTLEdBQUcsa0JBQUssSUFBSSxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsU0FBUyxHQUFHLFFBQVEsR0FBRyxPQUFPLENBQUMsQ0FBQTtBQUNoRixVQUFJLE1BQU0sR0FBRyxrQkFBSyxJQUFJLENBQUMsU0FBUyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUE7QUFDaEUsUUFBRSxHQUFHLGtCQUFLLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxHQUFHLGdCQUFnQixDQUFDLENBQUE7QUFDckQsMkJBQUcsUUFBUSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQTtBQUN2QiwyQkFBRyxRQUFRLENBQUMsU0FBUyxFQUFFLGtCQUFLLElBQUksQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQTtBQUMxRCxTQUFHLENBQUMsT0FBTyxDQUFDLEdBQUcsS0FBSyxDQUFBO0FBQ3BCLFNBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxTQUFTLENBQUE7QUFDekIsU0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLFNBQVMsQ0FBQTtBQUN6QixXQUFLLElBQUksSUFBSSxJQUFJLGNBQWMsRUFBRTtBQUMvQixZQUFJLElBQUksS0FBSyxJQUFJLEVBQUU7QUFDakIsNkJBQU0sSUFBSSxDQUFDLGtCQUFLLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxHQUFHLGdCQUFnQixDQUFDLENBQUMsQ0FBQTtTQUM3RDtPQUNGO0FBQ0QsV0FBSyxJQUFJLElBQUksSUFBSSxjQUFjLEVBQUU7QUFDL0IsWUFBSSxRQUFRLEdBQUcsa0JBQUssSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQTtBQUM1RCwyQkFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7T0FDckI7S0FDRixDQUFDLENBQUE7O0FBRUYsTUFBRSxDQUFDLHVDQUF1QyxFQUFFLFlBQU07QUFDaEQsWUFBTSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFBO0FBQy9DLFVBQUksVUFBVSxHQUFHLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxDQUFBO0FBQzVDLFlBQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQTtBQUMvQixZQUFNLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUM1QyxZQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0tBQy9CLENBQUMsQ0FBQTs7QUFFRixNQUFFLENBQUMsZ0NBQWdDLEVBQUUsWUFBTTtBQUN6QyxZQUFNLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFBO0FBQ3RDLFVBQUksUUFBUSxHQUFHLElBQUksQ0FBQTtBQUNuQixVQUFJLElBQUksR0FBRyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQUUsZ0JBQVEsR0FBRyxDQUFDLENBQUE7T0FBRSxDQUFDLENBQUE7O0FBRTNELHFCQUFlLENBQUMsWUFBTTtBQUFFLGVBQU8sSUFBSSxDQUFBO09BQUUsQ0FBQyxDQUFBOztBQUV0QyxVQUFJLENBQUMsWUFBTTtBQUNULGNBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQTtBQUM3QixjQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQTtBQUMxQyxjQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQTtBQUN4QyxjQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtBQUN4QyxjQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxRQUFRLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFBO0FBQy9FLGNBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ2pDLGNBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ3JDLGNBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ2xDLFlBQUksUUFBUSxLQUFLLFNBQVMsRUFBRTtBQUMxQixnQkFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7U0FDdkMsTUFBTTtBQUNMLGdCQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtTQUNuQztBQUNELGNBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ3pDLGNBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQzNDLGNBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQ3ZDLGNBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFBO0FBQzFDLGNBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ25DLGNBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFBO0FBQzFDLGNBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFBO0FBQzdDLFlBQUksUUFBUSxLQUFLLFNBQVMsRUFBRTtBQUMxQixnQkFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDbEMsZ0JBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxDQUFDLENBQUE7QUFDeEUsZ0JBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO1NBQ3BDLE1BQU0sSUFBSSxRQUFRLEtBQUssUUFBUSxFQUFFO0FBQ2hDLGdCQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtBQUNwQyxnQkFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsOEZBQThGLENBQUMsQ0FBQTtBQUNuSSxnQkFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUE7U0FDeEMsTUFBTSxJQUFJLGdCQUFHLFFBQVEsRUFBRSxLQUFLLE9BQU8sRUFBRTtBQUNwQyxnQkFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDbEMsZ0JBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLHdDQUF3QyxDQUFDLENBQUE7QUFDN0UsZ0JBQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO1NBQ3BDO0FBQ0QsY0FBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtBQUNqRCxjQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTtPQUMxQyxDQUFDLENBQUE7S0FDSCxDQUFDLENBQUE7O0FBRUYsTUFBRSxDQUFDLDhCQUE4QixFQUFFLFlBQU07QUFDdkMsWUFBTSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQTtBQUN0QyxVQUFJLElBQUksR0FBRyxJQUFJLENBQUE7QUFDZixVQUFJLEdBQUcsR0FBRyxJQUFJLENBQUE7QUFDZCxVQUFJLElBQUksR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQUUsWUFBSSxHQUFHLENBQUMsQ0FBQTtPQUFFLENBQUMsU0FBTSxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQUUsV0FBRyxHQUFHLENBQUMsQ0FBQTtPQUFFLENBQUMsQ0FBQTs7QUFFbEcscUJBQWUsQ0FBQyxZQUFNO0FBQUUsZUFBTyxJQUFJLENBQUE7T0FBRSxDQUFDLENBQUE7O0FBRXRDLFVBQUksQ0FBQyxZQUFNO0FBQ1QsY0FBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTtBQUN0QixjQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUE7QUFDekIsY0FBTSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBSyxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUE7T0FDcEUsQ0FBQyxDQUFBO0tBQ0gsQ0FBQyxDQUFBOztBQUVGLE1BQUUsQ0FBQyxrQ0FBa0MsRUFBRSxZQUFNO0FBQzNDLFVBQUksS0FBSyxHQUFHLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQTtBQUNwQyxVQUFJLE9BQU8sR0FBRyxLQUFLLENBQUE7QUFDbkIsVUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFBO0FBQ2YsVUFBSSxRQUFRLEdBQUcsS0FBSyxDQUFBO0FBQ3BCLFVBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxDQUFDLEVBQUs7QUFBRSxlQUFPLEdBQUcsQ0FBQyxDQUFBO09BQUUsQ0FBQyxDQUFBOztBQUV4RSxxQkFBZSxDQUFDLFlBQU07QUFBRSxlQUFPLElBQUksQ0FBQTtPQUFFLENBQUMsQ0FBQTs7QUFFdEMsVUFBSSxDQUFDLFlBQU07QUFDVCxhQUFLLElBQUksUUFBUSxJQUFJLEtBQUssRUFBRTtBQUMxQixjQUFJLEdBQUcsSUFBSSxDQUFBO0FBQ1gsY0FBSSxHQUFHLElBQUksQ0FBQTtBQUNYLGtCQUFRLEdBQUcsa0JBQUssSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLFFBQVEsR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDckUsY0FBSSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxDQUFDLEVBQUs7QUFBRSxnQkFBSSxHQUFHLENBQUMsQ0FBQTtXQUFFLENBQUMsQ0FBQTtBQUN4RSx5QkFBZSxDQUFDLFlBQU07QUFBRSxtQkFBTyxJQUFJLENBQUE7V0FBRSxDQUFDLENBQUE7O0FBRXRDLGNBQUksQ0FBQyxZQUFNO0FBQ1Qsa0JBQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQTtBQUN6QixrQkFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtXQUM1QixDQUFDLENBQUE7U0FDSDtPQUNGLENBQUMsQ0FBQTtLQUNILENBQUMsQ0FBQTs7QUFFRixNQUFFLENBQUMsNENBQTRDLEVBQUUsWUFBTTtBQUNyRCxVQUFJLElBQUksR0FBRyxJQUFJLENBQUE7QUFDZixVQUFJLElBQUksR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQUUsWUFBSSxHQUFHLENBQUMsQ0FBQTtPQUFFLENBQUMsQ0FBQTtBQUNyRSxxQkFBZSxDQUFDLFlBQU07QUFBRSxlQUFPLElBQUksQ0FBQTtPQUFFLENBQUMsQ0FBQTs7QUFFdEMsVUFBSSxDQUFDLFlBQU07QUFDVCxjQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO09BQ3pCLENBQUMsQ0FBQTtLQUNILENBQUMsQ0FBQTs7QUFFRixNQUFFLENBQUMscUNBQXFDLEVBQUUsWUFBTTtBQUM5QyxVQUFJLEtBQUssR0FBRyxDQUFDLFdBQVcsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQTtBQUMxSixVQUFJLE9BQU8sR0FBRyxLQUFLLENBQUE7QUFDbkIsVUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFDLENBQUMsRUFBSztBQUFFLGVBQU8sR0FBRyxDQUFDLENBQUE7T0FBRSxDQUFDLENBQUE7O0FBRXhFLHFCQUFlLENBQUMsWUFBTTtBQUFFLGVBQU8sSUFBSSxDQUFBO09BQUUsQ0FBQyxDQUFBOztBQUV0QyxVQUFJLENBQUMsWUFBTTs4QkFDQSxRQUFRO0FBQ2YsY0FBSSxJQUFJLEdBQUcsSUFBSSxDQUFBO0FBQ2YsY0FBSSxRQUFRLEdBQUcsa0JBQUssSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsUUFBUSxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQTtBQUNyRSxjQUFJLElBQUksR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQUUsZ0JBQUksR0FBRyxDQUFDLENBQUE7V0FBRSxDQUFDLENBQUE7QUFDNUUseUJBQWUsQ0FBQyxZQUFNO0FBQUUsbUJBQU8sSUFBSSxDQUFBO1dBQUUsQ0FBQyxDQUFBOztBQUV0QyxjQUFJLENBQUMsWUFBTTtBQUNULGtCQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUE7QUFDekIsa0JBQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7V0FDNUIsQ0FBQyxDQUFBOzs7QUFUSixhQUFLLElBQUksUUFBUSxJQUFJLEtBQUssRUFBRTtnQkFBbkIsUUFBUTtTQVVoQjtPQUNGLENBQUMsQ0FBQTtLQUNILENBQUMsQ0FBQTtHQUNILENBQUMsQ0FBQTs7QUFFRixVQUFRLENBQUMscUVBQXFFLEVBQUUsWUFBTTtBQUNwRixRQUFJLFNBQVMsR0FBRyxJQUFJLENBQUE7QUFDcEIsUUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFBO0FBQ3ZCLFFBQUksT0FBTyxHQUFHLElBQUksQ0FBQTtBQUNsQixRQUFJLFNBQVMsR0FBRyxJQUFJLENBQUE7QUFDcEIsUUFBSSxjQUFjLEdBQUcsSUFBSSxDQUFBO0FBQ3pCLGNBQVUsQ0FBQyxZQUFNO0FBQ2YsZUFBUyxHQUFHLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFBO0FBQ2xDLG9CQUFjLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsQ0FBQTtBQUN6QyxhQUFPLEdBQUcsa0JBQUssU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFBO0FBQ2pDLGVBQVMsR0FBRyxrQkFBSyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUE7QUFDckMsa0JBQVksR0FBRyxrQkFBSyxJQUFJLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFBO0FBQzFDLDJCQUFHLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQTtBQUMxQixTQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsU0FBUyxDQUFBO0FBQ3pCLFNBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxPQUFPLEdBQUcsa0JBQUssU0FBUyxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQTtBQUNyRCxXQUFLLElBQUksSUFBSSxJQUFJLFNBQVMsRUFBRTtBQUMxQiwyQkFBTSxJQUFJLENBQUMsa0JBQUssSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxDQUFBO09BQ3hEO0FBQ0QsV0FBSyxJQUFJLElBQUksSUFBSSxjQUFjLEVBQUU7QUFDL0IsMkJBQU0sSUFBSSxDQUFDLGtCQUFLLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxHQUFHLGdCQUFnQixDQUFDLENBQUMsQ0FBQTtPQUM3RDtLQUNGLENBQUMsQ0FBQTs7QUFFRixNQUFFLENBQUMsZ0NBQWdDLEVBQUUsWUFBTTtBQUN6QyxVQUFJLENBQUMsWUFBTTsrQkFDQSxRQUFRO0FBQ2YsY0FBSSxRQUFRLEdBQUcsS0FBSyxDQUFBO0FBQ3BCLGNBQUksSUFBSSxHQUFHLElBQUksQ0FBQTtBQUNmLGNBQUksSUFBSSxHQUFHLElBQUksQ0FBQTs7QUFFZixjQUFJLGNBQWMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7QUFDM0Msb0JBQVEsR0FBRyxrQkFBSyxJQUFJLENBQUMsWUFBWSxFQUFFLFFBQVEsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFBO1dBQ2hFLE1BQU07QUFDTCxvQkFBUSxHQUFHLGtCQUFLLElBQUksQ0FBQyxPQUFPLEVBQUUsUUFBUSxHQUFHLGdCQUFnQixDQUFDLENBQUE7V0FDM0Q7O0FBRUQsY0FBSSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxDQUFDLEVBQUs7QUFDekQsZ0JBQUksR0FBRyxDQUFDLENBQUE7V0FDVCxDQUFDLENBQUE7QUFDRix5QkFBZSxDQUFDLFlBQU07QUFBRSxtQkFBTyxJQUFJLENBQUE7V0FBRSxDQUFDLENBQUE7QUFDdEMsY0FBSSxDQUFDLFlBQU07QUFDVCxnQkFBSSxHQUFHLElBQUksQ0FBQTtBQUNYLGtCQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUE7QUFDekIsa0JBQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7V0FDNUIsQ0FBQyxDQUFBOzs7QUFuQkosYUFBSyxJQUFJLFFBQVEsSUFBSSxTQUFTLEVBQUU7aUJBQXZCLFFBQVE7U0FvQmhCO09BQ0YsQ0FBQyxDQUFBO0tBQ0gsQ0FBQyxDQUFBOztBQUVGLE1BQUUsQ0FBQyxtREFBbUQsRUFBRSxZQUFNO0FBQzVELFVBQUksQ0FBQyxZQUFNOytCQUNBLFFBQVE7QUFDZixjQUFJLElBQUksR0FBRyxJQUFJLENBQUE7QUFDZixjQUFJLFFBQVEsR0FBRyxLQUFLLENBQUE7QUFDcEIsY0FBSSxJQUFJLEdBQUcsSUFBSSxDQUFBO0FBQ2Ysa0JBQVEsR0FBRyxrQkFBSyxJQUFJLENBQUMsWUFBWSxFQUFFLFFBQVEsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFBO0FBQy9ELGNBQUksR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQUUsZ0JBQUksR0FBRyxDQUFDLENBQUE7V0FBRSxDQUFDLENBQUE7QUFDeEUseUJBQWUsQ0FBQyxZQUFNO0FBQUUsbUJBQU8sSUFBSSxDQUFBO1dBQUUsQ0FBQyxDQUFBO0FBQ3RDLGNBQUksQ0FBQyxZQUFNO0FBQ1Qsa0JBQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQTtBQUN6QixrQkFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtXQUM1QixDQUFDLENBQUE7OztBQVZKLGFBQUssSUFBSSxRQUFRLElBQUksY0FBYyxFQUFFO2lCQUE1QixRQUFRO1NBV2hCO09BQ0YsQ0FBQyxDQUFBO0tBQ0gsQ0FBQyxDQUFBO0dBQ0gsQ0FBQyxDQUFBO0NBQ0gsQ0FBQyxDQUFBIiwiZmlsZSI6Ii9ob21lL3NoYW5lLy5hdG9tL3BhY2thZ2VzL2dvLWNvbmZpZy9zcGVjL2xvY2F0b3Itc3BlYy5qcyIsInNvdXJjZXNDb250ZW50IjpbIid1c2UgYmFiZWwnXG5cbmltcG9ydCB7aXNUcnV0aHl9IGZyb20gJy4vLi4vbGliL2NoZWNrJ1xuaW1wb3J0IHtFeGVjdXRvcn0gZnJvbSAnLi8uLi9saWIvZXhlY3V0b3InXG5pbXBvcnQge1BhdGhIZWxwZXJ9IGZyb20gJy4vLi4vbGliL3BhdGhoZWxwZXInXG5pbXBvcnQge0xvY2F0b3J9IGZyb20gJy4vLi4vbGliL2xvY2F0b3InXG5pbXBvcnQgdGVtcCBmcm9tICd0ZW1wJ1xuaW1wb3J0IGZzIGZyb20gJ2ZzLWV4dHJhJ1xuaW1wb3J0IG9zIGZyb20gJ29zJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcbmltcG9ydCB0b3VjaCBmcm9tICd0b3VjaCdcblxuZGVzY3JpYmUoJ0xvY2F0b3InLCAoKSA9PiB7XG4gIGxldCBlbnYgPSBudWxsXG4gIGxldCBlbnZpcm9ubWVudEZuID0gbnVsbFxuICBsZXQgZXhlY3V0b3IgPSBudWxsXG4gIGxldCBwbGF0Zm9ybSA9IG51bGxcbiAgbGV0IGFyY2ggPSBudWxsXG4gIGxldCBleGVjdXRhYmxlU3VmZml4ID0gbnVsbFxuICBsZXQgcGF0aGhlbHBlciA9IG51bGxcbiAgbGV0IHBhdGhrZXkgPSBudWxsXG4gIGxldCByZWFkeUZuID0gbnVsbFxuICBsZXQgbG9jYXRvciA9IG51bGxcblxuICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICB0ZW1wLnRyYWNrKClcbiAgICBwYXRoaGVscGVyID0gbmV3IFBhdGhIZWxwZXIoKVxuICAgIGVudiA9IHByb2Nlc3MuZW52XG4gICAgaWYgKGlzVHJ1dGh5KGVudi5HT1JPT1QpKSB7XG4gICAgICBkZWxldGUgZW52LkdPUk9PVFxuICAgIH1cbiAgICBlbnZpcm9ubWVudEZuID0gKCkgPT4ge1xuICAgICAgcmV0dXJuIGVudlxuICAgIH1cbiAgICByZWFkeUZuID0gKCkgPT4geyByZXR1cm4gdHJ1ZSB9XG4gICAgcGxhdGZvcm0gPSBwcm9jZXNzLnBsYXRmb3JtXG4gICAgaWYgKHByb2Nlc3MuYXJjaCA9PT0gJ2FybScpIHtcbiAgICAgIGFyY2ggPSAnYXJtJ1xuICAgIH0gZWxzZSBpZiAocHJvY2Vzcy5hcmNoID09PSAnaWEzMicpIHtcbiAgICAgIC8vIFVnaCwgQXRvbSBpcyAzMi1iaXQgb24gV2luZG93cy4uLiBmb3Igbm93LlxuICAgICAgaWYgKHBsYXRmb3JtID09PSAnd2luMzInKSB7XG4gICAgICAgIGFyY2ggPSAnYW1kNjQnXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhcmNoID0gJzM4NidcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgYXJjaCA9ICdhbWQ2NCdcbiAgICB9XG4gICAgZXhlY3V0b3IgPSBuZXcgRXhlY3V0b3Ioe2Vudmlyb25tZW50Rm46IGVudmlyb25tZW50Rm59KVxuICAgIGV4ZWN1dGFibGVTdWZmaXggPSAnJ1xuICAgIHBhdGhrZXkgPSAnUEFUSCdcbiAgICBpZiAocHJvY2Vzcy5wbGF0Zm9ybSA9PT0gJ3dpbjMyJykge1xuICAgICAgcGxhdGZvcm0gPSAnd2luZG93cydcbiAgICAgIGV4ZWN1dGFibGVTdWZmaXggPSAnLmV4ZSdcbiAgICAgIHBhdGhrZXkgPSAnUGF0aCdcbiAgICB9XG5cbiAgICBsb2NhdG9yID0gbmV3IExvY2F0b3Ioe1xuICAgICAgZW52aXJvbm1lbnQ6IGVudmlyb25tZW50Rm4sXG4gICAgICBleGVjdXRvcjogZXhlY3V0b3IsXG4gICAgICByZWFkeTogcmVhZHlGblxuICAgIH0pXG4gIH0pXG5cbiAgYWZ0ZXJFYWNoKCgpID0+IHtcbiAgICBpZiAoZXhlY3V0b3IgIT09IG51bGwpIHtcbiAgICAgIGV4ZWN1dG9yLmRpc3Bvc2UoKVxuICAgICAgZXhlY3V0b3IgPSBudWxsXG4gICAgfVxuXG4gICAgaWYgKGxvY2F0b3IgIT09IG51bGwpIHtcbiAgICAgIGxvY2F0b3IuZGlzcG9zZSgpXG4gICAgICBsb2NhdG9yID0gbnVsbFxuICAgIH1cblxuICAgIGFyY2ggPSBudWxsXG4gICAgcGxhdGZvcm0gPSBudWxsXG4gICAgZW52aXJvbm1lbnRGbiA9IG51bGxcbiAgICBleGVjdXRhYmxlU3VmZml4ID0gbnVsbFxuICAgIHBhdGhrZXkgPSBudWxsXG4gICAgcmVhZHlGbiA9IG51bGxcbiAgfSlcblxuICBkZXNjcmliZSgnd2hlbiB0aGUgZW52aXJvbm1lbnQgaXMgcHJvY2Vzcy5lbnYnLCAoKSA9PiB7XG4gICAgaXQoJ2ZpbmRFeGVjdXRhYmxlc0luUGF0aCByZXR1cm5zIGFuIGVtcHR5IGFycmF5IGlmIGl0cyBhcmd1bWVudHMgYXJlIGludmFsaWQnLCAoKSA9PiB7XG4gICAgICBleHBlY3QobG9jYXRvci5maW5kRXhlY3V0YWJsZXNJblBhdGgpLnRvQmVEZWZpbmVkKClcbiAgICAgIGV4cGVjdChsb2NhdG9yLmZpbmRFeGVjdXRhYmxlc0luUGF0aChmYWxzZSwgZmFsc2UpLmxlbmd0aCkudG9CZSgwKVxuICAgICAgZXhwZWN0KGxvY2F0b3IuZmluZEV4ZWN1dGFibGVzSW5QYXRoKCcnLCBmYWxzZSkubGVuZ3RoKS50b0JlKDApXG4gICAgICBleHBlY3QobG9jYXRvci5maW5kRXhlY3V0YWJsZXNJblBhdGgoJ2FiY2QnLCBmYWxzZSkubGVuZ3RoKS50b0JlKDApXG4gICAgICBleHBlY3QobG9jYXRvci5maW5kRXhlY3V0YWJsZXNJblBhdGgoJ2FiY2QnLCB7YmxlaDogJ2FiY2QnfSkubGVuZ3RoKS50b0JlKDApXG4gICAgICBleHBlY3QobG9jYXRvci5maW5kRXhlY3V0YWJsZXNJblBhdGgoJ2FiY2QnLCAnYWJjZCcpLmxlbmd0aCkudG9CZSgwKVxuICAgICAgZXhwZWN0KGxvY2F0b3IuZmluZEV4ZWN1dGFibGVzSW5QYXRoKCdhYmNkJywgW10pLmxlbmd0aCkudG9CZSgwKVxuICAgICAgZXhwZWN0KGxvY2F0b3IuZmluZEV4ZWN1dGFibGVzSW5QYXRoKFtdLCBbXSkubGVuZ3RoKS50b0JlKDApXG4gICAgfSlcblxuICAgIGl0KCdmaW5kRXhlY3V0YWJsZXNJblBhdGggcmV0dXJucyBhbiBhcnJheSB3aXRoIGVsZW1lbnRzIGlmIGl0cyBhcmd1bWVudHMgYXJlIHZhbGlkJywgKCkgPT4ge1xuICAgICAgZXhwZWN0KGxvY2F0b3IuZmluZEV4ZWN1dGFibGVzSW5QYXRoKS50b0JlRGVmaW5lZCgpXG4gICAgICBpZiAob3MucGxhdGZvcm0oKSA9PT0gJ3dpbjMyJykge1xuICAgICAgICBleHBlY3QobG9jYXRvci5maW5kRXhlY3V0YWJsZXNJblBhdGgoJ2M6XFxcXHdpbmRvd3NcXFxcc3lzdGVtMzInLCBbJ2NtZC5leGUnXSkubGVuZ3RoKS50b0JlKDEpXG4gICAgICAgIGV4cGVjdChsb2NhdG9yLmZpbmRFeGVjdXRhYmxlc0luUGF0aCgnYzpcXFxcd2luZG93c1xcXFxzeXN0ZW0zMicsIFsnY21kLmV4ZSddKVswXSkudG9CZSgnYzpcXFxcd2luZG93c1xcXFxzeXN0ZW0zMlxcXFxjbWQuZXhlJylcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGV4cGVjdChsb2NhdG9yLmZpbmRFeGVjdXRhYmxlc0luUGF0aCgnL2JpbicsIFsnc2gnXSkubGVuZ3RoKS50b0JlKDEpXG4gICAgICAgIGV4cGVjdChsb2NhdG9yLmZpbmRFeGVjdXRhYmxlc0luUGF0aCgnL2JpbicsIFsnc2gnXSlbMF0pLnRvQmUoJy9iaW4vc2gnKVxuICAgICAgfVxuICAgIH0pXG4gIH0pXG5cbiAgZGVzY3JpYmUoJ3doZW4gdGhlIGVudmlyb25tZW50IGhhcyBhIEdPUEFUSCB0aGF0IGluY2x1ZGVzIGEgdGlsZGUnLCAoKSA9PiB7XG4gICAgYmVmb3JlRWFjaCgoKSA9PiB7XG4gICAgICBlbnYuR09QQVRIID0gcGF0aC5qb2luKCd+JywgJ2dvJylcbiAgICB9KVxuXG4gICAgaXQoJ2lzIGRlZmluZWQnLCAoKSA9PiB7XG4gICAgICBleHBlY3QobG9jYXRvcikudG9CZURlZmluZWQoKVxuICAgICAgZXhwZWN0KGxvY2F0b3IpLnRvQmVUcnV0aHkoKVxuICAgIH0pXG5cbiAgICBpdCgnZ29wYXRoKCkgcmV0dXJucyBhIHBhdGggd2l0aCB0aGUgaG9tZSBkaXJlY3RvcnkgZXhwYW5kZWQnLCAoKSA9PiB7XG4gICAgICBleHBlY3QobG9jYXRvci5nb3BhdGgpLnRvQmVEZWZpbmVkKClcbiAgICAgIGV4cGVjdChsb2NhdG9yLmdvcGF0aCgpKS50b0JlKHBhdGguam9pbihwYXRoaGVscGVyLmhvbWUoKSwgJ2dvJykpXG4gICAgfSlcbiAgfSlcblxuICBkZXNjcmliZSgnd2hlbiB0aGUgZW52aXJvbm1lbnQgaGFzIGFuIGVtcHR5IEdPUEFUSCcsICgpID0+IHtcbiAgICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICAgIGlmIChpc1RydXRoeShlbnYuR09QQVRIKSkge1xuICAgICAgICBkZWxldGUgZW52LkdPUEFUSFxuICAgICAgfVxuICAgIH0pXG5cbiAgICBpdCgnZ29wYXRoKCkgcmV0dXJucyBmYWxzZScsICgpID0+IHtcbiAgICAgIGV4cGVjdChsb2NhdG9yLmdvcGF0aCkudG9CZURlZmluZWQoKVxuICAgICAgZXhwZWN0KGxvY2F0b3IuZ29wYXRoKCkpLnRvQmUoZmFsc2UpXG4gICAgfSlcbiAgfSlcblxuICBkZXNjcmliZSgnd2hlbiB0aGUgZW52aXJvbm1lbnQgaGFzIGEgR09QQVRIIHRoYXQgaXMgd2hpdGVzcGFjZScsICgpID0+IHtcbiAgICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICAgIGVudi5HT1BBVEggPSAnICAgICAgICAnXG4gICAgfSlcblxuICAgIGl0KCdnb3BhdGgoKSByZXR1cm5zIGZhbHNlJywgKCkgPT4ge1xuICAgICAgZXhwZWN0KGxvY2F0b3IuZ29wYXRoKS50b0JlRGVmaW5lZCgpXG4gICAgICBleHBlY3QobG9jYXRvci5nb3BhdGgoKSkudG9CZShmYWxzZSlcbiAgICB9KVxuICB9KVxuXG4gIGRlc2NyaWJlKCd3aGVuIHRoZSBQQVRIIGhhcyBhIHNpbmdsZSBkaXJlY3Rvcnkgd2l0aCBhIGdvIHJ1bnRpbWUgaW4gaXQnLCAoKSA9PiB7XG4gICAgbGV0IGdvZGlyID0gbnVsbFxuICAgIGxldCBnbyA9IG51bGxcbiAgICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICAgIGdvZGlyID0gdGVtcC5ta2RpclN5bmMoJ2dvLScpXG4gICAgICBnbyA9IHBhdGguam9pbihnb2RpciwgJ2dvJyArIGV4ZWN1dGFibGVTdWZmaXgpXG4gICAgICBmcy53cml0ZUZpbGVTeW5jKGdvLCAnJywge2VuY29kaW5nOiAndXRmOCcsIG1vZGU6IDUxMX0pXG4gICAgICBlbnZbcGF0aGtleV0gPSBnb2RpclxuICAgICAgZW52LkdPUEFUSCA9IHBhdGguam9pbignficsICdnbycpXG4gICAgfSlcblxuICAgIGl0KCdydW50aW1lQ2FuZGlkYXRlcygpIGZpbmRzIHRoZSBydW50aW1lJywgKCkgPT4ge1xuICAgICAgZXhwZWN0KGxvY2F0b3IucnVudGltZUNhbmRpZGF0ZXMpLnRvQmVEZWZpbmVkKClcbiAgICAgIGxldCBjYW5kaWRhdGVzID0gbG9jYXRvci5ydW50aW1lQ2FuZGlkYXRlcygpXG4gICAgICBleHBlY3QoY2FuZGlkYXRlcykudG9CZVRydXRoeSgpXG4gICAgICBleHBlY3QoY2FuZGlkYXRlcy5sZW5ndGgpLnRvQmVHcmVhdGVyVGhhbigwKVxuICAgICAgZXhwZWN0KGNhbmRpZGF0ZXNbMF0pLnRvQmUoZ28pXG4gICAgfSlcbiAgfSlcblxuICBkZXNjcmliZSgnd2hlbiBHT1JPT1QgaXMgc2V0IGFuZCB0aGUgZ28gdG9vbCBpcyBhdmFpbGFibGUgd2l0aGluICRHT1JPT1QvYmluJywgKCkgPT4ge1xuICAgIGxldCBnb2RpciA9IG51bGxcbiAgICBsZXQgZ28gPSBudWxsXG4gICAgbGV0IGdvcm9vdGdvID0gbnVsbFxuICAgIGxldCBnb3Jvb3RkaXIgPSBudWxsXG4gICAgbGV0IGdvcm9vdGJpbmRpciA9IG51bGxcblxuICAgIGJlZm9yZUVhY2goKCkgPT4ge1xuICAgICAgZ29yb290ZGlyID0gdGVtcC5ta2RpclN5bmMoJ2dvcm9vdC0nKVxuICAgICAgZ29yb290YmluZGlyID0gcGF0aC5qb2luKGdvcm9vdGRpciwgJ2JpbicpXG4gICAgICBmcy5ta2RpclN5bmMoZ29yb290YmluZGlyKVxuICAgICAgZ29yb290Z28gPSBwYXRoLmpvaW4oZ29yb290YmluZGlyLCAnZ28nICsgZXhlY3V0YWJsZVN1ZmZpeClcbiAgICAgIGdvZGlyID0gdGVtcC5ta2RpclN5bmMoJ2dvLScpXG4gICAgICBnbyA9IHBhdGguam9pbihnb2RpciwgJ2dvJyArIGV4ZWN1dGFibGVTdWZmaXgpXG4gICAgICBmcy53cml0ZUZpbGVTeW5jKGdvcm9vdGdvLCAnJywge2VuY29kaW5nOiAndXRmOCcsIG1vZGU6IDUxMX0pXG4gICAgICBmcy53cml0ZUZpbGVTeW5jKGdvLCAnJywge2VuY29kaW5nOiAndXRmOCcsIG1vZGU6IDUxMX0pXG4gICAgICBlbnZbcGF0aGtleV0gPSBnb2RpclxuICAgICAgZW52LkdPUk9PVCA9IGdvcm9vdGRpclxuICAgICAgZW52LkdPUEFUSCA9IHBhdGguam9pbignficsICdnbycpXG4gICAgfSlcblxuICAgIGFmdGVyRWFjaCgoKSA9PiB7XG4gICAgICBlbnYuR09ST09UID0gJydcbiAgICB9KVxuXG4gICAgaXQoJ3J1bnRpbWVDYW5kaWRhdGVzKCkgZmluZHMgdGhlIHJ1bnRpbWUgYW5kIG9yZGVycyB0aGUgZ28gaW4gJEdPUk9PVC9iaW4gYmVmb3JlIHRoZSBnbyBpbiBQQVRIJywgKCkgPT4ge1xuICAgICAgZXhwZWN0KGxvY2F0b3IucnVudGltZUNhbmRpZGF0ZXMpLnRvQmVEZWZpbmVkKClcbiAgICAgIGxldCBjYW5kaWRhdGVzID0gbG9jYXRvci5ydW50aW1lQ2FuZGlkYXRlcygpXG4gICAgICBleHBlY3QoY2FuZGlkYXRlcykudG9CZVRydXRoeSgpXG4gICAgICBleHBlY3QoY2FuZGlkYXRlcy5sZW5ndGgpLnRvQmVHcmVhdGVyVGhhbigwKVxuICAgICAgZXhwZWN0KGNhbmRpZGF0ZXNbMF0pLnRvQmUoZ29yb290Z28pXG4gICAgICBleHBlY3QoY2FuZGlkYXRlc1sxXSkudG9CZShnbylcbiAgICB9KVxuICB9KVxuXG4gIGRlc2NyaWJlKCd3aGVuIHRoZSBQQVRIIGhhcyBtdWx0aXBsZSBkaXJlY3RvcmllcyB3aXRoIGEgZ28gcnVudGltZSBpbiBpdCcsICgpID0+IHtcbiAgICBsZXQgZ29kaXIgPSBudWxsXG4gICAgbGV0IGdvMWRpciA9IG51bGxcbiAgICBsZXQgZ28gPSBudWxsXG4gICAgbGV0IGdvMSA9IG51bGxcbiAgICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICAgIGdvZGlyID0gdGVtcC5ta2RpclN5bmMoJ2dvLScpXG4gICAgICBnbzFkaXIgPSB0ZW1wLm1rZGlyU3luYygnZ28xLScpXG4gICAgICBnbyA9IHBhdGguam9pbihnb2RpciwgJ2dvJyArIGV4ZWN1dGFibGVTdWZmaXgpXG4gICAgICBnbzEgPSBwYXRoLmpvaW4oZ28xZGlyLCAnZ28nICsgZXhlY3V0YWJsZVN1ZmZpeClcbiAgICAgIGZzLndyaXRlRmlsZVN5bmMoZ28sICcnLCB7ZW5jb2Rpbmc6ICd1dGY4JywgbW9kZTogNTExfSlcbiAgICAgIGZzLndyaXRlRmlsZVN5bmMoZ28xLCAnJywge2VuY29kaW5nOiAndXRmOCcsIG1vZGU6IDUxMX0pXG4gICAgICBlbnZbcGF0aGtleV0gPSBnb2RpciArIHBhdGguZGVsaW1pdGVyICsgZ28xZGlyXG4gICAgfSlcblxuICAgIGl0KCdydW50aW1lQ2FuZGlkYXRlcygpIHJldHVybnMgdGhlIGNhbmRpZGF0ZXMgaW4gdGhlIGNvcnJlY3Qgb3JkZXInLCAoKSA9PiB7XG4gICAgICBleHBlY3QobG9jYXRvci5ydW50aW1lQ2FuZGlkYXRlcykudG9CZURlZmluZWQoKVxuICAgICAgbGV0IGNhbmRpZGF0ZXMgPSBsb2NhdG9yLnJ1bnRpbWVDYW5kaWRhdGVzKClcbiAgICAgIGV4cGVjdChjYW5kaWRhdGVzKS50b0JlVHJ1dGh5KClcbiAgICAgIGV4cGVjdChjYW5kaWRhdGVzLmxlbmd0aCkudG9CZUdyZWF0ZXJUaGFuKDEpXG4gICAgICBleHBlY3QoY2FuZGlkYXRlc1swXSkudG9CZShnbylcbiAgICAgIGV4cGVjdChjYW5kaWRhdGVzWzFdKS50b0JlKGdvMSlcbiAgICB9KVxuXG4gICAgaXQoJ3J1bnRpbWVDYW5kaWRhdGVzKCkgcmV0dXJucyBjYW5kaWRhdGVzIGluIHRoZSBjb3JyZWN0IG9yZGVyIHdoZW4gYSBjYW5kaWRhdGUgb2NjdXJzIG11bHRpcGxlIHRpbWVzIGluIHRoZSBwYXRoJywgKCkgPT4ge1xuICAgICAgZW52W3BhdGhrZXldID0gZ29kaXIgKyBwYXRoLmRlbGltaXRlciArIGdvMWRpciArIHBhdGguZGVsaW1pdGVyICsgZ29kaXJcbiAgICAgIGV4cGVjdChsb2NhdG9yLnJ1bnRpbWVDYW5kaWRhdGVzKS50b0JlRGVmaW5lZCgpXG4gICAgICBsZXQgY2FuZGlkYXRlcyA9IGxvY2F0b3IucnVudGltZUNhbmRpZGF0ZXMoKVxuICAgICAgZXhwZWN0KGNhbmRpZGF0ZXMpLnRvQmVUcnV0aHkoKVxuICAgICAgZXhwZWN0KGNhbmRpZGF0ZXMubGVuZ3RoKS50b0JlR3JlYXRlclRoYW4oMSlcbiAgICAgIGV4cGVjdChjYW5kaWRhdGVzWzBdKS50b0JlKGdvKVxuICAgICAgZXhwZWN0KGNhbmRpZGF0ZXNbMV0pLnRvQmUoZ28xKVxuICAgICAgaWYgKGNhbmRpZGF0ZXMubGVuZ3RoID4gMikge1xuICAgICAgICBleHBlY3QoY2FuZGlkYXRlc1syXSkubm90LnRvQmUoZ28pXG4gICAgICB9XG4gICAgfSlcbiAgfSlcblxuICBkZXNjcmliZSgnd2hlbiB0aGUgcGF0aCBpbmNsdWRlcyBhIGRpcmVjdG9yeSB3aXRoIGdvIDEuNS4xIGluIGl0JywgKCkgPT4ge1xuICAgIGxldCBnb2RpciA9IG51bGxcbiAgICBsZXQgZ29wYXRoZGlyID0gbnVsbFxuICAgIGxldCBnb3Jvb3RkaXIgPSBudWxsXG4gICAgbGV0IGdvcm9vdGJpbmRpciA9IG51bGxcbiAgICBsZXQgZ290b29sZGlyID0gbnVsbFxuICAgIGxldCBnbyA9IG51bGxcbiAgICBsZXQgZ29yb290YmludG9vbHMgPSBudWxsXG4gICAgbGV0IGdvdG9vbGRpcnRvb2xzID0gbnVsbFxuICAgIGJlZm9yZUVhY2goKCkgPT4ge1xuICAgICAgZ29yb290YmludG9vbHMgPSBbJ2dvJywgJ2dvZG9jJywgJ2dvZm10J11cbiAgICAgIGdvdG9vbGRpcnRvb2xzID0gWydhZGRyMmxpbmUnLCAnY2dvJywgJ2Rpc3QnLCAnbGluaycsICdwYWNrJywgJ3RyYWNlJywgJ2FwaScsICdjb21waWxlJywgJ2RvYycsICdubScsICdwcHJvZicsICd2ZXQnLCAnYXNtJywgJ2NvdmVyJywgJ2ZpeCcsICdvYmpkdW1wJywgJ3lhY2MnXVxuICAgICAgZ29kaXIgPSB0ZW1wLm1rZGlyU3luYygnZ28tJylcbiAgICAgIGdvcGF0aGRpciA9IHRlbXAubWtkaXJTeW5jKCdnb3BhdGgtJylcbiAgICAgIGdvcm9vdGRpciA9IHRlbXAubWtkaXJTeW5jKCdnb3Jvb3QtJylcbiAgICAgIGdvcm9vdGJpbmRpciA9IHBhdGguam9pbihnb3Jvb3RkaXIsICdiaW4nKVxuICAgICAgZnMubWtkaXJTeW5jKGdvcm9vdGJpbmRpcilcbiAgICAgIGdvdG9vbGRpciA9IHBhdGguam9pbihnb3Jvb3RkaXIsICdwa2cnLCAndG9vbCcsIHBsYXRmb3JtICsgJ18nICsgYXJjaClcbiAgICAgIGZzLm1rZGlyc1N5bmMoZ290b29sZGlyKVxuICAgICAgbGV0IGZha2VleGVjdXRhYmxlID0gJ2dvXycgKyBwbGF0Zm9ybSArICdfJyArIGFyY2ggKyBleGVjdXRhYmxlU3VmZml4XG4gICAgICBsZXQgZ28xNTFqc29uID0gcGF0aC5qb2luKF9fZGlybmFtZSwgJ2ZpeHR1cmVzJywgJ2dvLTE1MS0nICsgcGxhdGZvcm0gKyAnLmpzb24nKVxuICAgICAgbGV0IGZha2VnbyA9IHBhdGguam9pbihfX2Rpcm5hbWUsICd0b29scycsICdnbycsIGZha2VleGVjdXRhYmxlKVxuICAgICAgZ28gPSBwYXRoLmpvaW4oZ29yb290YmluZGlyLCAnZ28nICsgZXhlY3V0YWJsZVN1ZmZpeClcbiAgICAgIGZzLmNvcHlTeW5jKGZha2VnbywgZ28pXG4gICAgICBmcy5jb3B5U3luYyhnbzE1MWpzb24sIHBhdGguam9pbihnb3Jvb3RiaW5kaXIsICdnby5qc29uJykpXG4gICAgICBlbnZbcGF0aGtleV0gPSBnb2RpclxuICAgICAgZW52WydHT1BBVEgnXSA9IGdvcGF0aGRpclxuICAgICAgZW52WydHT1JPT1QnXSA9IGdvcm9vdGRpclxuICAgICAgZm9yIChsZXQgdG9vbCBvZiBnb3Jvb3RiaW50b29scykge1xuICAgICAgICBpZiAodG9vbCAhPT0gJ2dvJykge1xuICAgICAgICAgIHRvdWNoLnN5bmMocGF0aC5qb2luKGdvcm9vdGJpbmRpciwgdG9vbCArIGV4ZWN1dGFibGVTdWZmaXgpKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBmb3IgKGxldCB0b29sIG9mIGdvdG9vbGRpcnRvb2xzKSB7XG4gICAgICAgIGxldCB0b29scGF0aCA9IHBhdGguam9pbihnb3Rvb2xkaXIsIHRvb2wgKyBleGVjdXRhYmxlU3VmZml4KVxuICAgICAgICB0b3VjaC5zeW5jKHRvb2xwYXRoKVxuICAgICAgfVxuICAgIH0pXG5cbiAgICBpdCgncnVudGltZUNhbmRpZGF0ZXMoKSBmaW5kcyB0aGUgcnVudGltZScsICgpID0+IHtcbiAgICAgIGV4cGVjdChsb2NhdG9yLnJ1bnRpbWVDYW5kaWRhdGVzKS50b0JlRGVmaW5lZCgpXG4gICAgICBsZXQgY2FuZGlkYXRlcyA9IGxvY2F0b3IucnVudGltZUNhbmRpZGF0ZXMoKVxuICAgICAgZXhwZWN0KGNhbmRpZGF0ZXMpLnRvQmVUcnV0aHkoKVxuICAgICAgZXhwZWN0KGNhbmRpZGF0ZXMubGVuZ3RoKS50b0JlR3JlYXRlclRoYW4oMClcbiAgICAgIGV4cGVjdChjYW5kaWRhdGVzWzBdKS50b0JlKGdvKVxuICAgIH0pXG5cbiAgICBpdCgncnVudGltZXMoKSByZXR1cm5zIHRoZSBydW50aW1lJywgKCkgPT4ge1xuICAgICAgZXhwZWN0KGxvY2F0b3IucnVudGltZXMpLnRvQmVEZWZpbmVkKClcbiAgICAgIGxldCBydW50aW1lcyA9IG51bGxcbiAgICAgIGxldCBkb25lID0gbG9jYXRvci5ydW50aW1lcygpLnRoZW4oKHIpID0+IHsgcnVudGltZXMgPSByIH0pXG5cbiAgICAgIHdhaXRzRm9yUHJvbWlzZSgoKSA9PiB7IHJldHVybiBkb25lIH0pXG5cbiAgICAgIHJ1bnMoKCkgPT4ge1xuICAgICAgICBleHBlY3QocnVudGltZXMpLnRvQmVUcnV0aHkoKVxuICAgICAgICBleHBlY3QocnVudGltZXMubGVuZ3RoKS50b0JlR3JlYXRlclRoYW4oMClcbiAgICAgICAgZXhwZWN0KHJ1bnRpbWVzWzBdLm5hbWUpLnRvQmUoJ2dvMS41LjEnKVxuICAgICAgICBleHBlY3QocnVudGltZXNbMF0uc2VtdmVyKS50b0JlKCcxLjUuMScpXG4gICAgICAgIGV4cGVjdChydW50aW1lc1swXS52ZXJzaW9uKS50b0JlKCdnbyB2ZXJzaW9uIGdvMS41LjEgJyArIHBsYXRmb3JtICsgJy8nICsgYXJjaClcbiAgICAgICAgZXhwZWN0KHJ1bnRpbWVzWzBdLnBhdGgpLnRvQmUoZ28pXG4gICAgICAgIGV4cGVjdChydW50aW1lc1swXS5HT0FSQ0gpLnRvQmUoYXJjaClcbiAgICAgICAgZXhwZWN0KHJ1bnRpbWVzWzBdLkdPQklOKS50b0JlKCcnKVxuICAgICAgICBpZiAocGxhdGZvcm0gPT09ICd3aW5kb3dzJykge1xuICAgICAgICAgIGV4cGVjdChydW50aW1lc1swXS5HT0VYRSkudG9CZSgnLmV4ZScpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZXhwZWN0KHJ1bnRpbWVzWzBdLkdPRVhFKS50b0JlKCcnKVxuICAgICAgICB9XG4gICAgICAgIGV4cGVjdChydW50aW1lc1swXS5HT0hPU1RBUkNIKS50b0JlKGFyY2gpXG4gICAgICAgIGV4cGVjdChydW50aW1lc1swXS5HT0hPU1RPUykudG9CZShwbGF0Zm9ybSlcbiAgICAgICAgZXhwZWN0KHJ1bnRpbWVzWzBdLkdPT1MpLnRvQmUocGxhdGZvcm0pXG4gICAgICAgIGV4cGVjdChydW50aW1lc1swXS5HT1BBVEgpLnRvQmUoZ29wYXRoZGlyKVxuICAgICAgICBleHBlY3QocnVudGltZXNbMF0uR09SQUNFKS50b0JlKCcnKVxuICAgICAgICBleHBlY3QocnVudGltZXNbMF0uR09ST09UKS50b0JlKGdvcm9vdGRpcilcbiAgICAgICAgZXhwZWN0KHJ1bnRpbWVzWzBdLkdPVE9PTERJUikudG9CZShnb3Rvb2xkaXIpXG4gICAgICAgIGlmIChwbGF0Zm9ybSA9PT0gJ3dpbmRvd3MnKSB7XG4gICAgICAgICAgZXhwZWN0KHJ1bnRpbWVzWzBdLkNDKS50b0JlKCdnY2MnKVxuICAgICAgICAgIGV4cGVjdChydW50aW1lc1swXS5HT0dDQ0ZMQUdTKS50b0JlKCctbTY0IC1tdGhyZWFkcyAtZm1lc3NhZ2UtbGVuZ3RoPTAnKVxuICAgICAgICAgIGV4cGVjdChydW50aW1lc1swXS5DWFgpLnRvQmUoJ2crKycpXG4gICAgICAgIH0gZWxzZSBpZiAocGxhdGZvcm0gPT09ICdkYXJ3aW4nKSB7XG4gICAgICAgICAgZXhwZWN0KHJ1bnRpbWVzWzBdLkNDKS50b0JlKCdjbGFuZycpXG4gICAgICAgICAgZXhwZWN0KHJ1bnRpbWVzWzBdLkdPR0NDRkxBR1MpLnRvQmUoJy1mUElDIC1tNjQgLXB0aHJlYWQgLWZuby1jYXJldC1kaWFnbm9zdGljcyAtUXVudXNlZC1hcmd1bWVudHMgLWZtZXNzYWdlLWxlbmd0aD0wIC1mbm8tY29tbW9uJylcbiAgICAgICAgICBleHBlY3QocnVudGltZXNbMF0uQ1hYKS50b0JlKCdjbGFuZysrJylcbiAgICAgICAgfSBlbHNlIGlmIChvcy5wbGF0Zm9ybSgpID09PSAnbGludXgnKSB7XG4gICAgICAgICAgZXhwZWN0KHJ1bnRpbWVzWzBdLkNDKS50b0JlKCdnY2MnKVxuICAgICAgICAgIGV4cGVjdChydW50aW1lc1swXS5HT0dDQ0ZMQUdTKS50b0JlKCctZlBJQyAtbTY0IC1wdGhyZWFkIC1mbWVzc2FnZS1sZW5ndGg9MCcpXG4gICAgICAgICAgZXhwZWN0KHJ1bnRpbWVzWzBdLkNYWCkudG9CZSgnZysrJylcbiAgICAgICAgfVxuICAgICAgICBleHBlY3QocnVudGltZXNbMF0uR08xNVZFTkRPUkVYUEVSSU1FTlQpLnRvQmUoJycpXG4gICAgICAgIGV4cGVjdChydW50aW1lc1swXS5DR09fRU5BQkxFRCkudG9CZSgnMScpXG4gICAgICB9KVxuICAgIH0pXG5cbiAgICBpdCgnZmluZFRvb2woKSBmaW5kcyB0aGUgZ28gdG9vbCcsICgpID0+IHtcbiAgICAgIGV4cGVjdChsb2NhdG9yLmZpbmRUb29sKS50b0JlRGVmaW5lZCgpXG4gICAgICBsZXQgdG9vbCA9IG51bGxcbiAgICAgIGxldCBlcnIgPSBudWxsXG4gICAgICBsZXQgZG9uZSA9IGxvY2F0b3IuZmluZFRvb2woJ2dvJywgZmFsc2UsIG51bGwpLnRoZW4oKHQpID0+IHsgdG9vbCA9IHQgfSkuY2F0Y2goKGUpID0+IHsgZXJyID0gZSB9KVxuXG4gICAgICB3YWl0c0ZvclByb21pc2UoKCkgPT4geyByZXR1cm4gZG9uZSB9KVxuXG4gICAgICBydW5zKCgpID0+IHtcbiAgICAgICAgZXhwZWN0KGVycikudG9CZShudWxsKVxuICAgICAgICBleHBlY3QodG9vbCkudG9CZVRydXRoeSgpXG4gICAgICAgIGV4cGVjdCh0b29sKS50b0JlKHBhdGguam9pbihnb3Jvb3RiaW5kaXIsICdnbycgKyBleGVjdXRhYmxlU3VmZml4KSlcbiAgICAgIH0pXG4gICAgfSlcblxuICAgIGl0KCdmaW5kVG9vbCgpIGZpbmRzIHRvb2xzIGluIEdPUk9PVCcsICgpID0+IHtcbiAgICAgIGxldCB0b29scyA9IFsnZ28nLCAnZ29kb2MnLCAnZ29mbXQnXVxuICAgICAgbGV0IHJ1bnRpbWUgPSBmYWxzZVxuICAgICAgbGV0IHRvb2wgPSBudWxsXG4gICAgICBsZXQgdG9vbFBhdGggPSBmYWxzZVxuICAgICAgbGV0IGRvbmUgPSBsb2NhdG9yLnJ1bnRpbWVGb3JQcm9qZWN0KGZhbHNlKS50aGVuKChyKSA9PiB7IHJ1bnRpbWUgPSByIH0pXG5cbiAgICAgIHdhaXRzRm9yUHJvbWlzZSgoKSA9PiB7IHJldHVybiBkb25lIH0pXG5cbiAgICAgIHJ1bnMoKCkgPT4ge1xuICAgICAgICBmb3IgKGxldCB0b29sSXRlbSBvZiB0b29scykge1xuICAgICAgICAgIHRvb2wgPSBudWxsXG4gICAgICAgICAgZG9uZSA9IG51bGxcbiAgICAgICAgICB0b29sUGF0aCA9IHBhdGguam9pbihydW50aW1lLkdPUk9PVCwgJ2JpbicsIHRvb2xJdGVtICsgcnVudGltZS5HT0VYRSlcbiAgICAgICAgICBkb25lID0gbG9jYXRvci5maW5kVG9vbCh0b29sSXRlbSwgZmFsc2UsIG51bGwpLnRoZW4oKHQpID0+IHsgdG9vbCA9IHQgfSlcbiAgICAgICAgICB3YWl0c0ZvclByb21pc2UoKCkgPT4geyByZXR1cm4gZG9uZSB9KVxuXG4gICAgICAgICAgcnVucygoKSA9PiB7XG4gICAgICAgICAgICBleHBlY3QodG9vbCkudG9CZVRydXRoeSgpXG4gICAgICAgICAgICBleHBlY3QodG9vbCkudG9CZSh0b29sUGF0aClcbiAgICAgICAgICB9KVxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH0pXG5cbiAgICBpdCgnc3RhdCgpIHJldHVybnMgZmFsc2UgZm9yIG5vbmV4aXN0ZW50IGZpbGVzJywgKCkgPT4ge1xuICAgICAgbGV0IHN0YXQgPSBudWxsXG4gICAgICBsZXQgZG9uZSA9IGxvY2F0b3Iuc3RhdCgnbm9uZXhpc3RlbnR0aGluZycpLnRoZW4oKHMpID0+IHsgc3RhdCA9IHMgfSlcbiAgICAgIHdhaXRzRm9yUHJvbWlzZSgoKSA9PiB7IHJldHVybiBkb25lIH0pXG5cbiAgICAgIHJ1bnMoKCkgPT4ge1xuICAgICAgICBleHBlY3Qoc3RhdCkudG9CZShmYWxzZSlcbiAgICAgIH0pXG4gICAgfSlcblxuICAgIGl0KCdmaW5kVG9vbCgpIGZpbmRzIHRvb2xzIGluIEdPVE9PTERJUicsICgpID0+IHtcbiAgICAgIGxldCB0b29scyA9IFsnYWRkcjJsaW5lJywgJ2NnbycsICdkaXN0JywgJ2xpbmsnLCAncGFjaycsICd0cmFjZScsICdhcGknLCAnY29tcGlsZScsICdkb2MnLCAnbm0nLCAncHByb2YnLCAndmV0JywgJ2FzbScsICdjb3ZlcicsICdmaXgnLCAnb2JqZHVtcCcsICd5YWNjJ11cbiAgICAgIGxldCBydW50aW1lID0gZmFsc2VcbiAgICAgIGxldCBkb25lID0gbG9jYXRvci5ydW50aW1lRm9yUHJvamVjdChmYWxzZSkudGhlbigocikgPT4geyBydW50aW1lID0gciB9KVxuXG4gICAgICB3YWl0c0ZvclByb21pc2UoKCkgPT4geyByZXR1cm4gZG9uZSB9KVxuXG4gICAgICBydW5zKCgpID0+IHtcbiAgICAgICAgZm9yIChsZXQgdG9vbEl0ZW0gb2YgdG9vbHMpIHtcbiAgICAgICAgICBsZXQgdG9vbCA9IG51bGxcbiAgICAgICAgICBsZXQgdG9vbFBhdGggPSBwYXRoLmpvaW4ocnVudGltZS5HT1RPT0xESVIsIHRvb2xJdGVtICsgcnVudGltZS5HT0VYRSlcbiAgICAgICAgICBsZXQgZG9uZSA9IGxvY2F0b3IuZmluZFRvb2wodG9vbEl0ZW0sIGZhbHNlLCBudWxsKS50aGVuKCh0KSA9PiB7IHRvb2wgPSB0IH0pXG4gICAgICAgICAgd2FpdHNGb3JQcm9taXNlKCgpID0+IHsgcmV0dXJuIGRvbmUgfSlcblxuICAgICAgICAgIHJ1bnMoKCkgPT4ge1xuICAgICAgICAgICAgZXhwZWN0KHRvb2wpLnRvQmVUcnV0aHkoKVxuICAgICAgICAgICAgZXhwZWN0KHRvb2wpLnRvQmUodG9vbFBhdGgpXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9KVxuICB9KVxuXG4gIGRlc2NyaWJlKCd3aGVuIHRoZSBwYXRoIGluY2x1ZGVzIGEgZGlyZWN0b3J5IHdpdGggdGhlIGdvbWV0YWxpbnRlciB0b29sIGluIGl0JywgKCkgPT4ge1xuICAgIGxldCBnb3BhdGhkaXIgPSBudWxsXG4gICAgbGV0IGdvcGF0aGJpbmRpciA9IG51bGxcbiAgICBsZXQgcGF0aGRpciA9IG51bGxcbiAgICBsZXQgcGF0aHRvb2xzID0gbnVsbFxuICAgIGxldCBnb3BhdGhiaW50b29scyA9IG51bGxcbiAgICBiZWZvcmVFYWNoKCgpID0+IHtcbiAgICAgIHBhdGh0b29scyA9IFsnZ29tZXRhbGludGVyJywgJ2diJ11cbiAgICAgIGdvcGF0aGJpbnRvb2xzID0gWydzb21lcmFuZG9tdG9vbCcsICdnYiddXG4gICAgICBwYXRoZGlyID0gdGVtcC5ta2RpclN5bmMoJ3BhdGgtJylcbiAgICAgIGdvcGF0aGRpciA9IHRlbXAubWtkaXJTeW5jKCdnb3BhdGgtJylcbiAgICAgIGdvcGF0aGJpbmRpciA9IHBhdGguam9pbihnb3BhdGhkaXIsICdiaW4nKVxuICAgICAgZnMubWtkaXJTeW5jKGdvcGF0aGJpbmRpcilcbiAgICAgIGVudlsnR09QQVRIJ10gPSBnb3BhdGhkaXJcbiAgICAgIGVudltwYXRoa2V5XSA9IHBhdGhkaXIgKyBwYXRoLmRlbGltaXRlciArIGVudlsnUEFUSCddXG4gICAgICBmb3IgKGxldCB0b29sIG9mIHBhdGh0b29scykge1xuICAgICAgICB0b3VjaC5zeW5jKHBhdGguam9pbihwYXRoZGlyLCB0b29sICsgZXhlY3V0YWJsZVN1ZmZpeCkpXG4gICAgICB9XG4gICAgICBmb3IgKGxldCB0b29sIG9mIGdvcGF0aGJpbnRvb2xzKSB7XG4gICAgICAgIHRvdWNoLnN5bmMocGF0aC5qb2luKGdvcGF0aGJpbmRpciwgdG9vbCArIGV4ZWN1dGFibGVTdWZmaXgpKVxuICAgICAgfVxuICAgIH0pXG5cbiAgICBpdCgnZmluZFRvb2woKSBmaW5kcyB0b29scyBpbiBQQVRIJywgKCkgPT4ge1xuICAgICAgcnVucygoKSA9PiB7XG4gICAgICAgIGZvciAobGV0IHRvb2xJdGVtIG9mIHBhdGh0b29scykge1xuICAgICAgICAgIGxldCB0b29sUGF0aCA9IGZhbHNlXG4gICAgICAgICAgbGV0IHRvb2wgPSBudWxsXG4gICAgICAgICAgbGV0IGRvbmUgPSBudWxsXG5cbiAgICAgICAgICBpZiAoZ29wYXRoYmludG9vbHMuaW5kZXhPZih0b29sSXRlbSkgIT09IC0xKSB7XG4gICAgICAgICAgICB0b29sUGF0aCA9IHBhdGguam9pbihnb3BhdGhiaW5kaXIsIHRvb2xJdGVtICsgZXhlY3V0YWJsZVN1ZmZpeClcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdG9vbFBhdGggPSBwYXRoLmpvaW4ocGF0aGRpciwgdG9vbEl0ZW0gKyBleGVjdXRhYmxlU3VmZml4KVxuICAgICAgICAgIH1cblxuICAgICAgICAgIGRvbmUgPSBsb2NhdG9yLmZpbmRUb29sKHRvb2xJdGVtLCBmYWxzZSwgbnVsbCkudGhlbigodCkgPT4ge1xuICAgICAgICAgICAgdG9vbCA9IHRcbiAgICAgICAgICB9KVxuICAgICAgICAgIHdhaXRzRm9yUHJvbWlzZSgoKSA9PiB7IHJldHVybiBkb25lIH0pXG4gICAgICAgICAgcnVucygoKSA9PiB7XG4gICAgICAgICAgICBkb25lID0gbnVsbFxuICAgICAgICAgICAgZXhwZWN0KHRvb2wpLnRvQmVUcnV0aHkoKVxuICAgICAgICAgICAgZXhwZWN0KHRvb2wpLnRvQmUodG9vbFBhdGgpXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9KVxuXG4gICAgaXQoJ2ZpbmRUb29sKCkgZmluZHMgdG9vbHMgaW4gR09QQVRIXFwncyBiaW4gZGlyZWN0b3J5JywgKCkgPT4ge1xuICAgICAgcnVucygoKSA9PiB7XG4gICAgICAgIGZvciAobGV0IHRvb2xJdGVtIG9mIGdvcGF0aGJpbnRvb2xzKSB7XG4gICAgICAgICAgbGV0IHRvb2wgPSBudWxsXG4gICAgICAgICAgbGV0IHRvb2xQYXRoID0gZmFsc2VcbiAgICAgICAgICBsZXQgZG9uZSA9IG51bGxcbiAgICAgICAgICB0b29sUGF0aCA9IHBhdGguam9pbihnb3BhdGhiaW5kaXIsIHRvb2xJdGVtICsgZXhlY3V0YWJsZVN1ZmZpeClcbiAgICAgICAgICBkb25lID0gbG9jYXRvci5maW5kVG9vbCh0b29sSXRlbSwgZmFsc2UsIG51bGwpLnRoZW4oKHQpID0+IHsgdG9vbCA9IHQgfSlcbiAgICAgICAgICB3YWl0c0ZvclByb21pc2UoKCkgPT4geyByZXR1cm4gZG9uZSB9KVxuICAgICAgICAgIHJ1bnMoKCkgPT4ge1xuICAgICAgICAgICAgZXhwZWN0KHRvb2wpLnRvQmVUcnV0aHkoKVxuICAgICAgICAgICAgZXhwZWN0KHRvb2wpLnRvQmUodG9vbFBhdGgpXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9KVxuICB9KVxufSlcbiJdfQ==
//# sourceURL=/home/shane/.atom/packages/go-config/spec/locator-spec.js
