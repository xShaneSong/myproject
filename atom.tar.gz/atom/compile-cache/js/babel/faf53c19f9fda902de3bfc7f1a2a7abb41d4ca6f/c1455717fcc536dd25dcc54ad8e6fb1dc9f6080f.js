Object.defineProperty(exports, '__esModule', {
  value: true
});

var _atom = require('atom');

var _check = require('./check');

var _executor = require('./executor');

'use babel';

exports['default'] = {
  environment: null,
  locator: null,
  subscriptions: null,
  dependenciesInstalled: null,

  activate: function activate() {
    var _this = this;

    this.dependenciesInstalled = false;
    this.subscriptions = new _atom.CompositeDisposable();
    this.subscriptions.add(atom.commands.add('atom-workspace', 'go-config:detect', function () {}));
    require('atom-package-deps').install('go-config').then(function () {
      _this.dependenciesInstalled = true;
    })['catch'](function (e) {
      console.log(e);
    });
  },

  deactivate: function deactivate() {
    this.dispose();
  },

  dispose: function dispose() {
    if ((0, _check.isTruthy)(this.subscriptions)) {
      this.subscriptions.dispose();
    }
    this.subscriptions = null;
    this.environment = null;
    this.locator = null;
    this.dependenciesInstalled = null;
  },

  getExecutor: function getExecutor(options) {
    var e = new _executor.Executor({ environmentFn: this.getEnvironment.bind(this) });
    return e;
  },

  getLocator: function getLocator() {
    if ((0, _check.isTruthy)(this.locator)) {
      return this.locator;
    }
    var Locator = require('./locator').Locator;
    this.locator = new Locator({
      environment: this.getEnvironment.bind(this),
      executor: this.getExecutor(),
      ready: this.ready.bind(this)
    });
    this.subscriptions.add(this.locator);
    return this.locator;
  },

  ready: function ready() {
    if ((0, _check.isFalsy)(this.dependenciesInstalled)) {
      return false;
    }
    if ((0, _check.isTruthy)(this.environment)) {
      return true;
    } else {
      return false;
    }
  },

  getEnvironment: function getEnvironment() {
    if (this.ready()) {
      return this.environment;
    }

    return process.env;
  },

  provide: function provide() {
    return { executor: this.getExecutor(), locator: this.getLocator(), environment: this.getEnvironment.bind(this) };
  },

  consumeEnvironment: function consumeEnvironment(environment) {
    this.environment = environment;
  }
};
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL3NoYW5lLy5hdG9tL3BhY2thZ2VzL2dvLWNvbmZpZy9saWIvbWFpbi5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O29CQUVrQyxNQUFNOztxQkFDUixTQUFTOzt3QkFDbEIsWUFBWTs7QUFKbkMsV0FBVyxDQUFBOztxQkFNSTtBQUNiLGFBQVcsRUFBRSxJQUFJO0FBQ2pCLFNBQU8sRUFBRSxJQUFJO0FBQ2IsZUFBYSxFQUFFLElBQUk7QUFDbkIsdUJBQXFCLEVBQUUsSUFBSTs7QUFFM0IsVUFBUSxFQUFDLG9CQUFHOzs7QUFDVixRQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFBO0FBQ2xDLFFBQUksQ0FBQyxhQUFhLEdBQUcsK0JBQXlCLENBQUE7QUFDOUMsUUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsa0JBQWtCLEVBQUUsWUFBTSxFQUFHLENBQUMsQ0FBQyxDQUFBO0FBQzFGLFdBQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBTTtBQUMzRCxZQUFLLHFCQUFxQixHQUFHLElBQUksQ0FBQTtLQUNsQyxDQUFDLFNBQU0sQ0FBQyxVQUFDLENBQUMsRUFBSztBQUNkLGFBQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUE7S0FDZixDQUFDLENBQUE7R0FDSDs7QUFFRCxZQUFVLEVBQUMsc0JBQUc7QUFDWixRQUFJLENBQUMsT0FBTyxFQUFFLENBQUE7R0FDZjs7QUFFRCxTQUFPLEVBQUMsbUJBQUc7QUFDVCxRQUFJLHFCQUFTLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRTtBQUNoQyxVQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxDQUFBO0tBQzdCO0FBQ0QsUUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUE7QUFDekIsUUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUE7QUFDdkIsUUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUE7QUFDbkIsUUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQTtHQUNsQzs7QUFFRCxhQUFXLEVBQUMscUJBQUMsT0FBTyxFQUFFO0FBQ3BCLFFBQUksQ0FBQyxHQUFHLHVCQUFhLEVBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDLENBQUMsQ0FBQTtBQUNyRSxXQUFPLENBQUMsQ0FBQTtHQUNUOztBQUVELFlBQVUsRUFBQyxzQkFBRztBQUNaLFFBQUkscUJBQVMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFO0FBQzFCLGFBQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQTtLQUNwQjtBQUNELFFBQUksT0FBTyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUE7QUFDMUMsUUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLE9BQU8sQ0FBQztBQUN6QixpQkFBVyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUMzQyxjQUFRLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBRTtBQUM1QixXQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0tBQzdCLENBQUMsQ0FBQTtBQUNGLFFBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtBQUNwQyxXQUFPLElBQUksQ0FBQyxPQUFPLENBQUE7R0FDcEI7O0FBRUQsT0FBSyxFQUFDLGlCQUFHO0FBQ1AsUUFBSSxvQkFBUSxJQUFJLENBQUMscUJBQXFCLENBQUMsRUFBRTtBQUN2QyxhQUFPLEtBQUssQ0FBQTtLQUNiO0FBQ0QsUUFBSSxxQkFBUyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7QUFDOUIsYUFBTyxJQUFJLENBQUE7S0FDWixNQUFNO0FBQ0wsYUFBTyxLQUFLLENBQUE7S0FDYjtHQUNGOztBQUVELGdCQUFjLEVBQUMsMEJBQUc7QUFDaEIsUUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDaEIsYUFBTyxJQUFJLENBQUMsV0FBVyxDQUFBO0tBQ3hCOztBQUVELFdBQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQTtHQUNuQjs7QUFFRCxTQUFPLEVBQUMsbUJBQUc7QUFDVCxXQUFPLEVBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxFQUFFLFdBQVcsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBQyxDQUFBO0dBQy9HOztBQUVELG9CQUFrQixFQUFDLDRCQUFDLFdBQVcsRUFBRTtBQUMvQixRQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQTtHQUMvQjtDQUNGIiwiZmlsZSI6Ii9ob21lL3NoYW5lLy5hdG9tL3BhY2thZ2VzL2dvLWNvbmZpZy9saWIvbWFpbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIid1c2UgYmFiZWwnXG5cbmltcG9ydCB7Q29tcG9zaXRlRGlzcG9zYWJsZX0gZnJvbSAnYXRvbSdcbmltcG9ydCB7aXNUcnV0aHksIGlzRmFsc3l9IGZyb20gJy4vY2hlY2snXG5pbXBvcnQge0V4ZWN1dG9yfSBmcm9tICcuL2V4ZWN1dG9yJ1xuXG5leHBvcnQgZGVmYXVsdCB7XG4gIGVudmlyb25tZW50OiBudWxsLFxuICBsb2NhdG9yOiBudWxsLFxuICBzdWJzY3JpcHRpb25zOiBudWxsLFxuICBkZXBlbmRlbmNpZXNJbnN0YWxsZWQ6IG51bGwsXG5cbiAgYWN0aXZhdGUgKCkge1xuICAgIHRoaXMuZGVwZW5kZW5jaWVzSW5zdGFsbGVkID0gZmFsc2VcbiAgICB0aGlzLnN1YnNjcmlwdGlvbnMgPSBuZXcgQ29tcG9zaXRlRGlzcG9zYWJsZSgpXG4gICAgdGhpcy5zdWJzY3JpcHRpb25zLmFkZChhdG9tLmNvbW1hbmRzLmFkZCgnYXRvbS13b3Jrc3BhY2UnLCAnZ28tY29uZmlnOmRldGVjdCcsICgpID0+IHsgfSkpXG4gICAgcmVxdWlyZSgnYXRvbS1wYWNrYWdlLWRlcHMnKS5pbnN0YWxsKCdnby1jb25maWcnKS50aGVuKCgpID0+IHtcbiAgICAgIHRoaXMuZGVwZW5kZW5jaWVzSW5zdGFsbGVkID0gdHJ1ZVxuICAgIH0pLmNhdGNoKChlKSA9PiB7XG4gICAgICBjb25zb2xlLmxvZyhlKVxuICAgIH0pXG4gIH0sXG5cbiAgZGVhY3RpdmF0ZSAoKSB7XG4gICAgdGhpcy5kaXNwb3NlKClcbiAgfSxcblxuICBkaXNwb3NlICgpIHtcbiAgICBpZiAoaXNUcnV0aHkodGhpcy5zdWJzY3JpcHRpb25zKSkge1xuICAgICAgdGhpcy5zdWJzY3JpcHRpb25zLmRpc3Bvc2UoKVxuICAgIH1cbiAgICB0aGlzLnN1YnNjcmlwdGlvbnMgPSBudWxsXG4gICAgdGhpcy5lbnZpcm9ubWVudCA9IG51bGxcbiAgICB0aGlzLmxvY2F0b3IgPSBudWxsXG4gICAgdGhpcy5kZXBlbmRlbmNpZXNJbnN0YWxsZWQgPSBudWxsXG4gIH0sXG5cbiAgZ2V0RXhlY3V0b3IgKG9wdGlvbnMpIHtcbiAgICBsZXQgZSA9IG5ldyBFeGVjdXRvcih7ZW52aXJvbm1lbnRGbjogdGhpcy5nZXRFbnZpcm9ubWVudC5iaW5kKHRoaXMpfSlcbiAgICByZXR1cm4gZVxuICB9LFxuXG4gIGdldExvY2F0b3IgKCkge1xuICAgIGlmIChpc1RydXRoeSh0aGlzLmxvY2F0b3IpKSB7XG4gICAgICByZXR1cm4gdGhpcy5sb2NhdG9yXG4gICAgfVxuICAgIGxldCBMb2NhdG9yID0gcmVxdWlyZSgnLi9sb2NhdG9yJykuTG9jYXRvclxuICAgIHRoaXMubG9jYXRvciA9IG5ldyBMb2NhdG9yKHtcbiAgICAgIGVudmlyb25tZW50OiB0aGlzLmdldEVudmlyb25tZW50LmJpbmQodGhpcyksXG4gICAgICBleGVjdXRvcjogdGhpcy5nZXRFeGVjdXRvcigpLFxuICAgICAgcmVhZHk6IHRoaXMucmVhZHkuYmluZCh0aGlzKVxuICAgIH0pXG4gICAgdGhpcy5zdWJzY3JpcHRpb25zLmFkZCh0aGlzLmxvY2F0b3IpXG4gICAgcmV0dXJuIHRoaXMubG9jYXRvclxuICB9LFxuXG4gIHJlYWR5ICgpIHtcbiAgICBpZiAoaXNGYWxzeSh0aGlzLmRlcGVuZGVuY2llc0luc3RhbGxlZCkpIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgICBpZiAoaXNUcnV0aHkodGhpcy5lbnZpcm9ubWVudCkpIHtcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfSxcblxuICBnZXRFbnZpcm9ubWVudCAoKSB7XG4gICAgaWYgKHRoaXMucmVhZHkoKSkge1xuICAgICAgcmV0dXJuIHRoaXMuZW52aXJvbm1lbnRcbiAgICB9XG5cbiAgICByZXR1cm4gcHJvY2Vzcy5lbnZcbiAgfSxcblxuICBwcm92aWRlICgpIHtcbiAgICByZXR1cm4ge2V4ZWN1dG9yOiB0aGlzLmdldEV4ZWN1dG9yKCksIGxvY2F0b3I6IHRoaXMuZ2V0TG9jYXRvcigpLCBlbnZpcm9ubWVudDogdGhpcy5nZXRFbnZpcm9ubWVudC5iaW5kKHRoaXMpfVxuICB9LFxuXG4gIGNvbnN1bWVFbnZpcm9ubWVudCAoZW52aXJvbm1lbnQpIHtcbiAgICB0aGlzLmVudmlyb25tZW50ID0gZW52aXJvbm1lbnRcbiAgfVxufVxuIl19
//# sourceURL=/home/shane/.atom/packages/go-config/lib/main.js
