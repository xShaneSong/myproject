Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _atom = require('atom');

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _os = require('os');

var _os2 = _interopRequireDefault(_os);

var _child_process = require('child_process');

'use babel';

var Environment = (function () {
  function Environment() {
    _classCallCheck(this, Environment);

    this.subscriptions = new _atom.CompositeDisposable();
  }

  _createClass(Environment, [{
    key: 'dispose',
    value: function dispose() {
      if (this.subscriptions) {
        this.subscriptions.dispose();
      }
      this.subscriptions = null;
      this.env = null;
    }
  }, {
    key: 'processenv',
    value: function processenv() {
      return process.env;
    }
  }, {
    key: 'current',
    value: function current() {
      if (this.env) {
        return this.env;
      }

      if (this.shouldPatchEnvironment()) {
        this.env = this.patchEnvironment();
      } else {
        this.env = this.processenv();
      }

      this.removeDyld();
      return this.env;
    }
  }, {
    key: 'removeDyld',
    value: function removeDyld() {
      if (typeof this.env === 'undefined' || this.env === null) {
        return;
      }

      if (this.env.DYLD_INSERT_LIBRARIES != null) {
        delete this.env.DYLD_INSERT_LIBRARIES;
      }
    }
  }, {
    key: 'patchEnvironment',
    value: function patchEnvironment() {
      var command = this.shell();
      if (command === '/bin/sh') {
        command = '/bin/bash';
      }
      var result = this.execSync(command, null, this.processenv(), ['--login'], 'env');
      if (result && result.code === 0 && result.stdout && result.stdout.length > 0) {
        var newenv = {};
        for (var line of result.stdout.split(_os2['default'].EOL)) {
          if (line.includes('=')) {
            var components = line.split('=');
            if (components.length === 2) {
              newenv[components[0]] = components[1];
            } else if (components.length > 2) {
              var k = components.shift();
              var v = components.join('=');
              newenv[k] = v;
            }
          }
        }
        return newenv;
      }

      return this.processenv();
    }
  }, {
    key: 'execSync',
    value: function execSync(command, cwd) {
      var env = arguments.length <= 2 || arguments[2] === undefined ? this.processenv() : arguments[2];
      var args = arguments.length <= 3 || arguments[3] === undefined ? [] : arguments[3];
      var input = arguments.length <= 4 || arguments[4] === undefined ? null : arguments[4];

      var options = { cwd: null, env: env, encoding: 'utf8' };
      if (cwd && cwd.length > 0) {
        options.cwd = _fs2['default'].realpathSync(cwd);
      }

      if (input && input.length) {
        options.input = input;
      }

      var done = (0, _child_process.spawnSync)(command, args, options);
      var code = done.status;

      var stdout = '';
      if (done.stdout && done.stdout.length > 0) {
        stdout = done.stdout;
      }
      var stderr = '';
      if (done.stderr && done.stderr.length > 0) {
        stderr = done.stderr;
      }
      var error = done.error;
      if (error && error.code) {
        switch (error.code) {
          case 'ENOENT':
            code = 127;
            break;
          case 'ENOTCONN':
            // https://github.com/iojs/io.js/pull/1214
            error = null;
            code = 0;
            break;
        }
      }

      return { code: code, stdout: stdout, stderr: stderr, error: error };
    }
  }, {
    key: 'shouldPatchEnvironment',
    value: function shouldPatchEnvironment() {
      var p = this.processenv();
      if (this.platform() === 'darwin' && p.PATH === '/usr/bin:/bin:/usr/sbin:/sbin') {
        return true;
      } else {
        return false;
      }
    }
  }, {
    key: 'platform',
    value: function platform() {
      return process.platform;
    }
  }, {
    key: 'shell',
    value: function shell() {
      var p = this.processenv();
      return p && p.SHELL;
    }
  }]);

  return Environment;
})();

exports.Environment = Environment;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL3NoYW5lLy5hdG9tL3BhY2thZ2VzL2Vudmlyb25tZW50L2xpYi9lbnZpcm9ubWVudC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O29CQUVrQyxNQUFNOztrQkFDekIsSUFBSTs7OztrQkFDSixJQUFJOzs7OzZCQUNLLGVBQWU7O0FBTHZDLFdBQVcsQ0FBQTs7SUFPRSxXQUFXO0FBQ1YsV0FERCxXQUFXLEdBQ1A7MEJBREosV0FBVzs7QUFFcEIsUUFBSSxDQUFDLGFBQWEsR0FBRywrQkFBeUIsQ0FBQTtHQUMvQzs7ZUFIVSxXQUFXOztXQUtkLG1CQUFHO0FBQ1QsVUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFO0FBQ3RCLFlBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLENBQUE7T0FDN0I7QUFDRCxVQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQTtBQUN6QixVQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQTtLQUNoQjs7O1dBRVUsc0JBQUc7QUFDWixhQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUE7S0FDbkI7OztXQUVPLG1CQUFHO0FBQ1QsVUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFO0FBQ1osZUFBTyxJQUFJLENBQUMsR0FBRyxDQUFBO09BQ2hCOztBQUVELFVBQUksSUFBSSxDQUFDLHNCQUFzQixFQUFFLEVBQUU7QUFDakMsWUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQTtPQUNuQyxNQUFNO0FBQ0wsWUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUE7T0FDN0I7O0FBRUQsVUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFBO0FBQ2pCLGFBQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQTtLQUNoQjs7O1dBRVUsc0JBQUc7QUFDWixVQUFJLE9BQU8sSUFBSSxDQUFDLEdBQUcsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDLEdBQUcsS0FBSyxJQUFJLEVBQUU7QUFDeEQsZUFBTTtPQUNQOztBQUVELFVBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsSUFBSSxJQUFJLEVBQUU7QUFDMUMsZUFBTyxJQUFJLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFBO09BQ3RDO0tBQ0Y7OztXQUVnQiw0QkFBRztBQUNsQixVQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUE7QUFDMUIsVUFBSSxPQUFPLEtBQUssU0FBUyxFQUFFO0FBQ3pCLGVBQU8sR0FBRyxXQUFXLENBQUE7T0FDdEI7QUFDRCxVQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUMsU0FBUyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUE7QUFDaEYsVUFBSSxNQUFNLElBQUksTUFBTSxDQUFDLElBQUksS0FBSyxDQUFDLElBQUksTUFBTSxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7QUFDNUUsWUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFBO0FBQ2YsYUFBSyxJQUFJLElBQUksSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxnQkFBRyxHQUFHLENBQUMsRUFBRTtBQUM1QyxjQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7QUFDdEIsZ0JBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDaEMsZ0JBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7QUFDM0Isb0JBQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUE7YUFDdEMsTUFBTSxJQUFJLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO0FBQ2hDLGtCQUFJLENBQUMsR0FBRyxVQUFVLENBQUMsS0FBSyxFQUFFLENBQUE7QUFDMUIsa0JBQUksQ0FBQyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDNUIsb0JBQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUE7YUFDZDtXQUNGO1NBQ0Y7QUFDRCxlQUFPLE1BQU0sQ0FBQTtPQUNkOztBQUVELGFBQU8sSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFBO0tBQ3pCOzs7V0FFUSxrQkFBQyxPQUFPLEVBQUUsR0FBRyxFQUFvRDtVQUFsRCxHQUFHLHlEQUFHLElBQUksQ0FBQyxVQUFVLEVBQUU7VUFBRSxJQUFJLHlEQUFHLEVBQUU7VUFBRSxLQUFLLHlEQUFHLElBQUk7O0FBQ3RFLFVBQUksT0FBTyxHQUFHLEVBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRSxNQUFNLEVBQUMsQ0FBQTtBQUNyRCxVQUFJLEdBQUcsSUFBSSxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtBQUN6QixlQUFPLENBQUMsR0FBRyxHQUFHLGdCQUFHLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQTtPQUNuQzs7QUFFRCxVQUFJLEtBQUssSUFBSSxLQUFLLENBQUMsTUFBTSxFQUFFO0FBQ3pCLGVBQU8sQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFBO09BQ3RCOztBQUVELFVBQUksSUFBSSxHQUFHLDhCQUFVLE9BQU8sRUFBRSxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUE7QUFDNUMsVUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQTs7QUFFdEIsVUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFBO0FBQ2YsVUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtBQUN6QyxjQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQTtPQUNyQjtBQUNELFVBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQTtBQUNmLFVBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7QUFDekMsY0FBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUE7T0FDckI7QUFDRCxVQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFBO0FBQ3RCLFVBQUksS0FBSyxJQUFJLEtBQUssQ0FBQyxJQUFJLEVBQUU7QUFDdkIsZ0JBQVEsS0FBSyxDQUFDLElBQUk7QUFDaEIsZUFBSyxRQUFRO0FBQ1gsZ0JBQUksR0FBRyxHQUFHLENBQUE7QUFDVixrQkFBSztBQUFBLEFBQ1AsZUFBSyxVQUFVOztBQUNiLGlCQUFLLEdBQUcsSUFBSSxDQUFBO0FBQ1osZ0JBQUksR0FBRyxDQUFDLENBQUE7QUFDUixrQkFBSztBQUFBLFNBQ1I7T0FDRjs7QUFFRCxhQUFPLEVBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBQyxDQUFBO0tBQ2xFOzs7V0FFc0Isa0NBQUc7QUFDeEIsVUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFBO0FBQ3pCLFVBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxLQUFLLFFBQVEsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLCtCQUErQixFQUFFO0FBQzlFLGVBQU8sSUFBSSxDQUFBO09BQ1osTUFBTTtBQUNMLGVBQU8sS0FBSyxDQUFBO09BQ2I7S0FDRjs7O1dBRVEsb0JBQUc7QUFDVixhQUFPLE9BQU8sQ0FBQyxRQUFRLENBQUE7S0FDeEI7OztXQUVLLGlCQUFHO0FBQ1AsVUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFBO0FBQ3pCLGFBQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUE7S0FDcEI7OztTQXpIVSxXQUFXIiwiZmlsZSI6Ii9ob21lL3NoYW5lLy5hdG9tL3BhY2thZ2VzL2Vudmlyb25tZW50L2xpYi9lbnZpcm9ubWVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbIid1c2UgYmFiZWwnXG5cbmltcG9ydCB7Q29tcG9zaXRlRGlzcG9zYWJsZX0gZnJvbSAnYXRvbSdcbmltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBvcyBmcm9tICdvcydcbmltcG9ydCB7c3Bhd25TeW5jfSBmcm9tICdjaGlsZF9wcm9jZXNzJ1xuXG5leHBvcnQgY2xhc3MgRW52aXJvbm1lbnQge1xuICBjb25zdHJ1Y3RvciAoKSB7XG4gICAgdGhpcy5zdWJzY3JpcHRpb25zID0gbmV3IENvbXBvc2l0ZURpc3Bvc2FibGUoKVxuICB9XG5cbiAgZGlzcG9zZSAoKSB7XG4gICAgaWYgKHRoaXMuc3Vic2NyaXB0aW9ucykge1xuICAgICAgdGhpcy5zdWJzY3JpcHRpb25zLmRpc3Bvc2UoKVxuICAgIH1cbiAgICB0aGlzLnN1YnNjcmlwdGlvbnMgPSBudWxsXG4gICAgdGhpcy5lbnYgPSBudWxsXG4gIH1cblxuICBwcm9jZXNzZW52ICgpIHtcbiAgICByZXR1cm4gcHJvY2Vzcy5lbnZcbiAgfVxuXG4gIGN1cnJlbnQgKCkge1xuICAgIGlmICh0aGlzLmVudikge1xuICAgICAgcmV0dXJuIHRoaXMuZW52XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuc2hvdWxkUGF0Y2hFbnZpcm9ubWVudCgpKSB7XG4gICAgICB0aGlzLmVudiA9IHRoaXMucGF0Y2hFbnZpcm9ubWVudCgpXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuZW52ID0gdGhpcy5wcm9jZXNzZW52KClcbiAgICB9XG5cbiAgICB0aGlzLnJlbW92ZUR5bGQoKVxuICAgIHJldHVybiB0aGlzLmVudlxuICB9XG5cbiAgcmVtb3ZlRHlsZCAoKSB7XG4gICAgaWYgKHR5cGVvZiB0aGlzLmVudiA9PT0gJ3VuZGVmaW5lZCcgfHwgdGhpcy5lbnYgPT09IG51bGwpIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGlmICh0aGlzLmVudi5EWUxEX0lOU0VSVF9MSUJSQVJJRVMgIT0gbnVsbCkge1xuICAgICAgZGVsZXRlIHRoaXMuZW52LkRZTERfSU5TRVJUX0xJQlJBUklFU1xuICAgIH1cbiAgfVxuXG4gIHBhdGNoRW52aXJvbm1lbnQgKCkge1xuICAgIGxldCBjb21tYW5kID0gdGhpcy5zaGVsbCgpXG4gICAgaWYgKGNvbW1hbmQgPT09ICcvYmluL3NoJykge1xuICAgICAgY29tbWFuZCA9ICcvYmluL2Jhc2gnXG4gICAgfVxuICAgIGxldCByZXN1bHQgPSB0aGlzLmV4ZWNTeW5jKGNvbW1hbmQsIG51bGwsIHRoaXMucHJvY2Vzc2VudigpLCBbJy0tbG9naW4nXSwgJ2VudicpXG4gICAgaWYgKHJlc3VsdCAmJiByZXN1bHQuY29kZSA9PT0gMCAmJiByZXN1bHQuc3Rkb3V0ICYmIHJlc3VsdC5zdGRvdXQubGVuZ3RoID4gMCkge1xuICAgICAgbGV0IG5ld2VudiA9IHt9XG4gICAgICBmb3IgKGxldCBsaW5lIG9mIHJlc3VsdC5zdGRvdXQuc3BsaXQob3MuRU9MKSkge1xuICAgICAgICBpZiAobGluZS5pbmNsdWRlcygnPScpKSB7XG4gICAgICAgICAgbGV0IGNvbXBvbmVudHMgPSBsaW5lLnNwbGl0KCc9JylcbiAgICAgICAgICBpZiAoY29tcG9uZW50cy5sZW5ndGggPT09IDIpIHtcbiAgICAgICAgICAgIG5ld2Vudltjb21wb25lbnRzWzBdXSA9IGNvbXBvbmVudHNbMV1cbiAgICAgICAgICB9IGVsc2UgaWYgKGNvbXBvbmVudHMubGVuZ3RoID4gMikge1xuICAgICAgICAgICAgbGV0IGsgPSBjb21wb25lbnRzLnNoaWZ0KClcbiAgICAgICAgICAgIGxldCB2ID0gY29tcG9uZW50cy5qb2luKCc9JylcbiAgICAgICAgICAgIG5ld2VudltrXSA9IHZcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBuZXdlbnZcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5wcm9jZXNzZW52KClcbiAgfVxuXG4gIGV4ZWNTeW5jIChjb21tYW5kLCBjd2QsIGVudiA9IHRoaXMucHJvY2Vzc2VudigpLCBhcmdzID0gW10sIGlucHV0ID0gbnVsbCkge1xuICAgIGxldCBvcHRpb25zID0ge2N3ZDogbnVsbCwgZW52OiBlbnYsIGVuY29kaW5nOiAndXRmOCd9XG4gICAgaWYgKGN3ZCAmJiBjd2QubGVuZ3RoID4gMCkge1xuICAgICAgb3B0aW9ucy5jd2QgPSBmcy5yZWFscGF0aFN5bmMoY3dkKVxuICAgIH1cblxuICAgIGlmIChpbnB1dCAmJiBpbnB1dC5sZW5ndGgpIHtcbiAgICAgIG9wdGlvbnMuaW5wdXQgPSBpbnB1dFxuICAgIH1cblxuICAgIGxldCBkb25lID0gc3Bhd25TeW5jKGNvbW1hbmQsIGFyZ3MsIG9wdGlvbnMpXG4gICAgbGV0IGNvZGUgPSBkb25lLnN0YXR1c1xuXG4gICAgbGV0IHN0ZG91dCA9ICcnXG4gICAgaWYgKGRvbmUuc3Rkb3V0ICYmIGRvbmUuc3Rkb3V0Lmxlbmd0aCA+IDApIHtcbiAgICAgIHN0ZG91dCA9IGRvbmUuc3Rkb3V0XG4gICAgfVxuICAgIGxldCBzdGRlcnIgPSAnJ1xuICAgIGlmIChkb25lLnN0ZGVyciAmJiBkb25lLnN0ZGVyci5sZW5ndGggPiAwKSB7XG4gICAgICBzdGRlcnIgPSBkb25lLnN0ZGVyclxuICAgIH1cbiAgICBsZXQgZXJyb3IgPSBkb25lLmVycm9yXG4gICAgaWYgKGVycm9yICYmIGVycm9yLmNvZGUpIHtcbiAgICAgIHN3aXRjaCAoZXJyb3IuY29kZSkge1xuICAgICAgICBjYXNlICdFTk9FTlQnOlxuICAgICAgICAgIGNvZGUgPSAxMjdcbiAgICAgICAgICBicmVha1xuICAgICAgICBjYXNlICdFTk9UQ09OTic6IC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9pb2pzL2lvLmpzL3B1bGwvMTIxNFxuICAgICAgICAgIGVycm9yID0gbnVsbFxuICAgICAgICAgIGNvZGUgPSAwXG4gICAgICAgICAgYnJlYWtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4ge2NvZGU6IGNvZGUsIHN0ZG91dDogc3Rkb3V0LCBzdGRlcnI6IHN0ZGVyciwgZXJyb3I6IGVycm9yfVxuICB9XG5cbiAgc2hvdWxkUGF0Y2hFbnZpcm9ubWVudCAoKSB7XG4gICAgbGV0IHAgPSB0aGlzLnByb2Nlc3NlbnYoKVxuICAgIGlmICh0aGlzLnBsYXRmb3JtKCkgPT09ICdkYXJ3aW4nICYmIHAuUEFUSCA9PT0gJy91c3IvYmluOi9iaW46L3Vzci9zYmluOi9zYmluJykge1xuICAgICAgcmV0dXJuIHRydWVcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuICB9XG5cbiAgcGxhdGZvcm0gKCkge1xuICAgIHJldHVybiBwcm9jZXNzLnBsYXRmb3JtXG4gIH1cblxuICBzaGVsbCAoKSB7XG4gICAgbGV0IHAgPSB0aGlzLnByb2Nlc3NlbnYoKVxuICAgIHJldHVybiBwICYmIHAuU0hFTExcbiAgfVxufVxuIl19
//# sourceURL=/home/shane/.atom/packages/environment/lib/environment.js
