(function() {
  var Dispatch, Emitter, Environment, Executor, GoExecutable, Gobuild, Gocover, Godef, Gofmt, Golint, Gopath, Govet, LineMessageView, MessagePanelView, PlainMessageView, SplicerSplitter, Subscriber, async, os, path, _, _ref, _ref1,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

  _ref = require('emissary'), Subscriber = _ref.Subscriber, Emitter = _ref.Emitter;

  Gofmt = require('./gofmt');

  Govet = require('./govet');

  Golint = require('./golint');

  Gopath = require('./gopath');

  Gobuild = require('./gobuild');

  Gocover = require('./gocover');

  Executor = require('./executor');

  Environment = require('./environment');

  GoExecutable = require('./goexecutable');

  Godef = require('./godef');

  SplicerSplitter = require('./util/splicersplitter');

  _ = require('underscore-plus');

  _ref1 = require('atom-message-panel'), MessagePanelView = _ref1.MessagePanelView, LineMessageView = _ref1.LineMessageView, PlainMessageView = _ref1.PlainMessageView;

  path = require('path');

  os = require('os');

  async = require('async');

  module.exports = Dispatch = (function() {
    Subscriber.includeInto(Dispatch);

    Emitter.includeInto(Dispatch);

    function Dispatch() {
      this.gettools = __bind(this.gettools, this);
      this.displayGoInfo = __bind(this.displayGoInfo, this);
      this.emitReady = __bind(this.emitReady, this);
      this.displayMessages = __bind(this.displayMessages, this);
      this.resetAndDisplayMessages = __bind(this.resetAndDisplayMessages, this);
      this.detect = __bind(this.detect, this);
      this.handleEvents = __bind(this.handleEvents, this);
      this.subscribeToAtomEvents = __bind(this.subscribeToAtomEvents, this);
      this.destroy = __bind(this.destroy, this);
      var gobuildsubscription, gocoversubscription, gofmtsubscription, golintsubscription, gopathsubscription, govetsubscription;
      this.activated = false;
      this.dispatching = false;
      this.ready = false;
      this.messages = [];
      this.items = [];
      this.environment = new Environment(process.env);
      this.executor = new Executor(this.environment.Clone());
      this.splicersplitter = new SplicerSplitter();
      this.goexecutable = new GoExecutable(this.env());
      this.gofmt = new Gofmt(this);
      this.govet = new Govet(this);
      this.golint = new Golint(this);
      this.gopath = new Gopath(this);
      this.gobuild = new Gobuild(this);
      this.gocover = new Gocover(this);
      this.godef = new Godef(this);
      if (this.messagepanel == null) {
        this.messagepanel = new MessagePanelView({
          title: '<span class="icon-diff-added"></span> go-plus',
          rawTitle: true
        });
      }
      gofmtsubscription = this.gofmt.on('reset', (function(_this) {
        return function(editor) {
          return _this.resetState(editor);
        };
      })(this));
      golintsubscription = this.golint.on('reset', (function(_this) {
        return function(editor) {
          return _this.resetState(editor);
        };
      })(this));
      govetsubscription = this.govet.on('reset', (function(_this) {
        return function(editor) {
          return _this.resetState(editor);
        };
      })(this));
      gopathsubscription = this.gopath.on('reset', (function(_this) {
        return function(editor) {
          return _this.resetState(editor);
        };
      })(this));
      gobuildsubscription = this.gobuild.on('reset', (function(_this) {
        return function(editor) {
          return _this.resetState(editor);
        };
      })(this));
      gocoversubscription = this.gocover.on('reset', (function(_this) {
        return function(editor) {
          return _this.resetState(editor);
        };
      })(this));
      this.subscribe(gofmtsubscription);
      this.subscribe(golintsubscription);
      this.subscribe(govetsubscription);
      this.subscribe(gopathsubscription);
      this.subscribe(gobuildsubscription);
      this.subscribe(gocoversubscription);
      this.on('dispatch-complete', (function(_this) {
        return function(editor) {
          return _this.displayMessages(editor);
        };
      })(this));
      this.subscribeToAtomEvents();
      this.detect();
    }

    Dispatch.prototype.destroy = function() {
      var _ref2;
      this.destroyItems();
      this.unsubscribe();
      this.resetPanel();
      if ((_ref2 = this.messagepanel) != null) {
        _ref2.remove();
      }
      this.messagepanel = null;
      this.gocover.destroy();
      this.gobuild.destroy();
      this.golint.destroy();
      this.govet.destroy();
      this.gopath.destroy();
      this.gofmt.destroy();
      this.godef.destroy();
      this.gocover = null;
      this.gobuild = null;
      this.golint = null;
      this.govet = null;
      this.gopath = null;
      this.gofmt = null;
      this.godef = null;
      this.ready = false;
      this.activated = false;
      return this.emit('destroyed');
    };

    Dispatch.prototype.addItem = function(item) {
      if (__indexOf.call(this.items, item) >= 0) {
        return;
      }
      if (typeof item.on === 'function') {
        this.subscribe(item, 'destroyed', (function(_this) {
          return function() {
            return _this.removeItem(item);
          };
        })(this));
      }
      return this.items.splice(0, 0, item);
    };

    Dispatch.prototype.removeItem = function(item) {
      var index;
      index = this.items.indexOf(item);
      if (index === -1) {
        return;
      }
      if (typeof item.on === 'function') {
        this.unsubscribe(item);
      }
      return this.items.splice(index, 1);
    };

    Dispatch.prototype.destroyItems = function() {
      var item, _i, _len, _ref2, _results;
      if (!(this.items && _.size(this.items) > 0)) {
        return;
      }
      _ref2 = this.items;
      _results = [];
      for (_i = 0, _len = _ref2.length; _i < _len; _i++) {
        item = _ref2[_i];
        _results.push(item.dispose());
      }
      return _results;
    };

    Dispatch.prototype.subscribeToAtomEvents = function() {
      this.addItem(atom.workspace.observeTextEditors((function(_this) {
        return function(editor) {
          return _this.handleEvents(editor);
        };
      })(this)));
      this.addItem(atom.workspace.onDidChangeActivePaneItem((function(_this) {
        return function(event) {
          return _this.resetPanel();
        };
      })(this)));
      this.addItem(atom.config.observe('go-plus.getMissingTools', (function(_this) {
        return function() {
          if ((atom.config.get('go-plus.getMissingTools') != null) && atom.config.get('go-plus.getMissingTools') && _this.ready) {
            return _this.gettools(false);
          }
        };
      })(this)));
      this.addItem(atom.config.observe('go-plus.formatTool', (function(_this) {
        return function() {
          if (_this.ready) {
            return _this.displayGoInfo(true);
          }
        };
      })(this)));
      this.addItem(atom.config.observe('go-plus.goPath', (function(_this) {
        return function() {
          if (_this.ready) {
            return _this.displayGoInfo(true);
          }
        };
      })(this)));
      this.addItem(atom.config.observe('go-plus.environmentOverridesConfiguration', (function(_this) {
        return function() {
          if (_this.ready) {
            return _this.displayGoInfo(true);
          }
        };
      })(this)));
      this.addItem(atom.config.observe('go-plus.goInstallation', (function(_this) {
        return function() {
          if (_this.ready) {
            return _this.detect();
          }
        };
      })(this)));
      atom.commands.add('atom-workspace', {
        'golang:goinfo': (function(_this) {
          return function() {
            if (_this.ready && _this.activated) {
              return _this.displayGoInfo(true);
            }
          };
        })(this)
      });
      atom.commands.add('atom-workspace', {
        'golang:getmissingtools': (function(_this) {
          return function() {
            if (_this.activated) {
              return _this.gettools(false);
            }
          };
        })(this)
      });
      atom.commands.add('atom-workspace', {
        'golang:updatetools': (function(_this) {
          return function() {
            if (_this.activated) {
              return _this.gettools(true);
            }
          };
        })(this)
      });
      return this.activated = true;
    };

    Dispatch.prototype.handleEvents = function(editor) {
      var buffer, destroyedsubscription, modifiedsubscription, savedsubscription;
      buffer = editor != null ? editor.getBuffer() : void 0;
      if (buffer == null) {
        return;
      }
      this.updateGutter(editor, this.messages);
      modifiedsubscription = buffer.onDidStopChanging((function(_this) {
        return function() {
          if (!_this.activated) {
            return;
          }
          return _this.handleBufferChanged(editor);
        };
      })(this));
      savedsubscription = buffer.onDidSave((function(_this) {
        return function() {
          if (!_this.activated) {
            return;
          }
          if (!!_this.dispatching) {
            return;
          }
          return _this.handleBufferSave(editor, true);
        };
      })(this));
      destroyedsubscription = buffer.onDidDestroy((function(_this) {
        return function() {
          if (savedsubscription != null) {
            savedsubscription.dispose();
          }
          if (savedsubscription != null) {
            _this.removeItem(savedsubscription);
          }
          if (modifiedsubscription != null) {
            modifiedsubscription.dispose();
          }
          if (modifiedsubscription != null) {
            return _this.removeItem(modifiedsubscription);
          }
        };
      })(this));
      this.addItem(modifiedsubscription);
      this.addItem(savedsubscription);
      return this.addItem(destroyedsubscription);
    };

    Dispatch.prototype.detect = function() {
      this.ready = false;
      return this.goexecutable.detect().then((function(_this) {
        return function(gos) {
          if ((atom.config.get('go-plus.getMissingTools') != null) && atom.config.get('go-plus.getMissingTools')) {
            _this.gettools(false);
          }
          _this.displayGoInfo(false);
          return _this.emitReady();
        };
      })(this));
    };

    Dispatch.prototype.resetAndDisplayMessages = function(editor, msgs) {
      if (!this.isValidEditor(editor)) {
        return;
      }
      this.resetState(editor);
      this.collectMessages(msgs);
      return this.displayMessages(editor);
    };

    Dispatch.prototype.displayMessages = function(editor) {
      this.updatePane(editor, this.messages);
      this.updateGutter(editor, this.messages);
      this.dispatching = false;
      return this.emit('display-complete');
    };

    Dispatch.prototype.emitReady = function() {
      this.ready = true;
      return this.emit('ready');
    };

    Dispatch.prototype.displayGoInfo = function(force) {
      var editor, go, gopath, thepath, _ref2, _ref3, _ref4, _ref5;
      editor = (_ref2 = atom.workspace) != null ? _ref2.getActiveTextEditor() : void 0;
      if (!force) {
        if (!this.isValidEditor(editor)) {
          return;
        }
      }
      this.resetPanel();
      go = this.goexecutable.current();
      if ((go != null) && (go.executable != null) && go.executable.trim() !== '') {
        this.messagepanel.add(new PlainMessageView({
          raw: true,
          message: '<b>Go:</b> ' + go.name + ' (@' + go.executable + ')',
          className: 'text-info'
        }));
        gopath = go.buildgopath();
        if ((gopath != null) && gopath.trim() !== '') {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>GOPATH:</b> ' + gopath,
            className: 'text-highlight'
          }));
        } else {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>GOPATH:</b> Not Set (You Should Try Launching Atom Using The Shell Commands...)',
            className: 'text-error'
          }));
        }
        if ((go.cover() != null) && go.cover() !== false) {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Cover Tool:</b> ' + go.cover(),
            className: 'text-subtle'
          }));
        } else {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Cover Tool:</b> Not Found',
            className: 'text-error'
          }));
        }
        if ((go.vet() != null) && go.vet() !== false) {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Vet Tool:</b> ' + go.vet(),
            className: 'text-subtle'
          }));
        } else {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Vet Tool:</b> Not Found',
            className: 'text-error'
          }));
        }
        if ((go.format() != null) && go.format() !== false) {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Format Tool:</b> ' + go.format(),
            className: 'text-subtle'
          }));
        } else {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Format Tool (' + atom.config.get('go-plus.formatTool') + '):</b> Not Found',
            className: 'text-error'
          }));
        }
        if ((go.golint() != null) && go.golint() !== false) {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Lint Tool:</b> ' + go.golint(),
            className: 'text-subtle'
          }));
        } else {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Lint Tool:</b> Not Found',
            className: 'text-error'
          }));
        }
        if ((go.gocode() != null) && go.gocode() !== false) {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Gocode Tool:</b> ' + go.gocode(),
            className: 'text-subtle'
          }));
        } else {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Gocode Tool:</b> Not Found',
            className: 'text-error'
          }));
        }
        if ((go.godef() != null) && go.godef() !== false) {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Godef Tool:</b> ' + go.godef(),
            className: 'text-subtle'
          }));
        } else {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Godef Tool:</b> Not Found',
            className: 'text-error'
          }));
        }
        if (_.contains(atom.packages.getAvailablePackageNames(), 'autocomplete-plus')) {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Gocode Status:</b> Enabled',
            className: 'text-subtle'
          }));
        } else {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Gocode Status:</b> Not Enabled (autocomplete-plus needs to be installed and active; install it and restart)',
            className: 'text-warning'
          }));
        }
        if ((go.oracle() != null) && go.oracle() !== false) {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Oracle Tool: ' + go.oracle(),
            className: 'text-subtle'
          }));
        } else {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Oracle Tool: Not Found',
            className: 'text-error'
          }));
        }
        if ((go.git() != null) && go.git() !== false) {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Git:</b> ' + go.git(),
            className: 'text-subtle'
          }));
        } else {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>Git:</b> Not Found',
            className: 'text-warning'
          }));
        }
        thepath = (_ref3 = this.env()) != null ? _ref3.PATH : void 0;
        if (os.platform() === 'win32') {
          thepath = ((_ref4 = this.env()) != null ? _ref4.Path : void 0) || ((_ref5 = this.env()) != null ? _ref5.PATH : void 0);
        }
        if ((thepath != null) && thepath.trim() !== '') {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>PATH:</b> ' + thepath,
            className: 'text-subtle'
          }));
        } else {
          this.messagepanel.add(new PlainMessageView({
            raw: true,
            message: '<b>PATH:</b> Not Set',
            className: 'text-error'
          }));
        }
      } else {
        this.messagepanel.add(new PlainMessageView({
          raw: true,
          message: 'No Go Installations Were Found',
          className: 'text-error'
        }));
      }
      this.messagepanel.add(new PlainMessageView({
        raw: true,
        message: '<b>Atom:</b> ' + atom.appVersion + ' (' + os.platform() + ' ' + os.arch() + ' ' + os.release() + ')',
        className: 'text-info'
      }));
      return this.messagepanel.attach();
    };

    Dispatch.prototype.collectMessages = function(messages) {
      if ((messages != null) && _.size(messages) > 0) {
        messages = _.flatten(messages);
      }
      messages = _.filter(messages, function(element, index, list) {
        return element != null;
      });
      if (messages == null) {
        return;
      }
      messages = _.filter(messages, function(message) {
        return message != null;
      });
      this.messages = _.union(this.messages, messages);
      this.messages = _.uniq(this.messages, function(element, index, list) {
        return (element != null ? element.line : void 0) + ':' + (element != null ? element.column : void 0) + ':' + (element != null ? element.msg : void 0);
      });
      return this.emit('messages-collected', _.size(this.messages));
    };

    Dispatch.prototype.triggerPipeline = function(editor, saving) {
      var go;
      this.dispatching = true;
      go = this.goexecutable.current();
      if (!((go != null) && (go.executable != null) && go.executable.trim() !== '')) {
        this.displayGoInfo(false);
        this.dispatching = false;
        return;
      }
      async.series([
        (function(_this) {
          return function(callback) {
            return _this.gofmt.formatBuffer(editor, saving, callback);
          };
        })(this)
      ], (function(_this) {
        return function(err, modifymessages) {
          _this.collectMessages(modifymessages);
          return async.parallel([
            function(callback) {
              return _this.govet.checkBuffer(editor, saving, callback);
            }, function(callback) {
              return _this.golint.checkBuffer(editor, saving, callback);
            }, function(callback) {
              return _this.gopath.check(editor, saving, callback);
            }, function(callback) {
              return _this.gobuild.checkBuffer(editor, saving, callback);
            }
          ], function(err, checkmessages) {
            _this.collectMessages(checkmessages);
            return _this.emit('dispatch-complete', editor);
          });
        };
      })(this));
      return async.series([
        (function(_this) {
          return function(callback) {
            return _this.gocover.runCoverage(editor, saving, callback);
          };
        })(this)
      ], (function(_this) {
        return function(err, modifymessages) {
          return _this.emit('coverage-complete');
        };
      })(this));
    };

    Dispatch.prototype.handleBufferSave = function(editor, saving) {
      if (!(this.ready && this.activated)) {
        return;
      }
      if (!this.isValidEditor(editor)) {
        return;
      }
      this.resetState(editor);
      return this.triggerPipeline(editor, saving);
    };

    Dispatch.prototype.handleBufferChanged = function(editor) {
      if (!(this.ready && this.activated)) {
        return;
      }
      if (!this.isValidEditor(editor)) {

      }
    };

    Dispatch.prototype.resetState = function(editor) {
      this.messages = [];
      this.resetGutter(editor);
      return this.resetPanel();
    };

    Dispatch.prototype.resetGutter = function(editor) {
      var marker, markers, _i, _len, _ref2, _results;
      if (!this.isValidEditor(editor)) {
        return;
      }
      markers = editor != null ? (_ref2 = editor.getBuffer()) != null ? _ref2.findMarkers({
        "class": 'go-plus'
      }) : void 0 : void 0;
      if (!((markers != null) && _.size(markers) > 0)) {
        return;
      }
      _results = [];
      for (_i = 0, _len = markers.length; _i < _len; _i++) {
        marker = markers[_i];
        _results.push(marker.destroy());
      }
      return _results;
    };

    Dispatch.prototype.updateGutter = function(editor, messages) {
      var buffer, error, marker, message, skip, _i, _len, _results;
      this.resetGutter(editor);
      if (!this.isValidEditor(editor)) {
        return;
      }
      if (!((messages != null) && messages.length > 0)) {
        return;
      }
      buffer = editor != null ? editor.getBuffer() : void 0;
      if (buffer == null) {
        return;
      }
      _results = [];
      for (_i = 0, _len = messages.length; _i < _len; _i++) {
        message = messages[_i];
        skip = false;
        if (((message != null ? message.file : void 0) != null) && message.file !== '') {
          skip = message.file !== (buffer != null ? buffer.getPath() : void 0);
        }
        if (!skip) {
          if (((message != null ? message.line : void 0) != null) && message.line !== false && message.line >= 0) {
            try {
              marker = buffer != null ? buffer.markPosition([message.line - 1, 0], {
                "class": 'go-plus',
                invalidate: 'touch'
              }) : void 0;
              _results.push(editor != null ? editor.decorateMarker(marker, {
                type: 'line-number',
                "class": 'goplus-' + message.type
              }) : void 0);
            } catch (_error) {
              error = _error;
              _results.push(console.log(error));
            }
          } else {
            _results.push(void 0);
          }
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };

    Dispatch.prototype.resetPanel = function() {
      var _ref2, _ref3;
      if ((_ref2 = this.messagepanel) != null) {
        _ref2.close();
      }
      return (_ref3 = this.messagepanel) != null ? _ref3.clear() : void 0;
    };

    Dispatch.prototype.updatePane = function(editor, messages) {
      var className, column, file, line, message, sortedMessages, _i, _len;
      this.resetPanel;
      if (messages == null) {
        return;
      }
      if (messages.length <= 0 && atom.config.get('go-plus.showPanelWhenNoIssuesExist')) {
        this.messagepanel.add(new PlainMessageView({
          message: 'No Issues',
          className: 'text-success'
        }));
        this.messagepanel.attach();
        return;
      }
      if (!(messages.length > 0)) {
        return;
      }
      if (!atom.config.get('go-plus.showPanel')) {
        return;
      }
      sortedMessages = _.sortBy(this.messages, function(element, index, list) {
        return parseInt(element.line, 10);
      });
      for (_i = 0, _len = sortedMessages.length; _i < _len; _i++) {
        message = sortedMessages[_i];
        className = (function() {
          switch (message.type) {
            case 'error':
              return 'text-error';
            case 'warning':
              return 'text-warning';
            default:
              return 'text-info';
          }
        })();
        file = (message.file != null) && message.file.trim() !== '' ? message.file : null;
        if ((file != null) && file !== '' && ((typeof atom !== "undefined" && atom !== null ? atom.project : void 0) != null)) {
          file = atom.project.relativize(file);
        }
        column = (message.column != null) && message.column !== '' && message.column !== false ? message.column : null;
        line = (message.line != null) && message.line !== '' && message.line !== false ? message.line : null;
        if (file === null && column === null && line === null) {
          this.messagepanel.add(new PlainMessageView({
            message: message.msg,
            className: className
          }));
        } else {
          this.messagepanel.add(new LineMessageView({
            file: file,
            line: line,
            character: column,
            message: message.msg,
            className: className
          }));
        }
      }
      if ((typeof atom !== "undefined" && atom !== null ? atom.workspace : void 0) != null) {
        return this.messagepanel.attach();
      }
    };

    Dispatch.prototype.isValidEditor = function(editor) {
      var _ref2;
      return (editor != null ? (_ref2 = editor.getGrammar()) != null ? _ref2.scopeName : void 0 : void 0) === 'source.go';
    };

    Dispatch.prototype.env = function() {
      return this.environment.Clone();
    };

    Dispatch.prototype.gettools = function(updateExistingTools) {
      var thego;
      updateExistingTools = (updateExistingTools != null) && updateExistingTools;
      this.ready = false;
      thego = this.goexecutable.current();
      if (!((thego != null) && (thego.executable != null) && thego.executable.trim() !== '')) {
        this.displayGoInfo(false);
        return;
      }
      if (!(thego.toolsAreMissing() || updateExistingTools)) {
        this.emitReady();
        return;
      }
      this.resetPanel();
      this.messagepanel.add(new PlainMessageView({
        message: 'Running `go get -u` to get required tools...',
        className: 'text-success'
      }));
      this.messagepanel.attach();
      this.goexecutable.on('gettools-complete', (function(_this) {
        return function() {
          _this.displayGoInfo(true);
          return _this.emitReady();
        };
      })(this));
      return this.goexecutable.gettools(thego, updateExistingTools);
    };

    return Dispatch;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvZ28tcGx1cy9saWIvZGlzcGF0Y2guY29mZmVlIgogIF0sCiAgIm5hbWVzIjogW10sCiAgIm1hcHBpbmdzIjogIkFBQUE7QUFBQSxNQUFBLGdPQUFBO0lBQUE7eUpBQUE7O0FBQUEsRUFBQSxPQUF3QixPQUFBLENBQVEsVUFBUixDQUF4QixFQUFDLGtCQUFBLFVBQUQsRUFBYSxlQUFBLE9BQWIsQ0FBQTs7QUFBQSxFQUNBLEtBQUEsR0FBUSxPQUFBLENBQVEsU0FBUixDQURSLENBQUE7O0FBQUEsRUFFQSxLQUFBLEdBQVEsT0FBQSxDQUFRLFNBQVIsQ0FGUixDQUFBOztBQUFBLEVBR0EsTUFBQSxHQUFTLE9BQUEsQ0FBUSxVQUFSLENBSFQsQ0FBQTs7QUFBQSxFQUlBLE1BQUEsR0FBUyxPQUFBLENBQVEsVUFBUixDQUpULENBQUE7O0FBQUEsRUFLQSxPQUFBLEdBQVUsT0FBQSxDQUFRLFdBQVIsQ0FMVixDQUFBOztBQUFBLEVBTUEsT0FBQSxHQUFVLE9BQUEsQ0FBUSxXQUFSLENBTlYsQ0FBQTs7QUFBQSxFQU9BLFFBQUEsR0FBVyxPQUFBLENBQVEsWUFBUixDQVBYLENBQUE7O0FBQUEsRUFRQSxXQUFBLEdBQWMsT0FBQSxDQUFRLGVBQVIsQ0FSZCxDQUFBOztBQUFBLEVBU0EsWUFBQSxHQUFlLE9BQUEsQ0FBUSxnQkFBUixDQVRmLENBQUE7O0FBQUEsRUFVQSxLQUFBLEdBQVEsT0FBQSxDQUFRLFNBQVIsQ0FWUixDQUFBOztBQUFBLEVBV0EsZUFBQSxHQUFrQixPQUFBLENBQVEsd0JBQVIsQ0FYbEIsQ0FBQTs7QUFBQSxFQVlBLENBQUEsR0FBSSxPQUFBLENBQVEsaUJBQVIsQ0FaSixDQUFBOztBQUFBLEVBYUEsUUFBd0QsT0FBQSxDQUFRLG9CQUFSLENBQXhELEVBQUMseUJBQUEsZ0JBQUQsRUFBbUIsd0JBQUEsZUFBbkIsRUFBb0MseUJBQUEsZ0JBYnBDLENBQUE7O0FBQUEsRUFjQSxJQUFBLEdBQU8sT0FBQSxDQUFRLE1BQVIsQ0FkUCxDQUFBOztBQUFBLEVBZUEsRUFBQSxHQUFLLE9BQUEsQ0FBUSxJQUFSLENBZkwsQ0FBQTs7QUFBQSxFQWdCQSxLQUFBLEdBQVEsT0FBQSxDQUFRLE9BQVIsQ0FoQlIsQ0FBQTs7QUFBQSxFQWtCQSxNQUFNLENBQUMsT0FBUCxHQUNNO0FBQ0osSUFBQSxVQUFVLENBQUMsV0FBWCxDQUF1QixRQUF2QixDQUFBLENBQUE7O0FBQUEsSUFDQSxPQUFPLENBQUMsV0FBUixDQUFvQixRQUFwQixDQURBLENBQUE7O0FBR2EsSUFBQSxrQkFBQSxHQUFBO0FBRVgsaURBQUEsQ0FBQTtBQUFBLDJEQUFBLENBQUE7QUFBQSxtREFBQSxDQUFBO0FBQUEsK0RBQUEsQ0FBQTtBQUFBLCtFQUFBLENBQUE7QUFBQSw2Q0FBQSxDQUFBO0FBQUEseURBQUEsQ0FBQTtBQUFBLDJFQUFBLENBQUE7QUFBQSwrQ0FBQSxDQUFBO0FBQUEsVUFBQSxzSEFBQTtBQUFBLE1BQUEsSUFBQyxDQUFBLFNBQUQsR0FBYSxLQUFiLENBQUE7QUFBQSxNQUNBLElBQUMsQ0FBQSxXQUFELEdBQWUsS0FEZixDQUFBO0FBQUEsTUFFQSxJQUFDLENBQUEsS0FBRCxHQUFTLEtBRlQsQ0FBQTtBQUFBLE1BR0EsSUFBQyxDQUFBLFFBQUQsR0FBWSxFQUhaLENBQUE7QUFBQSxNQUlBLElBQUMsQ0FBQSxLQUFELEdBQVMsRUFKVCxDQUFBO0FBQUEsTUFNQSxJQUFDLENBQUEsV0FBRCxHQUFtQixJQUFBLFdBQUEsQ0FBWSxPQUFPLENBQUMsR0FBcEIsQ0FObkIsQ0FBQTtBQUFBLE1BT0EsSUFBQyxDQUFBLFFBQUQsR0FBZ0IsSUFBQSxRQUFBLENBQVMsSUFBQyxDQUFBLFdBQVcsQ0FBQyxLQUFiLENBQUEsQ0FBVCxDQVBoQixDQUFBO0FBQUEsTUFRQSxJQUFDLENBQUEsZUFBRCxHQUF1QixJQUFBLGVBQUEsQ0FBQSxDQVJ2QixDQUFBO0FBQUEsTUFTQSxJQUFDLENBQUEsWUFBRCxHQUFvQixJQUFBLFlBQUEsQ0FBYSxJQUFDLENBQUEsR0FBRCxDQUFBLENBQWIsQ0FUcEIsQ0FBQTtBQUFBLE1BV0EsSUFBQyxDQUFBLEtBQUQsR0FBYSxJQUFBLEtBQUEsQ0FBTSxJQUFOLENBWGIsQ0FBQTtBQUFBLE1BWUEsSUFBQyxDQUFBLEtBQUQsR0FBYSxJQUFBLEtBQUEsQ0FBTSxJQUFOLENBWmIsQ0FBQTtBQUFBLE1BYUEsSUFBQyxDQUFBLE1BQUQsR0FBYyxJQUFBLE1BQUEsQ0FBTyxJQUFQLENBYmQsQ0FBQTtBQUFBLE1BY0EsSUFBQyxDQUFBLE1BQUQsR0FBYyxJQUFBLE1BQUEsQ0FBTyxJQUFQLENBZGQsQ0FBQTtBQUFBLE1BZUEsSUFBQyxDQUFBLE9BQUQsR0FBZSxJQUFBLE9BQUEsQ0FBUSxJQUFSLENBZmYsQ0FBQTtBQUFBLE1BZ0JBLElBQUMsQ0FBQSxPQUFELEdBQWUsSUFBQSxPQUFBLENBQVEsSUFBUixDQWhCZixDQUFBO0FBQUEsTUFpQkEsSUFBQyxDQUFBLEtBQUQsR0FBYSxJQUFBLEtBQUEsQ0FBTSxJQUFOLENBakJiLENBQUE7QUFtQkEsTUFBQSxJQUFzSCx5QkFBdEg7QUFBQSxRQUFBLElBQUMsQ0FBQSxZQUFELEdBQW9CLElBQUEsZ0JBQUEsQ0FBaUI7QUFBQSxVQUFDLEtBQUEsRUFBTywrQ0FBUjtBQUFBLFVBQXlELFFBQUEsRUFBVSxJQUFuRTtTQUFqQixDQUFwQixDQUFBO09BbkJBO0FBQUEsTUFzQkEsaUJBQUEsR0FBb0IsSUFBQyxDQUFBLEtBQUssQ0FBQyxFQUFQLENBQVUsT0FBVixFQUFtQixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxNQUFELEdBQUE7aUJBQVksS0FBQyxDQUFBLFVBQUQsQ0FBWSxNQUFaLEVBQVo7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFuQixDQXRCcEIsQ0FBQTtBQUFBLE1BdUJBLGtCQUFBLEdBQXFCLElBQUMsQ0FBQSxNQUFNLENBQUMsRUFBUixDQUFXLE9BQVgsRUFBb0IsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsTUFBRCxHQUFBO2lCQUFZLEtBQUMsQ0FBQSxVQUFELENBQVksTUFBWixFQUFaO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBcEIsQ0F2QnJCLENBQUE7QUFBQSxNQXdCQSxpQkFBQSxHQUFvQixJQUFDLENBQUEsS0FBSyxDQUFDLEVBQVAsQ0FBVSxPQUFWLEVBQW1CLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLE1BQUQsR0FBQTtpQkFBWSxLQUFDLENBQUEsVUFBRCxDQUFZLE1BQVosRUFBWjtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQW5CLENBeEJwQixDQUFBO0FBQUEsTUF5QkEsa0JBQUEsR0FBcUIsSUFBQyxDQUFBLE1BQU0sQ0FBQyxFQUFSLENBQVcsT0FBWCxFQUFvQixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxNQUFELEdBQUE7aUJBQVksS0FBQyxDQUFBLFVBQUQsQ0FBWSxNQUFaLEVBQVo7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFwQixDQXpCckIsQ0FBQTtBQUFBLE1BMEJBLG1CQUFBLEdBQXNCLElBQUMsQ0FBQSxPQUFPLENBQUMsRUFBVCxDQUFZLE9BQVosRUFBcUIsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsTUFBRCxHQUFBO2lCQUFZLEtBQUMsQ0FBQSxVQUFELENBQVksTUFBWixFQUFaO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBckIsQ0ExQnRCLENBQUE7QUFBQSxNQTJCQSxtQkFBQSxHQUFzQixJQUFDLENBQUEsT0FBTyxDQUFDLEVBQVQsQ0FBWSxPQUFaLEVBQXFCLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLE1BQUQsR0FBQTtpQkFBWSxLQUFDLENBQUEsVUFBRCxDQUFZLE1BQVosRUFBWjtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXJCLENBM0J0QixDQUFBO0FBQUEsTUE2QkEsSUFBQyxDQUFBLFNBQUQsQ0FBVyxpQkFBWCxDQTdCQSxDQUFBO0FBQUEsTUE4QkEsSUFBQyxDQUFBLFNBQUQsQ0FBVyxrQkFBWCxDQTlCQSxDQUFBO0FBQUEsTUErQkEsSUFBQyxDQUFBLFNBQUQsQ0FBVyxpQkFBWCxDQS9CQSxDQUFBO0FBQUEsTUFnQ0EsSUFBQyxDQUFBLFNBQUQsQ0FBVyxrQkFBWCxDQWhDQSxDQUFBO0FBQUEsTUFpQ0EsSUFBQyxDQUFBLFNBQUQsQ0FBVyxtQkFBWCxDQWpDQSxDQUFBO0FBQUEsTUFrQ0EsSUFBQyxDQUFBLFNBQUQsQ0FBVyxtQkFBWCxDQWxDQSxDQUFBO0FBQUEsTUFvQ0EsSUFBQyxDQUFBLEVBQUQsQ0FBSSxtQkFBSixFQUF5QixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxNQUFELEdBQUE7aUJBQVksS0FBQyxDQUFBLGVBQUQsQ0FBaUIsTUFBakIsRUFBWjtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpCLENBcENBLENBQUE7QUFBQSxNQXFDQSxJQUFDLENBQUEscUJBQUQsQ0FBQSxDQXJDQSxDQUFBO0FBQUEsTUFzQ0EsSUFBQyxDQUFBLE1BQUQsQ0FBQSxDQXRDQSxDQUZXO0lBQUEsQ0FIYjs7QUFBQSx1QkE2Q0EsT0FBQSxHQUFTLFNBQUEsR0FBQTtBQUNQLFVBQUEsS0FBQTtBQUFBLE1BQUEsSUFBQyxDQUFBLFlBQUQsQ0FBQSxDQUFBLENBQUE7QUFBQSxNQUNBLElBQUMsQ0FBQSxXQUFELENBQUEsQ0FEQSxDQUFBO0FBQUEsTUFFQSxJQUFDLENBQUEsVUFBRCxDQUFBLENBRkEsQ0FBQTs7YUFHYSxDQUFFLE1BQWYsQ0FBQTtPQUhBO0FBQUEsTUFJQSxJQUFDLENBQUEsWUFBRCxHQUFnQixJQUpoQixDQUFBO0FBQUEsTUFLQSxJQUFDLENBQUEsT0FBTyxDQUFDLE9BQVQsQ0FBQSxDQUxBLENBQUE7QUFBQSxNQU1BLElBQUMsQ0FBQSxPQUFPLENBQUMsT0FBVCxDQUFBLENBTkEsQ0FBQTtBQUFBLE1BT0EsSUFBQyxDQUFBLE1BQU0sQ0FBQyxPQUFSLENBQUEsQ0FQQSxDQUFBO0FBQUEsTUFRQSxJQUFDLENBQUEsS0FBSyxDQUFDLE9BQVAsQ0FBQSxDQVJBLENBQUE7QUFBQSxNQVNBLElBQUMsQ0FBQSxNQUFNLENBQUMsT0FBUixDQUFBLENBVEEsQ0FBQTtBQUFBLE1BVUEsSUFBQyxDQUFBLEtBQUssQ0FBQyxPQUFQLENBQUEsQ0FWQSxDQUFBO0FBQUEsTUFXQSxJQUFDLENBQUEsS0FBSyxDQUFDLE9BQVAsQ0FBQSxDQVhBLENBQUE7QUFBQSxNQVlBLElBQUMsQ0FBQSxPQUFELEdBQVcsSUFaWCxDQUFBO0FBQUEsTUFhQSxJQUFDLENBQUEsT0FBRCxHQUFXLElBYlgsQ0FBQTtBQUFBLE1BY0EsSUFBQyxDQUFBLE1BQUQsR0FBVSxJQWRWLENBQUE7QUFBQSxNQWVBLElBQUMsQ0FBQSxLQUFELEdBQVMsSUFmVCxDQUFBO0FBQUEsTUFnQkEsSUFBQyxDQUFBLE1BQUQsR0FBVSxJQWhCVixDQUFBO0FBQUEsTUFpQkEsSUFBQyxDQUFBLEtBQUQsR0FBUyxJQWpCVCxDQUFBO0FBQUEsTUFrQkEsSUFBQyxDQUFBLEtBQUQsR0FBUyxJQWxCVCxDQUFBO0FBQUEsTUFtQkEsSUFBQyxDQUFBLEtBQUQsR0FBUyxLQW5CVCxDQUFBO0FBQUEsTUFvQkEsSUFBQyxDQUFBLFNBQUQsR0FBYSxLQXBCYixDQUFBO2FBcUJBLElBQUMsQ0FBQSxJQUFELENBQU0sV0FBTixFQXRCTztJQUFBLENBN0NULENBQUE7O0FBQUEsdUJBcUVBLE9BQUEsR0FBUyxTQUFDLElBQUQsR0FBQTtBQUNQLE1BQUEsSUFBVSxlQUFRLElBQUMsQ0FBQSxLQUFULEVBQUEsSUFBQSxNQUFWO0FBQUEsY0FBQSxDQUFBO09BQUE7QUFFQSxNQUFBLElBQUcsTUFBQSxDQUFBLElBQVcsQ0FBQyxFQUFaLEtBQWtCLFVBQXJCO0FBQ0UsUUFBQSxJQUFDLENBQUEsU0FBRCxDQUFXLElBQVgsRUFBaUIsV0FBakIsRUFBOEIsQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFBLEdBQUE7bUJBQUcsS0FBQyxDQUFBLFVBQUQsQ0FBWSxJQUFaLEVBQUg7VUFBQSxFQUFBO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE5QixDQUFBLENBREY7T0FGQTthQUtBLElBQUMsQ0FBQSxLQUFLLENBQUMsTUFBUCxDQUFjLENBQWQsRUFBaUIsQ0FBakIsRUFBb0IsSUFBcEIsRUFOTztJQUFBLENBckVULENBQUE7O0FBQUEsdUJBNkVBLFVBQUEsR0FBWSxTQUFDLElBQUQsR0FBQTtBQUNWLFVBQUEsS0FBQTtBQUFBLE1BQUEsS0FBQSxHQUFRLElBQUMsQ0FBQSxLQUFLLENBQUMsT0FBUCxDQUFlLElBQWYsQ0FBUixDQUFBO0FBQ0EsTUFBQSxJQUFVLEtBQUEsS0FBUyxDQUFBLENBQW5CO0FBQUEsY0FBQSxDQUFBO09BREE7QUFHQSxNQUFBLElBQUcsTUFBQSxDQUFBLElBQVcsQ0FBQyxFQUFaLEtBQWtCLFVBQXJCO0FBQ0UsUUFBQSxJQUFDLENBQUEsV0FBRCxDQUFhLElBQWIsQ0FBQSxDQURGO09BSEE7YUFNQSxJQUFDLENBQUEsS0FBSyxDQUFDLE1BQVAsQ0FBYyxLQUFkLEVBQXFCLENBQXJCLEVBUFU7SUFBQSxDQTdFWixDQUFBOztBQUFBLHVCQXNGQSxZQUFBLEdBQWMsU0FBQSxHQUFBO0FBQ1osVUFBQSwrQkFBQTtBQUFBLE1BQUEsSUFBQSxDQUFBLENBQWMsSUFBQyxDQUFBLEtBQUQsSUFBVyxDQUFDLENBQUMsSUFBRixDQUFPLElBQUMsQ0FBQSxLQUFSLENBQUEsR0FBaUIsQ0FBMUMsQ0FBQTtBQUFBLGNBQUEsQ0FBQTtPQUFBO0FBQ0E7QUFBQTtXQUFBLDRDQUFBO3lCQUFBO0FBQ0Usc0JBQUEsSUFBSSxDQUFDLE9BQUwsQ0FBQSxFQUFBLENBREY7QUFBQTtzQkFGWTtJQUFBLENBdEZkLENBQUE7O0FBQUEsdUJBMkZBLHFCQUFBLEdBQXVCLFNBQUEsR0FBQTtBQUNyQixNQUFBLElBQUMsQ0FBQSxPQUFELENBQVMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxrQkFBZixDQUFrQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxNQUFELEdBQUE7aUJBQVksS0FBQyxDQUFBLFlBQUQsQ0FBYyxNQUFkLEVBQVo7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFsQyxDQUFULENBQUEsQ0FBQTtBQUFBLE1BQ0EsSUFBQyxDQUFBLE9BQUQsQ0FBUyxJQUFJLENBQUMsU0FBUyxDQUFDLHlCQUFmLENBQXlDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLEtBQUQsR0FBQTtpQkFBVyxLQUFDLENBQUEsVUFBRCxDQUFBLEVBQVg7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF6QyxDQUFULENBREEsQ0FBQTtBQUFBLE1BRUEsSUFBQyxDQUFBLE9BQUQsQ0FBUyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQVosQ0FBb0IseUJBQXBCLEVBQStDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFBLEdBQUE7QUFBRyxVQUFBLElBQW9CLG9EQUFBLElBQWdELElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQix5QkFBaEIsQ0FBaEQsSUFBK0YsS0FBQyxDQUFBLEtBQXBIO21CQUFBLEtBQUMsQ0FBQSxRQUFELENBQVUsS0FBVixFQUFBO1dBQUg7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUEvQyxDQUFULENBRkEsQ0FBQTtBQUFBLE1BR0EsSUFBQyxDQUFBLE9BQUQsQ0FBUyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQVosQ0FBb0Isb0JBQXBCLEVBQTBDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFBLEdBQUE7QUFBRyxVQUFBLElBQXdCLEtBQUMsQ0FBQSxLQUF6QjttQkFBQSxLQUFDLENBQUEsYUFBRCxDQUFlLElBQWYsRUFBQTtXQUFIO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBMUMsQ0FBVCxDQUhBLENBQUE7QUFBQSxNQUlBLElBQUMsQ0FBQSxPQUFELENBQVMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFaLENBQW9CLGdCQUFwQixFQUFzQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQSxHQUFBO0FBQUcsVUFBQSxJQUF3QixLQUFDLENBQUEsS0FBekI7bUJBQUEsS0FBQyxDQUFBLGFBQUQsQ0FBZSxJQUFmLEVBQUE7V0FBSDtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXRDLENBQVQsQ0FKQSxDQUFBO0FBQUEsTUFLQSxJQUFDLENBQUEsT0FBRCxDQUFTLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBWixDQUFvQiwyQ0FBcEIsRUFBaUUsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUEsR0FBQTtBQUFHLFVBQUEsSUFBd0IsS0FBQyxDQUFBLEtBQXpCO21CQUFBLEtBQUMsQ0FBQSxhQUFELENBQWUsSUFBZixFQUFBO1dBQUg7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFqRSxDQUFULENBTEEsQ0FBQTtBQUFBLE1BTUEsSUFBQyxDQUFBLE9BQUQsQ0FBUyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQVosQ0FBb0Isd0JBQXBCLEVBQThDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFBLEdBQUE7QUFBRyxVQUFBLElBQWEsS0FBQyxDQUFBLEtBQWQ7bUJBQUEsS0FBQyxDQUFBLE1BQUQsQ0FBQSxFQUFBO1dBQUg7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE5QyxDQUFULENBTkEsQ0FBQTtBQUFBLE1BUUEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFkLENBQWtCLGdCQUFsQixFQUNFO0FBQUEsUUFBQSxlQUFBLEVBQWlCLENBQUEsU0FBQSxLQUFBLEdBQUE7aUJBQUEsU0FBQSxHQUFBO0FBQUcsWUFBQSxJQUF3QixLQUFDLENBQUEsS0FBRCxJQUFXLEtBQUMsQ0FBQSxTQUFwQztxQkFBQSxLQUFDLENBQUEsYUFBRCxDQUFlLElBQWYsRUFBQTthQUFIO1VBQUEsRUFBQTtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBakI7T0FERixDQVJBLENBQUE7QUFBQSxNQVdBLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBZCxDQUFrQixnQkFBbEIsRUFDRTtBQUFBLFFBQUEsd0JBQUEsRUFBMEIsQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFBLEdBQUE7QUFBRyxZQUFBLElBQW9CLEtBQUMsQ0FBQSxTQUFyQjtxQkFBQSxLQUFDLENBQUEsUUFBRCxDQUFVLEtBQVYsRUFBQTthQUFIO1VBQUEsRUFBQTtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBMUI7T0FERixDQVhBLENBQUE7QUFBQSxNQWNBLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBZCxDQUFrQixnQkFBbEIsRUFDRTtBQUFBLFFBQUEsb0JBQUEsRUFBc0IsQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFBLEdBQUE7QUFBRyxZQUFBLElBQW1CLEtBQUMsQ0FBQSxTQUFwQjtxQkFBQSxLQUFDLENBQUEsUUFBRCxDQUFVLElBQVYsRUFBQTthQUFIO1VBQUEsRUFBQTtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBdEI7T0FERixDQWRBLENBQUE7YUFpQkEsSUFBQyxDQUFBLFNBQUQsR0FBYSxLQWxCUTtJQUFBLENBM0Z2QixDQUFBOztBQUFBLHVCQStHQSxZQUFBLEdBQWMsU0FBQyxNQUFELEdBQUE7QUFDWixVQUFBLHNFQUFBO0FBQUEsTUFBQSxNQUFBLG9CQUFTLE1BQU0sQ0FBRSxTQUFSLENBQUEsVUFBVCxDQUFBO0FBQ0EsTUFBQSxJQUFjLGNBQWQ7QUFBQSxjQUFBLENBQUE7T0FEQTtBQUFBLE1BRUEsSUFBQyxDQUFBLFlBQUQsQ0FBYyxNQUFkLEVBQXNCLElBQUMsQ0FBQSxRQUF2QixDQUZBLENBQUE7QUFBQSxNQUdBLG9CQUFBLEdBQXVCLE1BQU0sQ0FBQyxpQkFBUCxDQUF5QixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQSxHQUFBO0FBQzlDLFVBQUEsSUFBQSxDQUFBLEtBQWUsQ0FBQSxTQUFmO0FBQUEsa0JBQUEsQ0FBQTtXQUFBO2lCQUNBLEtBQUMsQ0FBQSxtQkFBRCxDQUFxQixNQUFyQixFQUY4QztRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpCLENBSHZCLENBQUE7QUFBQSxNQU9BLGlCQUFBLEdBQW9CLE1BQU0sQ0FBQyxTQUFQLENBQWlCLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFBLEdBQUE7QUFDbkMsVUFBQSxJQUFBLENBQUEsS0FBZSxDQUFBLFNBQWY7QUFBQSxrQkFBQSxDQUFBO1dBQUE7QUFDQSxVQUFBLElBQUEsQ0FBQSxDQUFjLEtBQUssQ0FBQSxXQUFuQjtBQUFBLGtCQUFBLENBQUE7V0FEQTtpQkFFQSxLQUFDLENBQUEsZ0JBQUQsQ0FBa0IsTUFBbEIsRUFBMEIsSUFBMUIsRUFIbUM7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFqQixDQVBwQixDQUFBO0FBQUEsTUFZQSxxQkFBQSxHQUF3QixNQUFNLENBQUMsWUFBUCxDQUFvQixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQSxHQUFBOztZQUMxQyxpQkFBaUIsQ0FBRSxPQUFuQixDQUFBO1dBQUE7QUFDQSxVQUFBLElBQWtDLHlCQUFsQztBQUFBLFlBQUEsS0FBQyxDQUFBLFVBQUQsQ0FBWSxpQkFBWixDQUFBLENBQUE7V0FEQTs7WUFFQSxvQkFBb0IsQ0FBRSxPQUF0QixDQUFBO1dBRkE7QUFHQSxVQUFBLElBQXFDLDRCQUFyQzttQkFBQSxLQUFDLENBQUEsVUFBRCxDQUFZLG9CQUFaLEVBQUE7V0FKMEM7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFwQixDQVp4QixDQUFBO0FBQUEsTUFrQkEsSUFBQyxDQUFBLE9BQUQsQ0FBUyxvQkFBVCxDQWxCQSxDQUFBO0FBQUEsTUFtQkEsSUFBQyxDQUFBLE9BQUQsQ0FBUyxpQkFBVCxDQW5CQSxDQUFBO2FBb0JBLElBQUMsQ0FBQSxPQUFELENBQVMscUJBQVQsRUFyQlk7SUFBQSxDQS9HZCxDQUFBOztBQUFBLHVCQXNJQSxNQUFBLEdBQVEsU0FBQSxHQUFBO0FBQ04sTUFBQSxJQUFDLENBQUEsS0FBRCxHQUFTLEtBQVQsQ0FBQTthQUNBLElBQUMsQ0FBQSxZQUFZLENBQUMsTUFBZCxDQUFBLENBQXNCLENBQUMsSUFBdkIsQ0FBNEIsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsR0FBRCxHQUFBO0FBQzFCLFVBQUEsSUFBb0Isb0RBQUEsSUFBZ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLHlCQUFoQixDQUFwRTtBQUFBLFlBQUEsS0FBQyxDQUFBLFFBQUQsQ0FBVSxLQUFWLENBQUEsQ0FBQTtXQUFBO0FBQUEsVUFDQSxLQUFDLENBQUEsYUFBRCxDQUFlLEtBQWYsQ0FEQSxDQUFBO2lCQUVBLEtBQUMsQ0FBQSxTQUFELENBQUEsRUFIMEI7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE1QixFQUZNO0lBQUEsQ0F0SVIsQ0FBQTs7QUFBQSx1QkE2SUEsdUJBQUEsR0FBeUIsU0FBQyxNQUFELEVBQVMsSUFBVCxHQUFBO0FBQ3ZCLE1BQUEsSUFBQSxDQUFBLElBQWUsQ0FBQSxhQUFELENBQWUsTUFBZixDQUFkO0FBQUEsY0FBQSxDQUFBO09BQUE7QUFBQSxNQUNBLElBQUMsQ0FBQSxVQUFELENBQVksTUFBWixDQURBLENBQUE7QUFBQSxNQUVBLElBQUMsQ0FBQSxlQUFELENBQWlCLElBQWpCLENBRkEsQ0FBQTthQUdBLElBQUMsQ0FBQSxlQUFELENBQWlCLE1BQWpCLEVBSnVCO0lBQUEsQ0E3SXpCLENBQUE7O0FBQUEsdUJBbUpBLGVBQUEsR0FBaUIsU0FBQyxNQUFELEdBQUE7QUFDZixNQUFBLElBQUMsQ0FBQSxVQUFELENBQVksTUFBWixFQUFvQixJQUFDLENBQUEsUUFBckIsQ0FBQSxDQUFBO0FBQUEsTUFDQSxJQUFDLENBQUEsWUFBRCxDQUFjLE1BQWQsRUFBc0IsSUFBQyxDQUFBLFFBQXZCLENBREEsQ0FBQTtBQUFBLE1BRUEsSUFBQyxDQUFBLFdBQUQsR0FBZSxLQUZmLENBQUE7YUFHQSxJQUFDLENBQUEsSUFBRCxDQUFNLGtCQUFOLEVBSmU7SUFBQSxDQW5KakIsQ0FBQTs7QUFBQSx1QkF5SkEsU0FBQSxHQUFXLFNBQUEsR0FBQTtBQUNULE1BQUEsSUFBQyxDQUFBLEtBQUQsR0FBUyxJQUFULENBQUE7YUFDQSxJQUFDLENBQUEsSUFBRCxDQUFNLE9BQU4sRUFGUztJQUFBLENBekpYLENBQUE7O0FBQUEsdUJBNkpBLGFBQUEsR0FBZSxTQUFDLEtBQUQsR0FBQTtBQUNiLFVBQUEsdURBQUE7QUFBQSxNQUFBLE1BQUEsMkNBQXVCLENBQUUsbUJBQWhCLENBQUEsVUFBVCxDQUFBO0FBQ0EsTUFBQSxJQUFBLENBQUEsS0FBQTtBQUNFLFFBQUEsSUFBQSxDQUFBLElBQWUsQ0FBQSxhQUFELENBQWUsTUFBZixDQUFkO0FBQUEsZ0JBQUEsQ0FBQTtTQURGO09BREE7QUFBQSxNQUlBLElBQUMsQ0FBQSxVQUFELENBQUEsQ0FKQSxDQUFBO0FBQUEsTUFLQSxFQUFBLEdBQUssSUFBQyxDQUFBLFlBQVksQ0FBQyxPQUFkLENBQUEsQ0FMTCxDQUFBO0FBTUEsTUFBQSxJQUFHLFlBQUEsSUFBUSx1QkFBUixJQUEyQixFQUFFLENBQUMsVUFBVSxDQUFDLElBQWQsQ0FBQSxDQUFBLEtBQTBCLEVBQXhEO0FBQ0UsUUFBQSxJQUFDLENBQUEsWUFBWSxDQUFDLEdBQWQsQ0FBc0IsSUFBQSxnQkFBQSxDQUFpQjtBQUFBLFVBQUMsR0FBQSxFQUFLLElBQU47QUFBQSxVQUFZLE9BQUEsRUFBUyxhQUFBLEdBQWdCLEVBQUUsQ0FBQyxJQUFuQixHQUEwQixLQUExQixHQUFrQyxFQUFFLENBQUMsVUFBckMsR0FBa0QsR0FBdkU7QUFBQSxVQUE0RSxTQUFBLEVBQVcsV0FBdkY7U0FBakIsQ0FBdEIsQ0FBQSxDQUFBO0FBQUEsUUFHQSxNQUFBLEdBQVMsRUFBRSxDQUFDLFdBQUgsQ0FBQSxDQUhULENBQUE7QUFJQSxRQUFBLElBQUcsZ0JBQUEsSUFBWSxNQUFNLENBQUMsSUFBUCxDQUFBLENBQUEsS0FBbUIsRUFBbEM7QUFDRSxVQUFBLElBQUMsQ0FBQSxZQUFZLENBQUMsR0FBZCxDQUFzQixJQUFBLGdCQUFBLENBQWlCO0FBQUEsWUFBQyxHQUFBLEVBQUssSUFBTjtBQUFBLFlBQVksT0FBQSxFQUFTLGlCQUFBLEdBQW9CLE1BQXpDO0FBQUEsWUFBaUQsU0FBQSxFQUFXLGdCQUE1RDtXQUFqQixDQUF0QixDQUFBLENBREY7U0FBQSxNQUFBO0FBR0UsVUFBQSxJQUFDLENBQUEsWUFBWSxDQUFDLEdBQWQsQ0FBc0IsSUFBQSxnQkFBQSxDQUFpQjtBQUFBLFlBQUMsR0FBQSxFQUFLLElBQU47QUFBQSxZQUFZLE9BQUEsRUFBUyxvRkFBckI7QUFBQSxZQUEyRyxTQUFBLEVBQVcsWUFBdEg7V0FBakIsQ0FBdEIsQ0FBQSxDQUhGO1NBSkE7QUFVQSxRQUFBLElBQUcsb0JBQUEsSUFBZ0IsRUFBRSxDQUFDLEtBQUgsQ0FBQSxDQUFBLEtBQWdCLEtBQW5DO0FBQ0UsVUFBQSxJQUFDLENBQUEsWUFBWSxDQUFDLEdBQWQsQ0FBc0IsSUFBQSxnQkFBQSxDQUFpQjtBQUFBLFlBQUMsR0FBQSxFQUFLLElBQU47QUFBQSxZQUFZLE9BQUEsRUFBUyxxQkFBQSxHQUF3QixFQUFFLENBQUMsS0FBSCxDQUFBLENBQTdDO0FBQUEsWUFBeUQsU0FBQSxFQUFXLGFBQXBFO1dBQWpCLENBQXRCLENBQUEsQ0FERjtTQUFBLE1BQUE7QUFHRSxVQUFBLElBQUMsQ0FBQSxZQUFZLENBQUMsR0FBZCxDQUFzQixJQUFBLGdCQUFBLENBQWlCO0FBQUEsWUFBQyxHQUFBLEVBQUssSUFBTjtBQUFBLFlBQVksT0FBQSxFQUFTLDhCQUFyQjtBQUFBLFlBQXFELFNBQUEsRUFBVyxZQUFoRTtXQUFqQixDQUF0QixDQUFBLENBSEY7U0FWQTtBQWdCQSxRQUFBLElBQUcsa0JBQUEsSUFBYyxFQUFFLENBQUMsR0FBSCxDQUFBLENBQUEsS0FBYyxLQUEvQjtBQUNFLFVBQUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxHQUFkLENBQXNCLElBQUEsZ0JBQUEsQ0FBaUI7QUFBQSxZQUFDLEdBQUEsRUFBSyxJQUFOO0FBQUEsWUFBWSxPQUFBLEVBQVMsbUJBQUEsR0FBc0IsRUFBRSxDQUFDLEdBQUgsQ0FBQSxDQUEzQztBQUFBLFlBQXFELFNBQUEsRUFBVyxhQUFoRTtXQUFqQixDQUF0QixDQUFBLENBREY7U0FBQSxNQUFBO0FBR0UsVUFBQSxJQUFDLENBQUEsWUFBWSxDQUFDLEdBQWQsQ0FBc0IsSUFBQSxnQkFBQSxDQUFpQjtBQUFBLFlBQUMsR0FBQSxFQUFLLElBQU47QUFBQSxZQUFZLE9BQUEsRUFBUyw0QkFBckI7QUFBQSxZQUFtRCxTQUFBLEVBQVcsWUFBOUQ7V0FBakIsQ0FBdEIsQ0FBQSxDQUhGO1NBaEJBO0FBc0JBLFFBQUEsSUFBRyxxQkFBQSxJQUFpQixFQUFFLENBQUMsTUFBSCxDQUFBLENBQUEsS0FBaUIsS0FBckM7QUFDRSxVQUFBLElBQUMsQ0FBQSxZQUFZLENBQUMsR0FBZCxDQUFzQixJQUFBLGdCQUFBLENBQWlCO0FBQUEsWUFBQyxHQUFBLEVBQUssSUFBTjtBQUFBLFlBQVksT0FBQSxFQUFTLHNCQUFBLEdBQXlCLEVBQUUsQ0FBQyxNQUFILENBQUEsQ0FBOUM7QUFBQSxZQUEyRCxTQUFBLEVBQVcsYUFBdEU7V0FBakIsQ0FBdEIsQ0FBQSxDQURGO1NBQUEsTUFBQTtBQUdFLFVBQUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxHQUFkLENBQXNCLElBQUEsZ0JBQUEsQ0FBaUI7QUFBQSxZQUFDLEdBQUEsRUFBSyxJQUFOO0FBQUEsWUFBWSxPQUFBLEVBQVMsa0JBQUEsR0FBcUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLG9CQUFoQixDQUFyQixHQUE2RCxrQkFBbEY7QUFBQSxZQUFzRyxTQUFBLEVBQVcsWUFBakg7V0FBakIsQ0FBdEIsQ0FBQSxDQUhGO1NBdEJBO0FBNEJBLFFBQUEsSUFBRyxxQkFBQSxJQUFpQixFQUFFLENBQUMsTUFBSCxDQUFBLENBQUEsS0FBaUIsS0FBckM7QUFDRSxVQUFBLElBQUMsQ0FBQSxZQUFZLENBQUMsR0FBZCxDQUFzQixJQUFBLGdCQUFBLENBQWlCO0FBQUEsWUFBQyxHQUFBLEVBQUssSUFBTjtBQUFBLFlBQVksT0FBQSxFQUFTLG9CQUFBLEdBQXVCLEVBQUUsQ0FBQyxNQUFILENBQUEsQ0FBNUM7QUFBQSxZQUF5RCxTQUFBLEVBQVcsYUFBcEU7V0FBakIsQ0FBdEIsQ0FBQSxDQURGO1NBQUEsTUFBQTtBQUdFLFVBQUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxHQUFkLENBQXNCLElBQUEsZ0JBQUEsQ0FBaUI7QUFBQSxZQUFDLEdBQUEsRUFBSyxJQUFOO0FBQUEsWUFBWSxPQUFBLEVBQVMsNkJBQXJCO0FBQUEsWUFBb0QsU0FBQSxFQUFXLFlBQS9EO1dBQWpCLENBQXRCLENBQUEsQ0FIRjtTQTVCQTtBQWtDQSxRQUFBLElBQUcscUJBQUEsSUFBaUIsRUFBRSxDQUFDLE1BQUgsQ0FBQSxDQUFBLEtBQWlCLEtBQXJDO0FBQ0UsVUFBQSxJQUFDLENBQUEsWUFBWSxDQUFDLEdBQWQsQ0FBc0IsSUFBQSxnQkFBQSxDQUFpQjtBQUFBLFlBQUMsR0FBQSxFQUFLLElBQU47QUFBQSxZQUFZLE9BQUEsRUFBUyxzQkFBQSxHQUF5QixFQUFFLENBQUMsTUFBSCxDQUFBLENBQTlDO0FBQUEsWUFBMkQsU0FBQSxFQUFXLGFBQXRFO1dBQWpCLENBQXRCLENBQUEsQ0FERjtTQUFBLE1BQUE7QUFHRSxVQUFBLElBQUMsQ0FBQSxZQUFZLENBQUMsR0FBZCxDQUFzQixJQUFBLGdCQUFBLENBQWlCO0FBQUEsWUFBQyxHQUFBLEVBQUssSUFBTjtBQUFBLFlBQVksT0FBQSxFQUFTLCtCQUFyQjtBQUFBLFlBQXNELFNBQUEsRUFBVyxZQUFqRTtXQUFqQixDQUF0QixDQUFBLENBSEY7U0FsQ0E7QUF3Q0EsUUFBQSxJQUFHLG9CQUFBLElBQWdCLEVBQUUsQ0FBQyxLQUFILENBQUEsQ0FBQSxLQUFnQixLQUFuQztBQUNFLFVBQUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxHQUFkLENBQXNCLElBQUEsZ0JBQUEsQ0FBaUI7QUFBQSxZQUFDLEdBQUEsRUFBSyxJQUFOO0FBQUEsWUFBWSxPQUFBLEVBQVMscUJBQUEsR0FBd0IsRUFBRSxDQUFDLEtBQUgsQ0FBQSxDQUE3QztBQUFBLFlBQXlELFNBQUEsRUFBVyxhQUFwRTtXQUFqQixDQUF0QixDQUFBLENBREY7U0FBQSxNQUFBO0FBR0UsVUFBQSxJQUFDLENBQUEsWUFBWSxDQUFDLEdBQWQsQ0FBc0IsSUFBQSxnQkFBQSxDQUFpQjtBQUFBLFlBQUMsR0FBQSxFQUFLLElBQU47QUFBQSxZQUFZLE9BQUEsRUFBUyw4QkFBckI7QUFBQSxZQUFxRCxTQUFBLEVBQVcsWUFBaEU7V0FBakIsQ0FBdEIsQ0FBQSxDQUhGO1NBeENBO0FBOENBLFFBQUEsSUFBRyxDQUFDLENBQUMsUUFBRixDQUFXLElBQUksQ0FBQyxRQUFRLENBQUMsd0JBQWQsQ0FBQSxDQUFYLEVBQXFELG1CQUFyRCxDQUFIO0FBQ0UsVUFBQSxJQUFDLENBQUEsWUFBWSxDQUFDLEdBQWQsQ0FBc0IsSUFBQSxnQkFBQSxDQUFpQjtBQUFBLFlBQUMsR0FBQSxFQUFLLElBQU47QUFBQSxZQUFZLE9BQUEsRUFBUywrQkFBckI7QUFBQSxZQUFzRCxTQUFBLEVBQVcsYUFBakU7V0FBakIsQ0FBdEIsQ0FBQSxDQURGO1NBQUEsTUFBQTtBQUdFLFVBQUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxHQUFkLENBQXNCLElBQUEsZ0JBQUEsQ0FBaUI7QUFBQSxZQUFDLEdBQUEsRUFBSyxJQUFOO0FBQUEsWUFBWSxPQUFBLEVBQVMsZ0hBQXJCO0FBQUEsWUFBdUksU0FBQSxFQUFXLGNBQWxKO1dBQWpCLENBQXRCLENBQUEsQ0FIRjtTQTlDQTtBQW9EQSxRQUFBLElBQUcscUJBQUEsSUFBaUIsRUFBRSxDQUFDLE1BQUgsQ0FBQSxDQUFBLEtBQWlCLEtBQXJDO0FBQ0UsVUFBQSxJQUFDLENBQUEsWUFBWSxDQUFDLEdBQWQsQ0FBc0IsSUFBQSxnQkFBQSxDQUFpQjtBQUFBLFlBQUMsR0FBQSxFQUFLLElBQU47QUFBQSxZQUFZLE9BQUEsRUFBUyxrQkFBQSxHQUFxQixFQUFFLENBQUMsTUFBSCxDQUFBLENBQTFDO0FBQUEsWUFBdUQsU0FBQSxFQUFXLGFBQWxFO1dBQWpCLENBQXRCLENBQUEsQ0FERjtTQUFBLE1BQUE7QUFHRSxVQUFBLElBQUMsQ0FBQSxZQUFZLENBQUMsR0FBZCxDQUFzQixJQUFBLGdCQUFBLENBQWlCO0FBQUEsWUFBQyxHQUFBLEVBQUssSUFBTjtBQUFBLFlBQVksT0FBQSxFQUFTLDJCQUFyQjtBQUFBLFlBQWtELFNBQUEsRUFBVyxZQUE3RDtXQUFqQixDQUF0QixDQUFBLENBSEY7U0FwREE7QUEwREEsUUFBQSxJQUFHLGtCQUFBLElBQWMsRUFBRSxDQUFDLEdBQUgsQ0FBQSxDQUFBLEtBQWMsS0FBL0I7QUFDRSxVQUFBLElBQUMsQ0FBQSxZQUFZLENBQUMsR0FBZCxDQUFzQixJQUFBLGdCQUFBLENBQWlCO0FBQUEsWUFBQyxHQUFBLEVBQUssSUFBTjtBQUFBLFlBQVksT0FBQSxFQUFTLGNBQUEsR0FBaUIsRUFBRSxDQUFDLEdBQUgsQ0FBQSxDQUF0QztBQUFBLFlBQWdELFNBQUEsRUFBVyxhQUEzRDtXQUFqQixDQUF0QixDQUFBLENBREY7U0FBQSxNQUFBO0FBR0UsVUFBQSxJQUFDLENBQUEsWUFBWSxDQUFDLEdBQWQsQ0FBc0IsSUFBQSxnQkFBQSxDQUFpQjtBQUFBLFlBQUMsR0FBQSxFQUFLLElBQU47QUFBQSxZQUFZLE9BQUEsRUFBUyx1QkFBckI7QUFBQSxZQUE4QyxTQUFBLEVBQVcsY0FBekQ7V0FBakIsQ0FBdEIsQ0FBQSxDQUhGO1NBMURBO0FBQUEsUUFnRUEsT0FBQSx1Q0FBZ0IsQ0FBRSxhQWhFbEIsQ0FBQTtBQWlFQSxRQUFBLElBQTRDLEVBQUUsQ0FBQyxRQUFILENBQUEsQ0FBQSxLQUFpQixPQUE3RDtBQUFBLFVBQUEsT0FBQSx3Q0FBaUIsQ0FBRSxjQUFSLHlDQUFzQixDQUFFLGNBQW5DLENBQUE7U0FqRUE7QUFrRUEsUUFBQSxJQUFHLGlCQUFBLElBQWEsT0FBTyxDQUFDLElBQVIsQ0FBQSxDQUFBLEtBQW9CLEVBQXBDO0FBQ0UsVUFBQSxJQUFDLENBQUEsWUFBWSxDQUFDLEdBQWQsQ0FBc0IsSUFBQSxnQkFBQSxDQUFpQjtBQUFBLFlBQUMsR0FBQSxFQUFLLElBQU47QUFBQSxZQUFZLE9BQUEsRUFBUyxlQUFBLEdBQWtCLE9BQXZDO0FBQUEsWUFBZ0QsU0FBQSxFQUFXLGFBQTNEO1dBQWpCLENBQXRCLENBQUEsQ0FERjtTQUFBLE1BQUE7QUFHRSxVQUFBLElBQUMsQ0FBQSxZQUFZLENBQUMsR0FBZCxDQUFzQixJQUFBLGdCQUFBLENBQWlCO0FBQUEsWUFBQyxHQUFBLEVBQUssSUFBTjtBQUFBLFlBQVksT0FBQSxFQUFTLHNCQUFyQjtBQUFBLFlBQTZDLFNBQUEsRUFBVyxZQUF4RDtXQUFqQixDQUF0QixDQUFBLENBSEY7U0FuRUY7T0FBQSxNQUFBO0FBd0VFLFFBQUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxHQUFkLENBQXNCLElBQUEsZ0JBQUEsQ0FBaUI7QUFBQSxVQUFDLEdBQUEsRUFBSyxJQUFOO0FBQUEsVUFBWSxPQUFBLEVBQVMsZ0NBQXJCO0FBQUEsVUFBdUQsU0FBQSxFQUFXLFlBQWxFO1NBQWpCLENBQXRCLENBQUEsQ0F4RUY7T0FOQTtBQUFBLE1BZ0ZBLElBQUMsQ0FBQSxZQUFZLENBQUMsR0FBZCxDQUFzQixJQUFBLGdCQUFBLENBQWlCO0FBQUEsUUFBQyxHQUFBLEVBQUssSUFBTjtBQUFBLFFBQVksT0FBQSxFQUFTLGVBQUEsR0FBa0IsSUFBSSxDQUFDLFVBQXZCLEdBQW9DLElBQXBDLEdBQTJDLEVBQUUsQ0FBQyxRQUFILENBQUEsQ0FBM0MsR0FBMkQsR0FBM0QsR0FBaUUsRUFBRSxDQUFDLElBQUgsQ0FBQSxDQUFqRSxHQUE2RSxHQUE3RSxHQUFtRixFQUFFLENBQUMsT0FBSCxDQUFBLENBQW5GLEdBQWtHLEdBQXZIO0FBQUEsUUFBNEgsU0FBQSxFQUFXLFdBQXZJO09BQWpCLENBQXRCLENBaEZBLENBQUE7YUFrRkEsSUFBQyxDQUFBLFlBQVksQ0FBQyxNQUFkLENBQUEsRUFuRmE7SUFBQSxDQTdKZixDQUFBOztBQUFBLHVCQWtQQSxlQUFBLEdBQWlCLFNBQUMsUUFBRCxHQUFBO0FBQ2YsTUFBQSxJQUFrQyxrQkFBQSxJQUFjLENBQUMsQ0FBQyxJQUFGLENBQU8sUUFBUCxDQUFBLEdBQW1CLENBQW5FO0FBQUEsUUFBQSxRQUFBLEdBQVcsQ0FBQyxDQUFDLE9BQUYsQ0FBVSxRQUFWLENBQVgsQ0FBQTtPQUFBO0FBQUEsTUFDQSxRQUFBLEdBQVcsQ0FBQyxDQUFDLE1BQUYsQ0FBUyxRQUFULEVBQW1CLFNBQUMsT0FBRCxFQUFVLEtBQVYsRUFBaUIsSUFBakIsR0FBQTtBQUEwQixlQUFPLGVBQVAsQ0FBMUI7TUFBQSxDQUFuQixDQURYLENBQUE7QUFFQSxNQUFBLElBQWMsZ0JBQWQ7QUFBQSxjQUFBLENBQUE7T0FGQTtBQUFBLE1BR0EsUUFBQSxHQUFXLENBQUMsQ0FBQyxNQUFGLENBQVMsUUFBVCxFQUFtQixTQUFDLE9BQUQsR0FBQTtlQUFhLGdCQUFiO01BQUEsQ0FBbkIsQ0FIWCxDQUFBO0FBQUEsTUFJQSxJQUFDLENBQUEsUUFBRCxHQUFZLENBQUMsQ0FBQyxLQUFGLENBQVEsSUFBQyxDQUFBLFFBQVQsRUFBbUIsUUFBbkIsQ0FKWixDQUFBO0FBQUEsTUFLQSxJQUFDLENBQUEsUUFBRCxHQUFZLENBQUMsQ0FBQyxJQUFGLENBQU8sSUFBQyxDQUFBLFFBQVIsRUFBa0IsU0FBQyxPQUFELEVBQVUsS0FBVixFQUFpQixJQUFqQixHQUFBO0FBQzVCLGtDQUFPLE9BQU8sQ0FBRSxjQUFULEdBQWdCLEdBQWhCLHNCQUFzQixPQUFPLENBQUUsZ0JBQS9CLEdBQXdDLEdBQXhDLHNCQUE4QyxPQUFPLENBQUUsYUFBOUQsQ0FENEI7TUFBQSxDQUFsQixDQUxaLENBQUE7YUFPQSxJQUFDLENBQUEsSUFBRCxDQUFNLG9CQUFOLEVBQTRCLENBQUMsQ0FBQyxJQUFGLENBQU8sSUFBQyxDQUFBLFFBQVIsQ0FBNUIsRUFSZTtJQUFBLENBbFBqQixDQUFBOztBQUFBLHVCQTRQQSxlQUFBLEdBQWlCLFNBQUMsTUFBRCxFQUFTLE1BQVQsR0FBQTtBQUNmLFVBQUEsRUFBQTtBQUFBLE1BQUEsSUFBQyxDQUFBLFdBQUQsR0FBZSxJQUFmLENBQUE7QUFBQSxNQUNBLEVBQUEsR0FBSyxJQUFDLENBQUEsWUFBWSxDQUFDLE9BQWQsQ0FBQSxDQURMLENBQUE7QUFFQSxNQUFBLElBQUEsQ0FBQSxDQUFPLFlBQUEsSUFBUSx1QkFBUixJQUEyQixFQUFFLENBQUMsVUFBVSxDQUFDLElBQWQsQ0FBQSxDQUFBLEtBQTBCLEVBQTVELENBQUE7QUFDRSxRQUFBLElBQUMsQ0FBQSxhQUFELENBQWUsS0FBZixDQUFBLENBQUE7QUFBQSxRQUNBLElBQUMsQ0FBQSxXQUFELEdBQWUsS0FEZixDQUFBO0FBRUEsY0FBQSxDQUhGO09BRkE7QUFBQSxNQU9BLEtBQUssQ0FBQyxNQUFOLENBQWE7UUFDWCxDQUFBLFNBQUEsS0FBQSxHQUFBO2lCQUFBLFNBQUMsUUFBRCxHQUFBO21CQUNFLEtBQUMsQ0FBQSxLQUFLLENBQUMsWUFBUCxDQUFvQixNQUFwQixFQUE0QixNQUE1QixFQUFvQyxRQUFwQyxFQURGO1VBQUEsRUFBQTtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FEVztPQUFiLEVBR0csQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsR0FBRCxFQUFNLGNBQU4sR0FBQTtBQUNELFVBQUEsS0FBQyxDQUFBLGVBQUQsQ0FBaUIsY0FBakIsQ0FBQSxDQUFBO2lCQUNBLEtBQUssQ0FBQyxRQUFOLENBQWU7WUFDYixTQUFDLFFBQUQsR0FBQTtxQkFDRSxLQUFDLENBQUEsS0FBSyxDQUFDLFdBQVAsQ0FBbUIsTUFBbkIsRUFBMkIsTUFBM0IsRUFBbUMsUUFBbkMsRUFERjtZQUFBLENBRGEsRUFHYixTQUFDLFFBQUQsR0FBQTtxQkFDRSxLQUFDLENBQUEsTUFBTSxDQUFDLFdBQVIsQ0FBb0IsTUFBcEIsRUFBNEIsTUFBNUIsRUFBb0MsUUFBcEMsRUFERjtZQUFBLENBSGEsRUFLYixTQUFDLFFBQUQsR0FBQTtxQkFDRSxLQUFDLENBQUEsTUFBTSxDQUFDLEtBQVIsQ0FBYyxNQUFkLEVBQXNCLE1BQXRCLEVBQThCLFFBQTlCLEVBREY7WUFBQSxDQUxhLEVBT2IsU0FBQyxRQUFELEdBQUE7cUJBQ0UsS0FBQyxDQUFBLE9BQU8sQ0FBQyxXQUFULENBQXFCLE1BQXJCLEVBQTZCLE1BQTdCLEVBQXFDLFFBQXJDLEVBREY7WUFBQSxDQVBhO1dBQWYsRUFTRyxTQUFDLEdBQUQsRUFBTSxhQUFOLEdBQUE7QUFDRCxZQUFBLEtBQUMsQ0FBQSxlQUFELENBQWlCLGFBQWpCLENBQUEsQ0FBQTttQkFDQSxLQUFDLENBQUEsSUFBRCxDQUFNLG1CQUFOLEVBQTJCLE1BQTNCLEVBRkM7VUFBQSxDQVRILEVBRkM7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUhILENBUEEsQ0FBQTthQTJCQSxLQUFLLENBQUMsTUFBTixDQUFhO1FBQ1gsQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFDLFFBQUQsR0FBQTttQkFDRSxLQUFDLENBQUEsT0FBTyxDQUFDLFdBQVQsQ0FBcUIsTUFBckIsRUFBNkIsTUFBN0IsRUFBcUMsUUFBckMsRUFERjtVQUFBLEVBQUE7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRFc7T0FBYixFQUdHLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLEdBQUQsRUFBTSxjQUFOLEdBQUE7aUJBQ0QsS0FBQyxDQUFBLElBQUQsQ0FBTSxtQkFBTixFQURDO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FISCxFQTVCZTtJQUFBLENBNVBqQixDQUFBOztBQUFBLHVCQStSQSxnQkFBQSxHQUFrQixTQUFDLE1BQUQsRUFBUyxNQUFULEdBQUE7QUFDaEIsTUFBQSxJQUFBLENBQUEsQ0FBYyxJQUFDLENBQUEsS0FBRCxJQUFXLElBQUMsQ0FBQSxTQUExQixDQUFBO0FBQUEsY0FBQSxDQUFBO09BQUE7QUFDQSxNQUFBLElBQUEsQ0FBQSxJQUFlLENBQUEsYUFBRCxDQUFlLE1BQWYsQ0FBZDtBQUFBLGNBQUEsQ0FBQTtPQURBO0FBQUEsTUFFQSxJQUFDLENBQUEsVUFBRCxDQUFZLE1BQVosQ0FGQSxDQUFBO2FBR0EsSUFBQyxDQUFBLGVBQUQsQ0FBaUIsTUFBakIsRUFBeUIsTUFBekIsRUFKZ0I7SUFBQSxDQS9SbEIsQ0FBQTs7QUFBQSx1QkFxU0EsbUJBQUEsR0FBcUIsU0FBQyxNQUFELEdBQUE7QUFDbkIsTUFBQSxJQUFBLENBQUEsQ0FBYyxJQUFDLENBQUEsS0FBRCxJQUFXLElBQUMsQ0FBQSxTQUExQixDQUFBO0FBQUEsY0FBQSxDQUFBO09BQUE7QUFDQSxNQUFBLElBQUEsQ0FBQSxJQUFlLENBQUEsYUFBRCxDQUFlLE1BQWYsQ0FBZDtBQUFBO09BRm1CO0lBQUEsQ0FyU3JCLENBQUE7O0FBQUEsdUJBeVNBLFVBQUEsR0FBWSxTQUFDLE1BQUQsR0FBQTtBQUNWLE1BQUEsSUFBQyxDQUFBLFFBQUQsR0FBWSxFQUFaLENBQUE7QUFBQSxNQUNBLElBQUMsQ0FBQSxXQUFELENBQWEsTUFBYixDQURBLENBQUE7YUFFQSxJQUFDLENBQUEsVUFBRCxDQUFBLEVBSFU7SUFBQSxDQXpTWixDQUFBOztBQUFBLHVCQThTQSxXQUFBLEdBQWEsU0FBQyxNQUFELEdBQUE7QUFDWCxVQUFBLDBDQUFBO0FBQUEsTUFBQSxJQUFBLENBQUEsSUFBZSxDQUFBLGFBQUQsQ0FBZSxNQUFmLENBQWQ7QUFBQSxjQUFBLENBQUE7T0FBQTtBQUFBLE1BRUEsT0FBQSxnRUFBNkIsQ0FBRSxXQUFyQixDQUFpQztBQUFBLFFBQUMsT0FBQSxFQUFPLFNBQVI7T0FBakMsbUJBRlYsQ0FBQTtBQUdBLE1BQUEsSUFBQSxDQUFBLENBQWMsaUJBQUEsSUFBYSxDQUFDLENBQUMsSUFBRixDQUFPLE9BQVAsQ0FBQSxHQUFrQixDQUE3QyxDQUFBO0FBQUEsY0FBQSxDQUFBO09BSEE7QUFLQTtXQUFBLDhDQUFBOzZCQUFBO0FBQUEsc0JBQUEsTUFBTSxDQUFDLE9BQVAsQ0FBQSxFQUFBLENBQUE7QUFBQTtzQkFOVztJQUFBLENBOVNiLENBQUE7O0FBQUEsdUJBc1RBLFlBQUEsR0FBYyxTQUFDLE1BQUQsRUFBUyxRQUFULEdBQUE7QUFDWixVQUFBLHdEQUFBO0FBQUEsTUFBQSxJQUFDLENBQUEsV0FBRCxDQUFhLE1BQWIsQ0FBQSxDQUFBO0FBQ0EsTUFBQSxJQUFBLENBQUEsSUFBZSxDQUFBLGFBQUQsQ0FBZSxNQUFmLENBQWQ7QUFBQSxjQUFBLENBQUE7T0FEQTtBQUVBLE1BQUEsSUFBQSxDQUFBLENBQWMsa0JBQUEsSUFBYyxRQUFRLENBQUMsTUFBVCxHQUFrQixDQUE5QyxDQUFBO0FBQUEsY0FBQSxDQUFBO09BRkE7QUFBQSxNQUdBLE1BQUEsb0JBQVMsTUFBTSxDQUFFLFNBQVIsQ0FBQSxVQUhULENBQUE7QUFJQSxNQUFBLElBQWMsY0FBZDtBQUFBLGNBQUEsQ0FBQTtPQUpBO0FBS0E7V0FBQSwrQ0FBQTsrQkFBQTtBQUNFLFFBQUEsSUFBQSxHQUFPLEtBQVAsQ0FBQTtBQUNBLFFBQUEsSUFBRyxtREFBQSxJQUFtQixPQUFPLENBQUMsSUFBUixLQUFrQixFQUF4QztBQUNFLFVBQUEsSUFBQSxHQUFPLE9BQU8sQ0FBQyxJQUFSLHVCQUFrQixNQUFNLENBQUUsT0FBUixDQUFBLFdBQXpCLENBREY7U0FEQTtBQUlBLFFBQUEsSUFBQSxDQUFBLElBQUE7QUFDRSxVQUFBLElBQUcsbURBQUEsSUFBbUIsT0FBTyxDQUFDLElBQVIsS0FBa0IsS0FBckMsSUFBK0MsT0FBTyxDQUFDLElBQVIsSUFBZ0IsQ0FBbEU7QUFDRTtBQUNFLGNBQUEsTUFBQSxvQkFBUyxNQUFNLENBQUUsWUFBUixDQUFxQixDQUFDLE9BQU8sQ0FBQyxJQUFSLEdBQWUsQ0FBaEIsRUFBbUIsQ0FBbkIsQ0FBckIsRUFBNEM7QUFBQSxnQkFBQyxPQUFBLEVBQU8sU0FBUjtBQUFBLGdCQUFtQixVQUFBLEVBQVksT0FBL0I7ZUFBNUMsVUFBVCxDQUFBO0FBQUEsNkNBQ0EsTUFBTSxDQUFFLGNBQVIsQ0FBdUIsTUFBdkIsRUFBK0I7QUFBQSxnQkFBQyxJQUFBLEVBQU0sYUFBUDtBQUFBLGdCQUFzQixPQUFBLEVBQU8sU0FBQSxHQUFZLE9BQU8sQ0FBQyxJQUFqRDtlQUEvQixXQURBLENBREY7YUFBQSxjQUFBO0FBSUUsY0FESSxjQUNKLENBQUE7QUFBQSw0QkFBQSxPQUFPLENBQUMsR0FBUixDQUFZLEtBQVosRUFBQSxDQUpGO2FBREY7V0FBQSxNQUFBO2tDQUFBO1dBREY7U0FBQSxNQUFBO2dDQUFBO1NBTEY7QUFBQTtzQkFOWTtJQUFBLENBdFRkLENBQUE7O0FBQUEsdUJBeVVBLFVBQUEsR0FBWSxTQUFBLEdBQUE7QUFDVixVQUFBLFlBQUE7O2FBQWEsQ0FBRSxLQUFmLENBQUE7T0FBQTt3REFDYSxDQUFFLEtBQWYsQ0FBQSxXQUZVO0lBQUEsQ0F6VVosQ0FBQTs7QUFBQSx1QkE2VUEsVUFBQSxHQUFZLFNBQUMsTUFBRCxFQUFTLFFBQVQsR0FBQTtBQUNWLFVBQUEsZ0VBQUE7QUFBQSxNQUFBLElBQUMsQ0FBQSxVQUFELENBQUE7QUFDQSxNQUFBLElBQWMsZ0JBQWQ7QUFBQSxjQUFBLENBQUE7T0FEQTtBQUVBLE1BQUEsSUFBRyxRQUFRLENBQUMsTUFBVCxJQUFtQixDQUFuQixJQUF5QixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0Isb0NBQWhCLENBQTVCO0FBQ0UsUUFBQSxJQUFDLENBQUEsWUFBWSxDQUFDLEdBQWQsQ0FBc0IsSUFBQSxnQkFBQSxDQUFpQjtBQUFBLFVBQUMsT0FBQSxFQUFTLFdBQVY7QUFBQSxVQUF1QixTQUFBLEVBQVcsY0FBbEM7U0FBakIsQ0FBdEIsQ0FBQSxDQUFBO0FBQUEsUUFDQSxJQUFDLENBQUEsWUFBWSxDQUFDLE1BQWQsQ0FBQSxDQURBLENBQUE7QUFFQSxjQUFBLENBSEY7T0FGQTtBQU1BLE1BQUEsSUFBQSxDQUFBLENBQWMsUUFBUSxDQUFDLE1BQVQsR0FBa0IsQ0FBaEMsQ0FBQTtBQUFBLGNBQUEsQ0FBQTtPQU5BO0FBT0EsTUFBQSxJQUFBLENBQUEsSUFBa0IsQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQixtQkFBaEIsQ0FBZDtBQUFBLGNBQUEsQ0FBQTtPQVBBO0FBQUEsTUFRQSxjQUFBLEdBQWlCLENBQUMsQ0FBQyxNQUFGLENBQVMsSUFBQyxDQUFBLFFBQVYsRUFBb0IsU0FBQyxPQUFELEVBQVUsS0FBVixFQUFpQixJQUFqQixHQUFBO0FBQ25DLGVBQU8sUUFBQSxDQUFTLE9BQU8sQ0FBQyxJQUFqQixFQUF1QixFQUF2QixDQUFQLENBRG1DO01BQUEsQ0FBcEIsQ0FSakIsQ0FBQTtBQVVBLFdBQUEscURBQUE7cUNBQUE7QUFDRSxRQUFBLFNBQUE7QUFBWSxrQkFBTyxPQUFPLENBQUMsSUFBZjtBQUFBLGlCQUNMLE9BREs7cUJBQ1EsYUFEUjtBQUFBLGlCQUVMLFNBRks7cUJBRVUsZUFGVjtBQUFBO3FCQUdMLFlBSEs7QUFBQTtZQUFaLENBQUE7QUFBQSxRQUtBLElBQUEsR0FBVSxzQkFBQSxJQUFrQixPQUFPLENBQUMsSUFBSSxDQUFDLElBQWIsQ0FBQSxDQUFBLEtBQXlCLEVBQTlDLEdBQXNELE9BQU8sQ0FBQyxJQUE5RCxHQUF3RSxJQUwvRSxDQUFBO0FBTUEsUUFBQSxJQUF3QyxjQUFBLElBQVUsSUFBQSxLQUFVLEVBQXBCLElBQTJCLGdGQUFuRTtBQUFBLFVBQUEsSUFBQSxHQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBYixDQUF3QixJQUF4QixDQUFQLENBQUE7U0FOQTtBQUFBLFFBT0EsTUFBQSxHQUFZLHdCQUFBLElBQW9CLE9BQU8sQ0FBQyxNQUFSLEtBQW9CLEVBQXhDLElBQStDLE9BQU8sQ0FBQyxNQUFSLEtBQW9CLEtBQXRFLEdBQWlGLE9BQU8sQ0FBQyxNQUF6RixHQUFxRyxJQVA5RyxDQUFBO0FBQUEsUUFRQSxJQUFBLEdBQVUsc0JBQUEsSUFBa0IsT0FBTyxDQUFDLElBQVIsS0FBa0IsRUFBcEMsSUFBMkMsT0FBTyxDQUFDLElBQVIsS0FBa0IsS0FBaEUsR0FBMkUsT0FBTyxDQUFDLElBQW5GLEdBQTZGLElBUnBHLENBQUE7QUFVQSxRQUFBLElBQUcsSUFBQSxLQUFRLElBQVIsSUFBaUIsTUFBQSxLQUFVLElBQTNCLElBQW9DLElBQUEsS0FBUSxJQUEvQztBQUVFLFVBQUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxHQUFkLENBQXNCLElBQUEsZ0JBQUEsQ0FBaUI7QUFBQSxZQUFDLE9BQUEsRUFBUyxPQUFPLENBQUMsR0FBbEI7QUFBQSxZQUF1QixTQUFBLEVBQVcsU0FBbEM7V0FBakIsQ0FBdEIsQ0FBQSxDQUZGO1NBQUEsTUFBQTtBQUtFLFVBQUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxHQUFkLENBQXNCLElBQUEsZUFBQSxDQUFnQjtBQUFBLFlBQUMsSUFBQSxFQUFNLElBQVA7QUFBQSxZQUFhLElBQUEsRUFBTSxJQUFuQjtBQUFBLFlBQXlCLFNBQUEsRUFBVyxNQUFwQztBQUFBLFlBQTRDLE9BQUEsRUFBUyxPQUFPLENBQUMsR0FBN0Q7QUFBQSxZQUFrRSxTQUFBLEVBQVcsU0FBN0U7V0FBaEIsQ0FBdEIsQ0FBQSxDQUxGO1NBWEY7QUFBQSxPQVZBO0FBMkJBLE1BQUEsSUFBMEIsZ0ZBQTFCO2VBQUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxNQUFkLENBQUEsRUFBQTtPQTVCVTtJQUFBLENBN1VaLENBQUE7O0FBQUEsdUJBMldBLGFBQUEsR0FBZSxTQUFDLE1BQUQsR0FBQTtBQUNiLFVBQUEsS0FBQTs0RUFBb0IsQ0FBRSw0QkFBdEIsS0FBbUMsWUFEdEI7SUFBQSxDQTNXZixDQUFBOztBQUFBLHVCQThXQSxHQUFBLEdBQUssU0FBQSxHQUFBO2FBQ0gsSUFBQyxDQUFBLFdBQVcsQ0FBQyxLQUFiLENBQUEsRUFERztJQUFBLENBOVdMLENBQUE7O0FBQUEsdUJBaVhBLFFBQUEsR0FBVSxTQUFDLG1CQUFELEdBQUE7QUFDUixVQUFBLEtBQUE7QUFBQSxNQUFBLG1CQUFBLEdBQXNCLDZCQUFBLElBQXlCLG1CQUEvQyxDQUFBO0FBQUEsTUFDQSxJQUFDLENBQUEsS0FBRCxHQUFTLEtBRFQsQ0FBQTtBQUFBLE1BRUEsS0FBQSxHQUFRLElBQUMsQ0FBQSxZQUFZLENBQUMsT0FBZCxDQUFBLENBRlIsQ0FBQTtBQUdBLE1BQUEsSUFBQSxDQUFBLENBQU8sZUFBQSxJQUFXLDBCQUFYLElBQWlDLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBakIsQ0FBQSxDQUFBLEtBQTZCLEVBQXJFLENBQUE7QUFDRSxRQUFBLElBQUMsQ0FBQSxhQUFELENBQWUsS0FBZixDQUFBLENBQUE7QUFDQSxjQUFBLENBRkY7T0FIQTtBQU1BLE1BQUEsSUFBQSxDQUFBLENBQU8sS0FBSyxDQUFDLGVBQU4sQ0FBQSxDQUFBLElBQTJCLG1CQUFsQyxDQUFBO0FBQ0UsUUFBQSxJQUFDLENBQUEsU0FBRCxDQUFBLENBQUEsQ0FBQTtBQUNBLGNBQUEsQ0FGRjtPQU5BO0FBQUEsTUFTQSxJQUFDLENBQUEsVUFBRCxDQUFBLENBVEEsQ0FBQTtBQUFBLE1BVUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxHQUFkLENBQXNCLElBQUEsZ0JBQUEsQ0FBaUI7QUFBQSxRQUFDLE9BQUEsRUFBUyw4Q0FBVjtBQUFBLFFBQTBELFNBQUEsRUFBVyxjQUFyRTtPQUFqQixDQUF0QixDQVZBLENBQUE7QUFBQSxNQVdBLElBQUMsQ0FBQSxZQUFZLENBQUMsTUFBZCxDQUFBLENBWEEsQ0FBQTtBQUFBLE1BWUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxFQUFkLENBQWlCLG1CQUFqQixFQUFzQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQSxHQUFBO0FBQ3BDLFVBQUEsS0FBQyxDQUFBLGFBQUQsQ0FBZSxJQUFmLENBQUEsQ0FBQTtpQkFDQSxLQUFDLENBQUEsU0FBRCxDQUFBLEVBRm9DO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBdEMsQ0FaQSxDQUFBO2FBZUEsSUFBQyxDQUFBLFlBQVksQ0FBQyxRQUFkLENBQXVCLEtBQXZCLEVBQThCLG1CQUE5QixFQWhCUTtJQUFBLENBalhWLENBQUE7O29CQUFBOztNQXBCRixDQUFBO0FBQUEiCn0=

//# sourceURL=/home/shane/.atom/packages/go-plus/lib/dispatch.coffee
