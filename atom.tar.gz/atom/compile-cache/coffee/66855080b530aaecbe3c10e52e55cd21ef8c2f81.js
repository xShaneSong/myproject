(function() {
  module.exports = {
    createTempFileWithCode: function(code) {
      return module.parent.exports.createTempFileWithCode(code);
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvc2NyaXB0L2xpYi9ncmFtbWFyLXV0aWxzL1IuY29mZmVlIgogIF0sCiAgIm5hbWVzIjogW10sCiAgIm1hcHBpbmdzIjogIkFBRUE7QUFBQSxFQUFBLE1BQU0sQ0FBQyxPQUFQLEdBTUU7QUFBQSxJQUFBLHNCQUFBLEVBQXdCLFNBQUMsSUFBRCxHQUFBO2FBQ3RCLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLHNCQUF0QixDQUE2QyxJQUE3QyxFQURzQjtJQUFBLENBQXhCO0dBTkYsQ0FBQTtBQUFBIgp9

//# sourceURL=/home/shane/.atom/packages/script/lib/grammar-utils/R.coffee
