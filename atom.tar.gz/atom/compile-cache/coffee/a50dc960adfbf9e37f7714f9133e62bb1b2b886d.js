(function() {
  var Disposable, XPathStatusBarView, utils,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Disposable = require('atom').Disposable;

  utils = require('./xml-utils');

  XPathStatusBarView = (function(_super) {
    __extends(XPathStatusBarView, _super);

    function XPathStatusBarView() {
      return XPathStatusBarView.__super__.constructor.apply(this, arguments);
    }

    XPathStatusBarView.prototype.statusBar = null;

    XPathStatusBarView.prototype.xpathLabel = null;

    XPathStatusBarView.prototype.tile = null;

    XPathStatusBarView.prototype.xpathSubscription = null;

    XPathStatusBarView.prototype.activeItemSubscription = null;

    XPathStatusBarView.prototype.configurationSubscription = null;

    XPathStatusBarView.prototype.initialize = function(statusBar) {
      this.statusBar = statusBar;
      this.classList.add('xpath-status', 'inline-block');
      this.xpathLabel = document.createElement('label');
      this.appendChild(this.xpathLabel);
      this.handleEvents();
      return this;
    };

    XPathStatusBarView.prototype.destroy = function() {
      var _ref, _ref1, _ref2;
      this.disposeViewSubscriptions();
      if ((_ref = this.activeItemSubscription) != null) {
        _ref.dispose();
      }
      this.activeItemSubscription = null;
      if ((_ref1 = this.configurationSubscription) != null) {
        _ref1.destroy();
      }
      this.configurationSubscription = null;
      if ((_ref2 = this.tile) != null) {
        _ref2.destroy();
      }
      return this.tile = null;
    };

    XPathStatusBarView.prototype.handleEvents = function() {
      this.activeItemSubscription = atom.workspace.onDidChangeActivePaneItem((function(_this) {
        return function() {
          return _this.subscribeToActiveTextEditor();
        };
      })(this));
      this.configurationSubscription = atom.config.observe('autocomplete-xml.showXPathInStatusBar', (function(_this) {
        return function() {
          return _this.attach();
        };
      })(this));
      return this.subscribeToActiveTextEditor();
    };

    XPathStatusBarView.prototype.attach = function() {
      var _ref;
      if ((_ref = this.tile) != null) {
        _ref.destroy();
      }
      if (atom.config.get('autocomplete-xml.showXPathInStatusBar')) {
        this.tile = this.statusBar.addRightTile({
          item: this
        });
      } else {
        this.disposeViewSubscriptions();
      }
      return this.tile;
    };

    XPathStatusBarView.prototype.disposeViewSubscriptions = function() {
      var _ref;
      if ((_ref = this.xpathSubscription) != null) {
        _ref.dispose();
      }
      return this.xpathSubscription = null;
    };

    XPathStatusBarView.prototype.getActiveTextEditor = function() {
      return atom.workspace.getActiveTextEditor();
    };

    XPathStatusBarView.prototype.subscribeToActiveTextEditor = function() {
      var _ref, _ref1, _ref2, _ref3;
      if ((_ref = this.xpathSubscription) != null) {
        _ref.dispose();
      }
      if (((_ref1 = this.getActiveTextEditor()) != null ? (_ref2 = _ref1.getGrammar()) != null ? _ref2.name : void 0 : void 0) === "XML") {
        this.updateXPath();
        return this.xpathSubscription = (_ref3 = this.getActiveTextEditor()) != null ? _ref3.onDidChangeCursorPosition((function(_this) {
          return function() {
            return _this.updateXPath();
          };
        })(this)) : void 0;
      } else {
        return this.xpathLabel.textContent = '';
      }
    };

    XPathStatusBarView.prototype.updateXPath = function() {
      var buffer, bufferPosition, editor, xpath;
      editor = this.getActiveTextEditor();
      if (editor) {
        buffer = editor.getBuffer();
        bufferPosition = editor.getCursorBufferPosition();
        xpath = utils.getXPath(buffer, bufferPosition, '');
        return this.xpathLabel.textContent = xpath.join('/');
      } else {
        return this.xpathLabel.textCotent = '';
      }
    };

    return XPathStatusBarView;

  })(HTMLDivElement);

  module.exports = document.registerElement('xpath-statusbar', {
    prototype: XPathStatusBarView.prototype
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvYXV0b2NvbXBsZXRlLXhtbC9saWIveHBhdGgtc3RhdHVzYmFyLXZpZXcuY29mZmVlIgogIF0sCiAgIm5hbWVzIjogW10sCiAgIm1hcHBpbmdzIjogIkFBQUE7QUFBQSxNQUFBLHFDQUFBO0lBQUE7bVNBQUE7O0FBQUEsRUFBQyxhQUFjLE9BQUEsQ0FBUSxNQUFSLEVBQWQsVUFBRCxDQUFBOztBQUFBLEVBQ0EsS0FBQSxHQUFRLE9BQUEsQ0FBUSxhQUFSLENBRFIsQ0FBQTs7QUFBQSxFQU9NO0FBQ0oseUNBQUEsQ0FBQTs7OztLQUFBOztBQUFBLGlDQUFBLFNBQUEsR0FBVyxJQUFYLENBQUE7O0FBQUEsaUNBQ0EsVUFBQSxHQUFZLElBRFosQ0FBQTs7QUFBQSxpQ0FFQSxJQUFBLEdBQU0sSUFGTixDQUFBOztBQUFBLGlDQUdBLGlCQUFBLEdBQW1CLElBSG5CLENBQUE7O0FBQUEsaUNBSUEsc0JBQUEsR0FBd0IsSUFKeEIsQ0FBQTs7QUFBQSxpQ0FLQSx5QkFBQSxHQUEyQixJQUwzQixDQUFBOztBQUFBLGlDQVFBLFVBQUEsR0FBWSxTQUFDLFNBQUQsR0FBQTtBQUNWLE1BQUEsSUFBQyxDQUFBLFNBQUQsR0FBYSxTQUFiLENBQUE7QUFBQSxNQUNBLElBQUMsQ0FBQSxTQUFTLENBQUMsR0FBWCxDQUFlLGNBQWYsRUFBK0IsY0FBL0IsQ0FEQSxDQUFBO0FBQUEsTUFFQSxJQUFDLENBQUEsVUFBRCxHQUFjLFFBQVEsQ0FBQyxhQUFULENBQXVCLE9BQXZCLENBRmQsQ0FBQTtBQUFBLE1BR0EsSUFBQyxDQUFBLFdBQUQsQ0FBYSxJQUFDLENBQUEsVUFBZCxDQUhBLENBQUE7QUFBQSxNQUlBLElBQUMsQ0FBQSxZQUFELENBQUEsQ0FKQSxDQUFBO2FBS0EsS0FOVTtJQUFBLENBUlosQ0FBQTs7QUFBQSxpQ0FpQkEsT0FBQSxHQUFTLFNBQUEsR0FBQTtBQUNQLFVBQUEsa0JBQUE7QUFBQSxNQUFBLElBQUMsQ0FBQSx3QkFBRCxDQUFBLENBQUEsQ0FBQTs7WUFHdUIsQ0FBRSxPQUF6QixDQUFBO09BSEE7QUFBQSxNQUlBLElBQUMsQ0FBQSxzQkFBRCxHQUEwQixJQUoxQixDQUFBOzthQU8wQixDQUFFLE9BQTVCLENBQUE7T0FQQTtBQUFBLE1BUUEsSUFBQyxDQUFBLHlCQUFELEdBQTZCLElBUjdCLENBQUE7O2FBV0ssQ0FBRSxPQUFQLENBQUE7T0FYQTthQVlBLElBQUMsQ0FBQSxJQUFELEdBQVEsS0FiRDtJQUFBLENBakJULENBQUE7O0FBQUEsaUNBaUNBLFlBQUEsR0FBYyxTQUFBLEdBQUE7QUFFWixNQUFBLElBQUMsQ0FBQSxzQkFBRCxHQUEwQixJQUFJLENBQUMsU0FBUyxDQUFDLHlCQUFmLENBQXlDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFBLEdBQUE7aUJBQ2pFLEtBQUMsQ0FBQSwyQkFBRCxDQUFBLEVBRGlFO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBekMsQ0FBMUIsQ0FBQTtBQUFBLE1BSUEsSUFBQyxDQUFBLHlCQUFELEdBQTZCLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBWixDQUMzQix1Q0FEMkIsRUFDYyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQSxHQUFBO2lCQUFHLEtBQUMsQ0FBQSxNQUFELENBQUEsRUFBSDtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRGQsQ0FKN0IsQ0FBQTthQVFBLElBQUMsQ0FBQSwyQkFBRCxDQUFBLEVBVlk7SUFBQSxDQWpDZCxDQUFBOztBQUFBLGlDQThDQSxNQUFBLEdBQVEsU0FBQSxHQUFBO0FBRU4sVUFBQSxJQUFBOztZQUFLLENBQUUsT0FBUCxDQUFBO09BQUE7QUFFQSxNQUFBLElBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLHVDQUFoQixDQUFIO0FBRUUsUUFBQSxJQUFDLENBQUEsSUFBRCxHQUFRLElBQUMsQ0FBQSxTQUFTLENBQUMsWUFBWCxDQUF3QjtBQUFBLFVBQUEsSUFBQSxFQUFNLElBQU47U0FBeEIsQ0FBUixDQUZGO09BQUEsTUFBQTtBQUtFLFFBQUEsSUFBQyxDQUFBLHdCQUFELENBQUEsQ0FBQSxDQUxGO09BRkE7QUFRQSxhQUFPLElBQUMsQ0FBQSxJQUFSLENBVk07SUFBQSxDQTlDUixDQUFBOztBQUFBLGlDQTJEQSx3QkFBQSxHQUEwQixTQUFBLEdBQUE7QUFFeEIsVUFBQSxJQUFBOztZQUFrQixDQUFFLE9BQXBCLENBQUE7T0FBQTthQUNBLElBQUMsQ0FBQSxpQkFBRCxHQUFxQixLQUhHO0lBQUEsQ0EzRDFCLENBQUE7O0FBQUEsaUNBaUVBLG1CQUFBLEdBQXFCLFNBQUEsR0FBQTthQUNuQixJQUFJLENBQUMsU0FBUyxDQUFDLG1CQUFmLENBQUEsRUFEbUI7SUFBQSxDQWpFckIsQ0FBQTs7QUFBQSxpQ0FxRUEsMkJBQUEsR0FBNkIsU0FBQSxHQUFBO0FBQzNCLFVBQUEseUJBQUE7O1lBQWtCLENBQUUsT0FBcEIsQ0FBQTtPQUFBO0FBR0EsTUFBQSxnR0FBdUMsQ0FBRSx1QkFBdEMsS0FBOEMsS0FBakQ7QUFDRSxRQUFBLElBQUMsQ0FBQSxXQUFELENBQUEsQ0FBQSxDQUFBO2VBQ0EsSUFBQyxDQUFBLGlCQUFELHVEQUEyQyxDQUFFLHlCQUF4QixDQUFrRCxDQUFBLFNBQUEsS0FBQSxHQUFBO2lCQUFBLFNBQUEsR0FBQTttQkFDckUsS0FBQyxDQUFBLFdBQUQsQ0FBQSxFQURxRTtVQUFBLEVBQUE7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxELFdBRnZCO09BQUEsTUFBQTtlQUtFLElBQUMsQ0FBQSxVQUFVLENBQUMsV0FBWixHQUEwQixHQUw1QjtPQUoyQjtJQUFBLENBckU3QixDQUFBOztBQUFBLGlDQWlGQSxXQUFBLEdBQWEsU0FBQSxHQUFBO0FBQ1gsVUFBQSxxQ0FBQTtBQUFBLE1BQUEsTUFBQSxHQUFTLElBQUMsQ0FBQSxtQkFBRCxDQUFBLENBQVQsQ0FBQTtBQUNBLE1BQUEsSUFBRyxNQUFIO0FBQ0UsUUFBQSxNQUFBLEdBQVMsTUFBTSxDQUFDLFNBQVAsQ0FBQSxDQUFULENBQUE7QUFBQSxRQUNBLGNBQUEsR0FBaUIsTUFBTSxDQUFDLHVCQUFQLENBQUEsQ0FEakIsQ0FBQTtBQUFBLFFBRUEsS0FBQSxHQUFRLEtBQUssQ0FBQyxRQUFOLENBQWUsTUFBZixFQUF1QixjQUF2QixFQUF1QyxFQUF2QyxDQUZSLENBQUE7ZUFHQSxJQUFDLENBQUEsVUFBVSxDQUFDLFdBQVosR0FBMEIsS0FBSyxDQUFDLElBQU4sQ0FBVyxHQUFYLEVBSjVCO09BQUEsTUFBQTtlQU1FLElBQUMsQ0FBQSxVQUFVLENBQUMsVUFBWixHQUF5QixHQU4zQjtPQUZXO0lBQUEsQ0FqRmIsQ0FBQTs7OEJBQUE7O0tBRCtCLGVBUGpDLENBQUE7O0FBQUEsRUFvR0EsTUFBTSxDQUFDLE9BQVAsR0FDRSxRQUFRLENBQUMsZUFBVCxDQUNFLGlCQURGLEVBRUU7QUFBQSxJQUFBLFNBQUEsRUFBVyxrQkFBa0IsQ0FBQyxTQUE5QjtHQUZGLENBckdGLENBQUE7QUFBQSIKfQ==

//# sourceURL=/home/shane/.atom/packages/autocomplete-xml/lib/xpath-statusbar-view.coffee
