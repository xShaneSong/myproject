(function() {
  var AutocompleteClangView;

  AutocompleteClangView = require('../lib/autocomplete-clang-view');

  describe("AutocompleteClangView", function() {
    return it("has one valid test", function() {
      return expect("life").toBe("easy");
    });
  });

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvYXV0b2NvbXBsZXRlLWNsYW5nL3NwZWMvYXV0b2NvbXBsZXRlLWNsYW5nLXZpZXctc3BlYy5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLE1BQUEscUJBQUE7O0FBQUEsRUFBQSxxQkFBQSxHQUF3QixPQUFBLENBQVEsZ0NBQVIsQ0FBeEIsQ0FBQTs7QUFBQSxFQUVBLFFBQUEsQ0FBUyx1QkFBVCxFQUFrQyxTQUFBLEdBQUE7V0FDaEMsRUFBQSxDQUFHLG9CQUFILEVBQXlCLFNBQUEsR0FBQTthQUN2QixNQUFBLENBQU8sTUFBUCxDQUFjLENBQUMsSUFBZixDQUFvQixNQUFwQixFQUR1QjtJQUFBLENBQXpCLEVBRGdDO0VBQUEsQ0FBbEMsQ0FGQSxDQUFBO0FBQUEiCn0=

//# sourceURL=/home/shane/.atom/packages/autocomplete-clang/spec/autocomplete-clang-view-spec.coffee
