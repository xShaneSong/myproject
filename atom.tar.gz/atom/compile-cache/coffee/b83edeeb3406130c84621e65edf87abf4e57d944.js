(function() {
  var fs, isFileAsync, path;

  path = require('path');

  fs = require('fs');

  isFileAsync = function(filePath) {
    return new Promise(function(resolve, reject) {
      return fs.stat(filePath, function(err, stats) {
        if (err) {
          return resolve(false);
        } else {
          return resolve(stats.isFile());
        }
      });
    });
  };

  module.exports = function(directoryPath) {
    if (directoryPath == null) {
      return Promise.reject();
    }
    return new Promise(function(resolve) {
      var filePaths, promises;
      filePaths = ['tags', 'TAGS', '.tags', '.TAGS'].map(function(fileName) {
        return path.join(directoryPath, fileName);
      });
      promises = filePaths.map(function(filePath) {
        return isFileAsync(filePath);
      });
      return Promise.all(promises).then(function(results) {
        var idx, result, _i, _len;
        for (idx = _i = 0, _len = results.length; _i < _len; idx = ++_i) {
          result = results[idx];
          if (result) {
            return resolve(filePaths[idx]);
          }
        }
        return resolve(false);
      });
    });
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvYXV0b2NvbXBsZXRlLWN0YWdzL2xpYi9nZXQtdGFncy1maWxlLmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSxxQkFBQTs7QUFBQSxFQUFBLElBQUEsR0FBTyxPQUFBLENBQVEsTUFBUixDQUFQLENBQUE7O0FBQUEsRUFDQSxFQUFBLEdBQUssT0FBQSxDQUFRLElBQVIsQ0FETCxDQUFBOztBQUFBLEVBR0EsV0FBQSxHQUFjLFNBQUMsUUFBRCxHQUFBO1dBQ1IsSUFBQSxPQUFBLENBQVEsU0FBQyxPQUFELEVBQVUsTUFBVixHQUFBO2FBQ1YsRUFBRSxDQUFDLElBQUgsQ0FBUSxRQUFSLEVBQWtCLFNBQUMsR0FBRCxFQUFNLEtBQU4sR0FBQTtBQUNoQixRQUFBLElBQUcsR0FBSDtpQkFDRSxPQUFBLENBQVEsS0FBUixFQURGO1NBQUEsTUFBQTtpQkFHRSxPQUFBLENBQVEsS0FBSyxDQUFDLE1BQU4sQ0FBQSxDQUFSLEVBSEY7U0FEZ0I7TUFBQSxDQUFsQixFQURVO0lBQUEsQ0FBUixFQURRO0VBQUEsQ0FIZCxDQUFBOztBQUFBLEVBYUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsU0FBQyxhQUFELEdBQUE7QUFDZixJQUFBLElBQStCLHFCQUEvQjtBQUFBLGFBQU8sT0FBTyxDQUFDLE1BQVIsQ0FBQSxDQUFQLENBQUE7S0FBQTtXQUVJLElBQUEsT0FBQSxDQUFRLFNBQUMsT0FBRCxHQUFBO0FBQ1YsVUFBQSxtQkFBQTtBQUFBLE1BQUEsU0FBQSxHQUFZLENBQUMsTUFBRCxFQUFTLE1BQVQsRUFBaUIsT0FBakIsRUFBMEIsT0FBMUIsQ0FBa0MsQ0FBQyxHQUFuQyxDQUF1QyxTQUFDLFFBQUQsR0FBQTtlQUNqRCxJQUFJLENBQUMsSUFBTCxDQUFVLGFBQVYsRUFBeUIsUUFBekIsRUFEaUQ7TUFBQSxDQUF2QyxDQUFaLENBQUE7QUFBQSxNQUdBLFFBQUEsR0FBVyxTQUFTLENBQUMsR0FBVixDQUFjLFNBQUMsUUFBRCxHQUFBO2VBQ3ZCLFdBQUEsQ0FBWSxRQUFaLEVBRHVCO01BQUEsQ0FBZCxDQUhYLENBQUE7YUFPQSxPQUFPLENBQUMsR0FBUixDQUFZLFFBQVosQ0FBcUIsQ0FBQyxJQUF0QixDQUEyQixTQUFDLE9BQUQsR0FBQTtBQUN6QixZQUFBLHFCQUFBO0FBQUEsYUFBQSwwREFBQTtnQ0FBQTtBQUNFLFVBQUEsSUFBa0MsTUFBbEM7QUFBQSxtQkFBTyxPQUFBLENBQVEsU0FBVSxDQUFBLEdBQUEsQ0FBbEIsQ0FBUCxDQUFBO1dBREY7QUFBQSxTQUFBO2VBR0EsT0FBQSxDQUFRLEtBQVIsRUFKeUI7TUFBQSxDQUEzQixFQVJVO0lBQUEsQ0FBUixFQUhXO0VBQUEsQ0FiakIsQ0FBQTtBQUFBIgp9

//# sourceURL=/home/shane/.atom/packages/autocomplete-ctags/lib/get-tags-file.coffee
