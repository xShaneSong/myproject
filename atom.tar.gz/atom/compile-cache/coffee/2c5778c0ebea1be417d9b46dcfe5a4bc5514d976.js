(function() {
  var CompositeDisposable, JapaneseWrapManager;

  CompositeDisposable = require('atom').CompositeDisposable;

  JapaneseWrapManager = require('./japanese-wrap-manager');

  module.exports = {
    japaneseWrapManager: null,
    config: {
      characterWidth: {
        type: 'object',
        properties: {
          greekAndCoptic: {
            title: 'ギリシャ文字及びコプト文字の幅',
            type: 'integer',
            "default": 2,
            minimum: 1,
            maximum: 2
          },
          cyrillic: {
            title: 'キリル文字の幅',
            type: 'integer',
            "default": 2,
            minimum: 1,
            maximum: 2
          }
        }
      },
      lineBreakingRule: {
        type: 'object',
        properties: {
          japanese: {
            title: '日本語禁則処理を行う',
            type: 'boolean',
            "default": true
          },
          halfwidthKatakana: {
            title: '半角カタカナ(JIS X 0201 片仮名図形文字集合)を禁則処理に含める',
            type: 'boolean',
            "default": true
          },
          ideographicSpaceAsWihteSpace: {
            title: '和文間隔(U+3000)を空白文字に含める',
            type: 'boolean',
            "default": false
          }
        }
      }
    },
    activate: function(state) {
      var major, minor, patch, _ref;
      _ref = atom.getVersion().split('.').map(function(i) {
        return +i;
      }), major = _ref[0], minor = _ref[1], patch = _ref[2];
      if ((major === 1 && minor >= 2) || major >= 2) {
        atom.notifications.addWarning('The japanese-wrap is DEPRECATED. (japanese-wrap は廃止されました。)', {
          dismissable: true,
          detail: 'The Atom has supported double-width characters, so the japanese-wrap is not necessary. It is no longer available. Please uninstall or dissable it.\nAtom が2幅文字をサポートしたため、 japanese-wrap は不要になりました。このパッケージが今後動作することはありません。 アンインストールまたは無効にしてください。'
        });
        return;
      }
      this.japaneseWrapManager = new JapaneseWrapManager;
      this.subscriptions = new CompositeDisposable;
      return this.subscriptions.add(atom.workspace.observeTextEditors((function(_this) {
        return function(editor) {
          return _this.japaneseWrapManager.overwriteFindWrapColumn(editor.displayBuffer);
        };
      })(this)));
    },
    deactivate: function() {
      var editor, major, minor, patch, _i, _len, _ref, _ref1, _ref2, _ref3, _ref4;
      _ref = atom.getVersion().split('.').map(function(i) {
        return +i;
      }), major = _ref[0], minor = _ref[1], patch = _ref[2];
      if ((major === 1 && minor >= 2) || major >= 2) {
        return;
      }
      if ((_ref1 = this.subscriptions) != null) {
        _ref1.dispose();
      }
      this.subscriptions = null;
      _ref2 = atom.workspace.getTextEditors();
      for (_i = 0, _len = _ref2.length; _i < _len; _i++) {
        editor = _ref2[_i];
        if ((_ref3 = this.japaneseWrapManager) != null) {
          _ref3.restoreFindWrapColumn(editor.displayBuffer);
        }
      }
      if ((_ref4 = this.japaneseWrapManager) != null) {
        _ref4.destroy();
      }
      return this.japaneseWrapManager = null;
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvamFwYW5lc2Utd3JhcC9saWIvamFwYW5lc2Utd3JhcC5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLE1BQUEsd0NBQUE7O0FBQUEsRUFBQyxzQkFBdUIsT0FBQSxDQUFRLE1BQVIsRUFBdkIsbUJBQUQsQ0FBQTs7QUFBQSxFQUNBLG1CQUFBLEdBQXNCLE9BQUEsQ0FBUSx5QkFBUixDQUR0QixDQUFBOztBQUFBLEVBR0EsTUFBTSxDQUFDLE9BQVAsR0FDRTtBQUFBLElBQUEsbUJBQUEsRUFBcUIsSUFBckI7QUFBQSxJQUVBLE1BQUEsRUFhRTtBQUFBLE1BQUEsY0FBQSxFQUNFO0FBQUEsUUFBQSxJQUFBLEVBQU0sUUFBTjtBQUFBLFFBQ0EsVUFBQSxFQUNFO0FBQUEsVUFBQSxjQUFBLEVBQ0U7QUFBQSxZQUFBLEtBQUEsRUFBTyxpQkFBUDtBQUFBLFlBQ0EsSUFBQSxFQUFNLFNBRE47QUFBQSxZQUVBLFNBQUEsRUFBUyxDQUZUO0FBQUEsWUFHQSxPQUFBLEVBQVMsQ0FIVDtBQUFBLFlBSUEsT0FBQSxFQUFTLENBSlQ7V0FERjtBQUFBLFVBTUEsUUFBQSxFQUNFO0FBQUEsWUFBQSxLQUFBLEVBQU8sU0FBUDtBQUFBLFlBQ0EsSUFBQSxFQUFNLFNBRE47QUFBQSxZQUVBLFNBQUEsRUFBUyxDQUZUO0FBQUEsWUFHQSxPQUFBLEVBQVMsQ0FIVDtBQUFBLFlBSUEsT0FBQSxFQUFTLENBSlQ7V0FQRjtTQUZGO09BREY7QUFBQSxNQWtCQSxnQkFBQSxFQUNFO0FBQUEsUUFBQSxJQUFBLEVBQU0sUUFBTjtBQUFBLFFBQ0EsVUFBQSxFQUNFO0FBQUEsVUFBQSxRQUFBLEVBQ0U7QUFBQSxZQUFBLEtBQUEsRUFBTyxZQUFQO0FBQUEsWUFDQSxJQUFBLEVBQU0sU0FETjtBQUFBLFlBRUEsU0FBQSxFQUFTLElBRlQ7V0FERjtBQUFBLFVBSUEsaUJBQUEsRUFDRTtBQUFBLFlBQUEsS0FBQSxFQUFPLHVDQUFQO0FBQUEsWUFDQSxJQUFBLEVBQU0sU0FETjtBQUFBLFlBRUEsU0FBQSxFQUFTLElBRlQ7V0FMRjtBQUFBLFVBUUEsNEJBQUEsRUFDRTtBQUFBLFlBQUEsS0FBQSxFQUFPLHVCQUFQO0FBQUEsWUFDQSxJQUFBLEVBQU0sU0FETjtBQUFBLFlBRUEsU0FBQSxFQUFTLEtBRlQ7V0FURjtTQUZGO09BbkJGO0tBZkY7QUFBQSxJQWlEQSxRQUFBLEVBQVUsU0FBQyxLQUFELEdBQUE7QUFDUixVQUFBLHlCQUFBO0FBQUEsTUFBQSxPQUF3QixJQUFJLENBQUMsVUFBTCxDQUFBLENBQWlCLENBQUMsS0FBbEIsQ0FBd0IsR0FBeEIsQ0FBNEIsQ0FBQyxHQUE3QixDQUFpQyxTQUFDLENBQUQsR0FBQTtlQUFPLENBQUEsRUFBUDtNQUFBLENBQWpDLENBQXhCLEVBQUMsZUFBRCxFQUFRLGVBQVIsRUFBZSxlQUFmLENBQUE7QUFDQSxNQUFBLElBQUcsQ0FBQyxLQUFBLEtBQVMsQ0FBVCxJQUFlLEtBQUEsSUFBUyxDQUF6QixDQUFBLElBQStCLEtBQUEsSUFBUyxDQUEzQztBQUNFLFFBQUEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFuQixDQUE4Qiw0REFBOUIsRUFDRTtBQUFBLFVBQUEsV0FBQSxFQUFhLElBQWI7QUFBQSxVQUNBLE1BQUEsRUFBUSxnUEFEUjtTQURGLENBQUEsQ0FBQTtBQVVBLGNBQUEsQ0FYRjtPQURBO0FBQUEsTUFjQSxJQUFDLENBQUEsbUJBQUQsR0FBdUIsR0FBQSxDQUFBLG1CQWR2QixDQUFBO0FBQUEsTUFnQkEsSUFBQyxDQUFBLGFBQUQsR0FBaUIsR0FBQSxDQUFBLG1CQWhCakIsQ0FBQTthQWlCQSxJQUFDLENBQUEsYUFBYSxDQUFDLEdBQWYsQ0FBbUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxrQkFBZixDQUFrQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxNQUFELEdBQUE7aUJBQ25ELEtBQUMsQ0FBQSxtQkFBbUIsQ0FBQyx1QkFBckIsQ0FBNkMsTUFBTSxDQUFDLGFBQXBELEVBRG1EO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbEMsQ0FBbkIsRUFsQlE7SUFBQSxDQWpEVjtBQUFBLElBeUVBLFVBQUEsRUFBWSxTQUFBLEdBQUE7QUFDVixVQUFBLHVFQUFBO0FBQUEsTUFBQSxPQUF3QixJQUFJLENBQUMsVUFBTCxDQUFBLENBQWlCLENBQUMsS0FBbEIsQ0FBd0IsR0FBeEIsQ0FBNEIsQ0FBQyxHQUE3QixDQUFpQyxTQUFDLENBQUQsR0FBQTtlQUFPLENBQUEsRUFBUDtNQUFBLENBQWpDLENBQXhCLEVBQUMsZUFBRCxFQUFRLGVBQVIsRUFBZSxlQUFmLENBQUE7QUFDQSxNQUFBLElBQUcsQ0FBQyxLQUFBLEtBQVMsQ0FBVCxJQUFlLEtBQUEsSUFBUyxDQUF6QixDQUFBLElBQStCLEtBQUEsSUFBUyxDQUEzQztBQUNFLGNBQUEsQ0FERjtPQURBOzthQUljLENBQUUsT0FBaEIsQ0FBQTtPQUpBO0FBQUEsTUFLQSxJQUFDLENBQUEsYUFBRCxHQUFpQixJQUxqQixDQUFBO0FBT0E7QUFBQSxXQUFBLDRDQUFBOzJCQUFBOztlQUNzQixDQUFFLHFCQUF0QixDQUE0QyxNQUFNLENBQUMsYUFBbkQ7U0FERjtBQUFBLE9BUEE7O2FBWW9CLENBQUUsT0FBdEIsQ0FBQTtPQVpBO2FBYUEsSUFBQyxDQUFBLG1CQUFELEdBQXVCLEtBZGI7SUFBQSxDQXpFWjtHQUpGLENBQUE7QUFBQSIKfQ==

//# sourceURL=/home/shane/.atom/packages/japanese-wrap/lib/japanese-wrap.coffee
