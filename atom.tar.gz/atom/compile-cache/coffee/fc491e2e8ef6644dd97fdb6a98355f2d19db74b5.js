(function() {
  var linkPaths, regex, template;

  regex = /((?:\w:)?\/?(?:[-\w.]+\/)*[-\w.]+):(\d+)(?::(\d+))?/g;

  template = '<a class="-linked-path" data-path="$1" data-line="$2" data-column="$3">$&</a>';

  module.exports = linkPaths = function(lines) {
    return lines.replace(regex, template);
  };

  linkPaths.listen = function(parentView) {
    return parentView.on('click', '.-linked-path', function(event) {
      var column, el, line, path, _ref;
      el = this;
      _ref = el.dataset, path = _ref.path, line = _ref.line, column = _ref.column;
      line = Number(line) - 1;
      column = column ? Number(column) - 1 : 0;
      return atom.workspace.open(path, {
        initialLine: line,
        initialColumn: column
      });
    });
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvc2NyaXB0L2xpYi9saW5rLXBhdGhzLmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSwwQkFBQTs7QUFBQSxFQUFBLEtBQUEsR0FBUSxzREFBUixDQUFBOztBQUFBLEVBTUEsUUFBQSxHQUFXLCtFQU5YLENBQUE7O0FBQUEsRUFRQSxNQUFNLENBQUMsT0FBUCxHQUFpQixTQUFBLEdBQVksU0FBQyxLQUFELEdBQUE7V0FDM0IsS0FBSyxDQUFDLE9BQU4sQ0FBYyxLQUFkLEVBQXFCLFFBQXJCLEVBRDJCO0VBQUEsQ0FSN0IsQ0FBQTs7QUFBQSxFQVdBLFNBQVMsQ0FBQyxNQUFWLEdBQW1CLFNBQUMsVUFBRCxHQUFBO1dBQ2pCLFVBQVUsQ0FBQyxFQUFYLENBQWMsT0FBZCxFQUF1QixlQUF2QixFQUF3QyxTQUFDLEtBQUQsR0FBQTtBQUN0QyxVQUFBLDRCQUFBO0FBQUEsTUFBQSxFQUFBLEdBQUssSUFBTCxDQUFBO0FBQUEsTUFDQSxPQUF1QixFQUFFLENBQUMsT0FBMUIsRUFBQyxZQUFBLElBQUQsRUFBTyxZQUFBLElBQVAsRUFBYSxjQUFBLE1BRGIsQ0FBQTtBQUFBLE1BRUEsSUFBQSxHQUFPLE1BQUEsQ0FBTyxJQUFQLENBQUEsR0FBZSxDQUZ0QixDQUFBO0FBQUEsTUFJQSxNQUFBLEdBQVksTUFBSCxHQUFlLE1BQUEsQ0FBTyxNQUFQLENBQUEsR0FBaUIsQ0FBaEMsR0FBdUMsQ0FKaEQsQ0FBQTthQU1BLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBZixDQUFvQixJQUFwQixFQUEwQjtBQUFBLFFBQ3hCLFdBQUEsRUFBYSxJQURXO0FBQUEsUUFFeEIsYUFBQSxFQUFlLE1BRlM7T0FBMUIsRUFQc0M7SUFBQSxDQUF4QyxFQURpQjtFQUFBLENBWG5CLENBQUE7QUFBQSIKfQ==

//# sourceURL=/home/shane/.atom/packages/script/lib/link-paths.coffee
