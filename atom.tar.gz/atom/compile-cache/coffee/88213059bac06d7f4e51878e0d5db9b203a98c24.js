(function() {
  module.exports = {
    types: {},
    roots: {},
    attributeGroups: {},
    parseFromString: function(xmlString, complete) {
      var xml2js;
      xml2js = require('xml2js');
      return xml2js.parseString(xmlString, {
        tagNameProcessors: [xml2js.processors.stripPrefix],
        preserveChildrenOrder: true,
        explicitChildren: true
      }, (function(_this) {
        return function(err, result) {
          if (err) {
            return console.error(err);
          } else {
            return _this.parse(result, complete);
          }
        };
      })(this));
    },
    parse: function(xml, complete) {
      var name, node, value, xsdStandard, _i, _j, _k, _len, _len1, _len2, _ref, _ref1, _ref2, _ref3, _ref4;
      xml = xml.schema;
      if (!xml) {
        return;
      }
      xsdStandard = xml.$["xmlns:xs"];
      if (!xsdStandard || xsdStandard !== "http://www.w3.org/2001/XMLSchema") {
        console.log("The schema doesn't follow the standard.");
        return;
      }
      _ref = xml.$$;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        node = _ref[_i];
        this.parseType(node);
      }
      _ref1 = xml.element;
      for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
        node = _ref1[_j];
        this.parseRoot(node);
      }
      _ref2 = this.roots;
      for (name in _ref2) {
        value = _ref2[name];
        this.types[name] = value;
      }
      _ref4 = (_ref3 = xml.attributeGroup) != null ? _ref3 : [];
      for (_k = 0, _len2 = _ref4.length; _k < _len2; _k++) {
        node = _ref4[_k];
        this.parseAttributeGroup(node);
      }
      return this.postParsing();
    },
    parseType: function(node, typeName) {
      var nodeName, type;
      type = this.initTypeObject(node, typeName);
      if (!type.xsdTypeName) {
        return null;
      }
      nodeName = node["#name"];
      if (nodeName === "simpleType") {
        return this.parseSimpleType(node, type);
      } else if (nodeName === "complexType") {
        return this.parseComplexType(node, type);
      } else if (nodeName === "group") {
        return this.parseGroupType(node, type);
      }
    },
    normalizeString: function(str) {
      return str != null ? typeof str.replace === "function" ? str.replace(/[\n\r]/, '').trim() : void 0 : void 0;
    },
    getDocumentation: function(node) {
      var _ref, _ref1, _ref2;
      return this.normalizeString((_ref = node != null ? (_ref1 = node.annotation) != null ? _ref1[0].documentation[0]._ : void 0 : void 0) != null ? _ref : node != null ? (_ref2 = node.annotation) != null ? _ref2[0].documentation[0] : void 0 : void 0);
    },
    initTypeObject: function(node, typeName) {
      var type, _ref;
      return type = {
        xsdType: '',
        xsdTypeName: typeName != null ? typeName : (_ref = node.$) != null ? _ref.name : void 0,
        xsdAttributes: [],
        xsdChildrenMode: '',
        xsdChildren: [],
        text: '',
        displayText: '',
        description: this.getDocumentation(node),
        type: 'tag',
        rightLabel: 'Tag'
      };
    },
    parseSimpleType: function(node, type) {
      var childrenNode, group, val, _i, _len, _ref, _ref1;
      type.xsdType = 'simple';
      if ((_ref = node.restriction) != null ? _ref[0].enumeration : void 0) {
        type.xsdChildrenMode = 'restriction';
        childrenNode = node.restriction[0];
        type.leftLabel = childrenNode.$.base;
      } else if (node.union) {
        type.xsdChildrenMode = 'union';
        type.leftLabel = node.union[0].$.memberTypes;
      }
      if (childrenNode) {
        group = {
          childType: 'choice',
          description: '',
          minOccurs: 0,
          maxOccurs: 'unbounded',
          elements: []
        };
        type.xsdChildren.push(group);
        _ref1 = childrenNode.enumeration;
        for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
          val = _ref1[_i];
          group.elements.push({
            tagName: val.$.value,
            xsdTypeName: null,
            description: '',
            minOccurs: 0,
            maxOccurs: 1
          });
        }
      }
      this.types[type.xsdTypeName] = type;
      return type;
    },
    parseComplexType: function(node, type) {
      var childrenNode, n, _ref;
      type.xsdType = 'complex';
      childrenNode = null;
      if (node.sequence) {
        type.xsdChildrenMode = 'sequence';
        childrenNode = node.sequence[0];
      } else if (node.choice) {
        type.xsdChildrenMode = 'choice';
        childrenNode = node.choice[0];
      } else if (node.all) {
        type.xsdChildrenMode = 'all';
        childrenNode = node.all[0];
      } else if ((_ref = node.complexContent) != null ? _ref[0].extension : void 0) {
        type.xsdChildrenMode = 'extension';
        type.xsdChildren = node.complexContent[0].extension[0];
      } else if (node.group) {
        type.xsdChildrenMode = 'group';
        type.xsdChildren = node.group[0];
      }
      if (childrenNode) {
        type.xsdChildren = (this.parseChildrenGroups(childrenNode.element, 'element')).concat(this.parseChildrenGroups(childrenNode.choice, 'choice')).concat(this.parseChildrenGroups(childrenNode.sequence, 'sequence')).concat(this.parseChildrenGroups(childrenNode.group, 'group'));
      }
      if (node.attribute) {
        type.xsdAttributes = ((function() {
          var _i, _len, _ref1, _results;
          _ref1 = node.$$;
          _results = [];
          for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
            n = _ref1[_i];
            _results.push(this.parseAttribute(n));
          }
          return _results;
        }).call(this)).filter(Boolean);
      }
      this.types[type.xsdTypeName] = type;
      return type;
    },
    parseChildrenGroups: function(groupNodes, mode) {
      var childNode, groups, node, _i, _len, _ref, _ref1, _ref2, _ref3, _ref4;
      if (!groupNodes) {
        return [];
      }
      groups = [];
      for (_i = 0, _len = groupNodes.length; _i < _len; _i++) {
        node = groupNodes[_i];
        groups.push({
          childType: mode,
          ref: (_ref = node.$) != null ? _ref.ref : void 0,
          description: this.getDocumentation(node),
          minOccurs: (_ref1 = (_ref2 = node.$) != null ? _ref2.minOccurs : void 0) != null ? _ref1 : 0,
          maxOccurs: (_ref3 = (_ref4 = node.$) != null ? _ref4.maxOccurs : void 0) != null ? _ref3 : 'unbounded',
          elements: mode === 'element' ? [].concat(this.parseElement(node)) : (function() {
            var _j, _len1, _ref5, _ref6, _results;
            _ref6 = (_ref5 = node.element) != null ? _ref5 : [];
            _results = [];
            for (_j = 0, _len1 = _ref6.length; _j < _len1; _j++) {
              childNode = _ref6[_j];
              _results.push(this.parseElement(childNode));
            }
            return _results;
          }).call(this)
        });
      }
      return groups;
    },
    parseAnonElements: function(node) {
      var childNode, randomName, _i, _len, _ref;
      randomName = require('uuid')();
      _ref = node.$$;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        childNode = _ref[_i];
        this.parseType(childNode, randomName);
      }
      return randomName;
    },
    parseElement: function(node) {
      var child, _ref, _ref1, _ref2, _ref3;
      child = {
        tagName: (_ref = node.$.name) != null ? _ref : node.$.ref,
        xsdTypeName: (_ref1 = node.$.type) != null ? _ref1 : node.$.ref,
        minOccurs: (_ref2 = node.$.minOccurs) != null ? _ref2 : 0,
        maxOccurs: (_ref3 = node.$.maxOccurs) != null ? _ref3 : 'unbounded',
        description: this.getDocumentation(node)
      };
      if (!child.xsdTypeName && node.$$) {
        child.xsdTypeName = this.parseAnonElements(node);
      }
      return child;
    },
    parseAttribute: function(node) {
      var attr, nodeName;
      nodeName = node["#name"];
      if (nodeName === "attribute" && node.$.use !== "prohibited") {
        attr = {
          name: node.$.name,
          type: node.$.type,
          description: this.getDocumentation(node),
          fixed: node.$.fixed,
          use: node.$.use,
          "default": node.$["default"]
        };
        if (!node.$.type && node.$$) {
          attr.type = this.parseAnonElements(node);
        }
        return attr;
      } else if (nodeName === "attributeGroup") {
        return {
          ref: node.$.ref
        };
      } else {
        return null;
      }
    },
    parseAttributeGroup: function(node) {
      var attributes, name, xattr;
      name = node.$.name;
      attributes = ((function() {
        var _i, _len, _ref, _results;
        _ref = node.$$;
        _results = [];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          xattr = _ref[_i];
          _results.push(this.parseAttribute(xattr));
        }
        return _results;
      }).call(this)).filter(Boolean);
      return this.attributeGroups[name] = attributes;
    },
    parseGroupType: function(node, type) {
      return this.parseComplexType(node, type);
    },
    parseRoot: function(node) {
      var root, rootElement, rootTagName, rootType, _ref;
      rootElement = this.parseElement(node);
      rootTagName = rootElement.tagName;
      rootType = this.types[rootElement.xsdTypeName];
      root = this.initTypeObject(null, rootElement.xsdTypeName);
      root.description = (_ref = rootElement.description) != null ? _ref : rootType.description;
      root.text = rootTagName;
      root.displayText = rootTagName;
      root.type = 'class';
      root.rightLabel = 'Root';
      root.xsdType = 'complex';
      root.xsdAttributes = rootType.xsdAttributes;
      root.xsdChildrenMode = rootType.xsdChildrenMode;
      root.xsdChildren = rootType.xsdChildren;
      this.roots[rootTagName] = root;
      return root;
    },
    postParsing: function() {
      var attr, attributes, extenAttr, extenType, group, groupType, groups, linkType, memberType, n, name, t, type, unionTypes, _i, _j, _k, _len, _len1, _len2, _ref, _ref1, _ref2, _results;
      _ref = this.types;
      _results = [];
      for (name in _ref) {
        type = _ref[name];
        if (type.xsdChildrenMode === 'extension') {
          extenType = type.xsdChildren;
          extenAttr = ((function() {
            var _i, _len, _ref1, _results1;
            _ref1 = extenType.$$ || [];
            _results1 = [];
            for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
              n = _ref1[_i];
              _results1.push(this.parseAttribute(n));
            }
            return _results1;
          }).call(this)).filter(Boolean);
          linkType = this.types[extenType.$.base];
          type.xsdTypeName = linkType.xsdTypeName;
          type.xsdChildrenMode = linkType.xsdChildrenMode;
          type.xsdChildren = linkType.xsdChildren;
          type.xsdAttributes = extenAttr.concat(linkType.xsdAttributes);
          if (type.description == null) {
            type.description = linkType.description;
          }
          type.type = linkType.type;
          type.rightLabel = linkType.rightLabel;
        } else if (type.xsdChildrenMode === 'group') {
          groupType = type.xsdChildren;
          linkType = this.types[groupType.$.ref];
          type.xsdChildren = linkType.xsdChildren;
          type.xsdChildrenMode = linkType.xsdChildrenMode;
        } else if (type.xsdChildrenMode === 'union') {
          unionTypes = type.leftLabel.split(' ');
          type.xsdChildrenMode = 'restriction';
          for (_i = 0, _len = unionTypes.length; _i < _len; _i++) {
            t = unionTypes[_i];
            memberType = this.types[t];
            if (memberType) {
              type.xsdChildren.push(memberType.xsdChildren[0]);
            }
          }
        }
        _ref1 = type.xsdChildren;
        for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
          group = _ref1[_j];
          if (group.childType === 'group') {
            linkType = this.types[group.ref];
            type.xsdChildren = linkType.xsdChildren;
            break;
          }
        }
        groups = (function() {
          var _k, _len2, _ref2, _results1;
          _ref2 = type.xsdAttributes;
          _results1 = [];
          for (_k = 0, _len2 = _ref2.length; _k < _len2; _k++) {
            attr = _ref2[_k];
            if (attr.ref) {
              _results1.push(attr.ref);
            }
          }
          return _results1;
        })();
        attributes = [];
        _ref2 = type.xsdAttributes;
        for (_k = 0, _len2 = _ref2.length; _k < _len2; _k++) {
          attr = _ref2[_k];
          if (attr.ref) {
            attributes = attributes.concat(this.attributeGroups[attr.ref]);
          } else {
            attributes.push(attr);
          }
        }
        _results.push(type.xsdAttributes = attributes);
      }
      return _results;
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvYXV0b2NvbXBsZXRlLXhtbC9saWIveHNkUGFyc2VyLmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsRUFBQSxNQUFNLENBQUMsT0FBUCxHQWdDRTtBQUFBLElBQUEsS0FBQSxFQUFPLEVBQVA7QUFBQSxJQUNBLEtBQUEsRUFBTyxFQURQO0FBQUEsSUFFQSxlQUFBLEVBQWlCLEVBRmpCO0FBQUEsSUFJQSxlQUFBLEVBQWlCLFNBQUMsU0FBRCxFQUFZLFFBQVosR0FBQTtBQUNmLFVBQUEsTUFBQTtBQUFBLE1BQUEsTUFBQSxHQUFTLE9BQUEsQ0FBUSxRQUFSLENBQVQsQ0FBQTthQUNBLE1BQU0sQ0FBQyxXQUFQLENBQW1CLFNBQW5CLEVBQThCO0FBQUEsUUFDNUIsaUJBQUEsRUFBbUIsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFdBQW5CLENBRFM7QUFBQSxRQUU1QixxQkFBQSxFQUF1QixJQUZLO0FBQUEsUUFHNUIsZ0JBQUEsRUFBa0IsSUFIVTtPQUE5QixFQUlLLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLEdBQUQsRUFBTSxNQUFOLEdBQUE7QUFDRCxVQUFBLElBQUcsR0FBSDttQkFBWSxPQUFPLENBQUMsS0FBUixDQUFjLEdBQWQsRUFBWjtXQUFBLE1BQUE7bUJBQW1DLEtBQUMsQ0FBQSxLQUFELENBQU8sTUFBUCxFQUFlLFFBQWYsRUFBbkM7V0FEQztRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBSkwsRUFGZTtJQUFBLENBSmpCO0FBQUEsSUFlQSxLQUFBLEVBQU8sU0FBQyxHQUFELEVBQU0sUUFBTixHQUFBO0FBRUwsVUFBQSxnR0FBQTtBQUFBLE1BQUEsR0FBQSxHQUFNLEdBQUcsQ0FBQyxNQUFWLENBQUE7QUFHQSxNQUFBLElBQUcsQ0FBQSxHQUFIO0FBQ0UsY0FBQSxDQURGO09BSEE7QUFBQSxNQU9BLFdBQUEsR0FBYyxHQUFHLENBQUMsQ0FBRSxDQUFBLFVBQUEsQ0FQcEIsQ0FBQTtBQVFBLE1BQUEsSUFBRyxDQUFBLFdBQUEsSUFBbUIsV0FBQSxLQUFpQixrQ0FBdkM7QUFDRSxRQUFBLE9BQU8sQ0FBQyxHQUFSLENBQVkseUNBQVosQ0FBQSxDQUFBO0FBQ0EsY0FBQSxDQUZGO09BUkE7QUFhQTtBQUFBLFdBQUEsMkNBQUE7d0JBQUE7QUFBQSxRQUFBLElBQUMsQ0FBQSxTQUFELENBQVcsSUFBWCxDQUFBLENBQUE7QUFBQSxPQWJBO0FBZ0JBO0FBQUEsV0FBQSw4Q0FBQTt5QkFBQTtBQUFBLFFBQUEsSUFBQyxDQUFBLFNBQUQsQ0FBVyxJQUFYLENBQUEsQ0FBQTtBQUFBLE9BaEJBO0FBbUJBO0FBQUEsV0FBQSxhQUFBOzRCQUFBO0FBQUEsUUFBQSxJQUFDLENBQUEsS0FBTSxDQUFBLElBQUEsQ0FBUCxHQUFlLEtBQWYsQ0FBQTtBQUFBLE9BbkJBO0FBc0JBO0FBQUEsV0FBQSw4Q0FBQTt5QkFBQTtBQUFBLFFBQUEsSUFBQyxDQUFBLG1CQUFELENBQXFCLElBQXJCLENBQUEsQ0FBQTtBQUFBLE9BdEJBO2FBeUJBLElBQUMsQ0FBQSxXQUFELENBQUEsRUEzQks7SUFBQSxDQWZQO0FBQUEsSUE4Q0EsU0FBQSxFQUFXLFNBQUMsSUFBRCxFQUFPLFFBQVAsR0FBQTtBQUVULFVBQUEsY0FBQTtBQUFBLE1BQUEsSUFBQSxHQUFPLElBQUMsQ0FBQSxjQUFELENBQWdCLElBQWhCLEVBQXNCLFFBQXRCLENBQVAsQ0FBQTtBQUNBLE1BQUEsSUFBZSxDQUFBLElBQVEsQ0FBQyxXQUF4QjtBQUFBLGVBQU8sSUFBUCxDQUFBO09BREE7QUFBQSxNQUlBLFFBQUEsR0FBVyxJQUFLLENBQUEsT0FBQSxDQUpoQixDQUFBO0FBS0EsTUFBQSxJQUFHLFFBQUEsS0FBWSxZQUFmO2VBQ0UsSUFBQyxDQUFBLGVBQUQsQ0FBaUIsSUFBakIsRUFBdUIsSUFBdkIsRUFERjtPQUFBLE1BRUssSUFBRyxRQUFBLEtBQVksYUFBZjtlQUNILElBQUMsQ0FBQSxnQkFBRCxDQUFrQixJQUFsQixFQUF3QixJQUF4QixFQURHO09BQUEsTUFFQSxJQUFHLFFBQUEsS0FBWSxPQUFmO2VBQ0gsSUFBQyxDQUFBLGNBQUQsQ0FBZ0IsSUFBaEIsRUFBc0IsSUFBdEIsRUFERztPQVhJO0lBQUEsQ0E5Q1g7QUFBQSxJQThEQSxlQUFBLEVBQWlCLFNBQUMsR0FBRCxHQUFBOytEQUNmLEdBQUcsQ0FBRSxRQUFTLFVBQVUsR0FBRyxDQUFDLElBQTVCLENBQUEsb0JBRGU7SUFBQSxDQTlEakI7QUFBQSxJQW1FQSxnQkFBQSxFQUFrQixTQUFDLElBQUQsR0FBQTtBQUNoQixVQUFBLGtCQUFBO2FBQUEsSUFBQyxDQUFBLGVBQUQsb0xBQ29CLENBQUEsQ0FBQSxDQUFFLENBQUMsYUFBYyxDQUFBLENBQUEsbUJBRHJDLEVBRGdCO0lBQUEsQ0FuRWxCO0FBQUEsSUF5RUEsY0FBQSxFQUFnQixTQUFDLElBQUQsRUFBTyxRQUFQLEdBQUE7QUFDZCxVQUFBLFVBQUE7YUFBQSxJQUFBLEdBRUU7QUFBQSxRQUFBLE9BQUEsRUFBUyxFQUFUO0FBQUEsUUFDQSxXQUFBLHFCQUFhLHlDQUFpQixDQUFFLGFBRGhDO0FBQUEsUUFFQSxhQUFBLEVBQWUsRUFGZjtBQUFBLFFBR0EsZUFBQSxFQUFpQixFQUhqQjtBQUFBLFFBSUEsV0FBQSxFQUFhLEVBSmI7QUFBQSxRQU9BLElBQUEsRUFBTSxFQVBOO0FBQUEsUUFRQSxXQUFBLEVBQWEsRUFSYjtBQUFBLFFBU0EsV0FBQSxFQUFhLElBQUMsQ0FBQSxnQkFBRCxDQUFrQixJQUFsQixDQVRiO0FBQUEsUUFVQSxJQUFBLEVBQU0sS0FWTjtBQUFBLFFBV0EsVUFBQSxFQUFZLEtBWFo7UUFIWTtJQUFBLENBekVoQjtBQUFBLElBMkZBLGVBQUEsRUFBaUIsU0FBQyxJQUFELEVBQU8sSUFBUCxHQUFBO0FBQ2YsVUFBQSwrQ0FBQTtBQUFBLE1BQUEsSUFBSSxDQUFDLE9BQUwsR0FBZSxRQUFmLENBQUE7QUFLQSxNQUFBLDRDQUFxQixDQUFBLENBQUEsQ0FBRSxDQUFDLG9CQUF4QjtBQUNFLFFBQUEsSUFBSSxDQUFDLGVBQUwsR0FBdUIsYUFBdkIsQ0FBQTtBQUFBLFFBQ0EsWUFBQSxHQUFlLElBQUksQ0FBQyxXQUFZLENBQUEsQ0FBQSxDQURoQyxDQUFBO0FBQUEsUUFFQSxJQUFJLENBQUMsU0FBTCxHQUFpQixZQUFZLENBQUMsQ0FBQyxDQUFDLElBRmhDLENBREY7T0FBQSxNQUlLLElBQUcsSUFBSSxDQUFDLEtBQVI7QUFDSCxRQUFBLElBQUksQ0FBQyxlQUFMLEdBQXVCLE9BQXZCLENBQUE7QUFBQSxRQUNBLElBQUksQ0FBQyxTQUFMLEdBQWlCLElBQUksQ0FBQyxLQUFNLENBQUEsQ0FBQSxDQUFFLENBQUMsQ0FBQyxDQUFDLFdBRGpDLENBREc7T0FUTDtBQWFBLE1BQUEsSUFBRyxZQUFIO0FBQ0UsUUFBQSxLQUFBLEdBQ0U7QUFBQSxVQUFBLFNBQUEsRUFBVyxRQUFYO0FBQUEsVUFDQSxXQUFBLEVBQWEsRUFEYjtBQUFBLFVBRUEsU0FBQSxFQUFXLENBRlg7QUFBQSxVQUdBLFNBQUEsRUFBVyxXQUhYO0FBQUEsVUFJQSxRQUFBLEVBQVUsRUFKVjtTQURGLENBQUE7QUFBQSxRQU1BLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBakIsQ0FBc0IsS0FBdEIsQ0FOQSxDQUFBO0FBUUE7QUFBQSxhQUFBLDRDQUFBOzBCQUFBO0FBQ0UsVUFBQSxLQUFLLENBQUMsUUFBUSxDQUFDLElBQWYsQ0FBb0I7QUFBQSxZQUNsQixPQUFBLEVBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQURHO0FBQUEsWUFFbEIsV0FBQSxFQUFhLElBRks7QUFBQSxZQUdsQixXQUFBLEVBQWEsRUFISztBQUFBLFlBSWxCLFNBQUEsRUFBVyxDQUpPO0FBQUEsWUFLbEIsU0FBQSxFQUFXLENBTE87V0FBcEIsQ0FBQSxDQURGO0FBQUEsU0FURjtPQWJBO0FBQUEsTUErQkEsSUFBQyxDQUFBLEtBQU0sQ0FBQSxJQUFJLENBQUMsV0FBTCxDQUFQLEdBQTJCLElBL0IzQixDQUFBO0FBZ0NBLGFBQU8sSUFBUCxDQWpDZTtJQUFBLENBM0ZqQjtBQUFBLElBZ0lBLGdCQUFBLEVBQWtCLFNBQUMsSUFBRCxFQUFPLElBQVAsR0FBQTtBQUNoQixVQUFBLHFCQUFBO0FBQUEsTUFBQSxJQUFJLENBQUMsT0FBTCxHQUFlLFNBQWYsQ0FBQTtBQUFBLE1BR0EsWUFBQSxHQUFlLElBSGYsQ0FBQTtBQUlBLE1BQUEsSUFBRyxJQUFJLENBQUMsUUFBUjtBQUNFLFFBQUEsSUFBSSxDQUFDLGVBQUwsR0FBdUIsVUFBdkIsQ0FBQTtBQUFBLFFBQ0EsWUFBQSxHQUFlLElBQUksQ0FBQyxRQUFTLENBQUEsQ0FBQSxDQUQ3QixDQURGO09BQUEsTUFHSyxJQUFHLElBQUksQ0FBQyxNQUFSO0FBQ0gsUUFBQSxJQUFJLENBQUMsZUFBTCxHQUF1QixRQUF2QixDQUFBO0FBQUEsUUFDQSxZQUFBLEdBQWUsSUFBSSxDQUFDLE1BQU8sQ0FBQSxDQUFBLENBRDNCLENBREc7T0FBQSxNQUdBLElBQUcsSUFBSSxDQUFDLEdBQVI7QUFDSCxRQUFBLElBQUksQ0FBQyxlQUFMLEdBQXVCLEtBQXZCLENBQUE7QUFBQSxRQUNBLFlBQUEsR0FBZSxJQUFJLENBQUMsR0FBSSxDQUFBLENBQUEsQ0FEeEIsQ0FERztPQUFBLE1BR0EsK0NBQXdCLENBQUEsQ0FBQSxDQUFFLENBQUMsa0JBQTNCO0FBQ0gsUUFBQSxJQUFJLENBQUMsZUFBTCxHQUF1QixXQUF2QixDQUFBO0FBQUEsUUFDQSxJQUFJLENBQUMsV0FBTCxHQUFtQixJQUFJLENBQUMsY0FBZSxDQUFBLENBQUEsQ0FBRSxDQUFDLFNBQVUsQ0FBQSxDQUFBLENBRHBELENBREc7T0FBQSxNQUdBLElBQUcsSUFBSSxDQUFDLEtBQVI7QUFDSCxRQUFBLElBQUksQ0FBQyxlQUFMLEdBQXVCLE9BQXZCLENBQUE7QUFBQSxRQUNBLElBQUksQ0FBQyxXQUFMLEdBQW1CLElBQUksQ0FBQyxLQUFNLENBQUEsQ0FBQSxDQUQ5QixDQURHO09BaEJMO0FBcUJBLE1BQUEsSUFBRyxZQUFIO0FBQ0UsUUFBQSxJQUFJLENBQUMsV0FBTCxHQUNFLENBQUMsSUFBQyxDQUFBLG1CQUFELENBQXFCLFlBQVksQ0FBQyxPQUFsQyxFQUEyQyxTQUEzQyxDQUFELENBQ0EsQ0FBQyxNQURELENBQ1MsSUFBQyxDQUFBLG1CQUFELENBQXFCLFlBQVksQ0FBQyxNQUFsQyxFQUEwQyxRQUExQyxDQURULENBRUEsQ0FBQyxNQUZELENBRVMsSUFBQyxDQUFBLG1CQUFELENBQXFCLFlBQVksQ0FBQyxRQUFsQyxFQUE0QyxVQUE1QyxDQUZULENBR0EsQ0FBQyxNQUhELENBR1MsSUFBQyxDQUFBLG1CQUFELENBQXFCLFlBQVksQ0FBQyxLQUFsQyxFQUF5QyxPQUF6QyxDQUhULENBREYsQ0FERjtPQXJCQTtBQTRCQSxNQUFBLElBQUcsSUFBSSxDQUFDLFNBQVI7QUFDRSxRQUFBLElBQUksQ0FBQyxhQUFMLEdBQXFCOztBQUFDO0FBQUE7ZUFBQSw0Q0FBQTswQkFBQTtBQUFBLDBCQUFBLElBQUMsQ0FBQSxjQUFELENBQWdCLENBQWhCLEVBQUEsQ0FBQTtBQUFBOztxQkFBRCxDQUFvQyxDQUFDLE1BQXJDLENBQTRDLE9BQTVDLENBQXJCLENBREY7T0E1QkE7QUFBQSxNQStCQSxJQUFDLENBQUEsS0FBTSxDQUFBLElBQUksQ0FBQyxXQUFMLENBQVAsR0FBMkIsSUEvQjNCLENBQUE7QUFnQ0EsYUFBTyxJQUFQLENBakNnQjtJQUFBLENBaElsQjtBQUFBLElBcUtBLG1CQUFBLEVBQXFCLFNBQUMsVUFBRCxFQUFhLElBQWIsR0FBQTtBQUNuQixVQUFBLG1FQUFBO0FBQUEsTUFBQSxJQUFHLENBQUEsVUFBSDtBQUNFLGVBQU8sRUFBUCxDQURGO09BQUE7QUFBQSxNQUlBLE1BQUEsR0FBUyxFQUpULENBQUE7QUFLQSxXQUFBLGlEQUFBOzhCQUFBO0FBQ0UsUUFBQSxNQUFNLENBQUMsSUFBUCxDQUFZO0FBQUEsVUFDVixTQUFBLEVBQVcsSUFERDtBQUFBLFVBRVYsR0FBQSxnQ0FBVyxDQUFFLFlBRkg7QUFBQSxVQUdWLFdBQUEsRUFBYSxJQUFDLENBQUEsZ0JBQUQsQ0FBa0IsSUFBbEIsQ0FISDtBQUFBLFVBSVYsU0FBQSxrRkFBK0IsQ0FKckI7QUFBQSxVQUtWLFNBQUEsa0ZBQStCLFdBTHJCO0FBQUEsVUFRVixRQUFBLEVBQWEsSUFBQSxLQUFRLFNBQVgsR0FBMEIsRUFBRSxDQUFDLE1BQUgsQ0FBVSxJQUFDLENBQUEsWUFBRCxDQUFjLElBQWQsQ0FBVixDQUExQjs7QUFDUDtBQUFBO2lCQUFBLDhDQUFBO29DQUFBO0FBQUEsNEJBQUEsSUFBQyxDQUFBLFlBQUQsQ0FBYyxTQUFkLEVBQUEsQ0FBQTtBQUFBOzt1QkFUTztTQUFaLENBQUEsQ0FERjtBQUFBLE9BTEE7QUFpQkEsYUFBTyxNQUFQLENBbEJtQjtJQUFBLENBcktyQjtBQUFBLElBMkxBLGlCQUFBLEVBQW1CLFNBQUMsSUFBRCxHQUFBO0FBR2pCLFVBQUEscUNBQUE7QUFBQSxNQUFBLFVBQUEsR0FBYSxPQUFBLENBQVEsTUFBUixDQUFBLENBQUEsQ0FBYixDQUFBO0FBQ0E7QUFBQSxXQUFBLDJDQUFBOzZCQUFBO0FBQUEsUUFBQSxJQUFDLENBQUEsU0FBRCxDQUFXLFNBQVgsRUFBc0IsVUFBdEIsQ0FBQSxDQUFBO0FBQUEsT0FEQTtBQUVBLGFBQU8sVUFBUCxDQUxpQjtJQUFBLENBM0xuQjtBQUFBLElBb01BLFlBQUEsRUFBYyxTQUFDLElBQUQsR0FBQTtBQUNaLFVBQUEsZ0NBQUE7QUFBQSxNQUFBLEtBQUEsR0FDRTtBQUFBLFFBQUEsT0FBQSx3Q0FBdUIsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUE5QjtBQUFBLFFBQ0EsV0FBQSwwQ0FBMkIsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQURsQztBQUFBLFFBRUEsU0FBQSwrQ0FBOEIsQ0FGOUI7QUFBQSxRQUdBLFNBQUEsK0NBQThCLFdBSDlCO0FBQUEsUUFJQSxXQUFBLEVBQWEsSUFBQyxDQUFBLGdCQUFELENBQWtCLElBQWxCLENBSmI7T0FERixDQUFBO0FBUUEsTUFBQSxJQUFHLENBQUEsS0FBUyxDQUFDLFdBQVYsSUFBMEIsSUFBSSxDQUFDLEVBQWxDO0FBQ0UsUUFBQSxLQUFLLENBQUMsV0FBTixHQUFvQixJQUFDLENBQUEsaUJBQUQsQ0FBbUIsSUFBbkIsQ0FBcEIsQ0FERjtPQVJBO0FBV0EsYUFBTyxLQUFQLENBWlk7SUFBQSxDQXBNZDtBQUFBLElBbU5BLGNBQUEsRUFBZ0IsU0FBQyxJQUFELEdBQUE7QUFDZCxVQUFBLGNBQUE7QUFBQSxNQUFBLFFBQUEsR0FBVyxJQUFLLENBQUEsT0FBQSxDQUFoQixDQUFBO0FBQ0EsTUFBQSxJQUFHLFFBQUEsS0FBWSxXQUFaLElBQTRCLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBUCxLQUFnQixZQUEvQztBQUNFLFFBQUEsSUFBQSxHQUNFO0FBQUEsVUFBQSxJQUFBLEVBQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFiO0FBQUEsVUFDQSxJQUFBLEVBQU0sSUFBSSxDQUFDLENBQUMsQ0FBQyxJQURiO0FBQUEsVUFFQSxXQUFBLEVBQWEsSUFBQyxDQUFBLGdCQUFELENBQWtCLElBQWxCLENBRmI7QUFBQSxVQUdBLEtBQUEsRUFBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBSGQ7QUFBQSxVQUlBLEdBQUEsRUFBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBSlo7QUFBQSxVQUtBLFNBQUEsRUFBUyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQUQsQ0FMZjtTQURGLENBQUE7QUFTQSxRQUFBLElBQUcsQ0FBQSxJQUFRLENBQUMsQ0FBQyxDQUFDLElBQVgsSUFBb0IsSUFBSSxDQUFDLEVBQTVCO0FBQ0UsVUFBQSxJQUFJLENBQUMsSUFBTCxHQUFZLElBQUMsQ0FBQSxpQkFBRCxDQUFtQixJQUFuQixDQUFaLENBREY7U0FUQTtBQVdBLGVBQU8sSUFBUCxDQVpGO09BQUEsTUFhSyxJQUFHLFFBQUEsS0FBWSxnQkFBZjtBQUNILGVBQU87QUFBQSxVQUFDLEdBQUEsRUFBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQWI7U0FBUCxDQURHO09BQUEsTUFBQTtBQUdILGVBQU8sSUFBUCxDQUhHO09BZlM7SUFBQSxDQW5OaEI7QUFBQSxJQXlPQSxtQkFBQSxFQUFxQixTQUFDLElBQUQsR0FBQTtBQUNuQixVQUFBLHVCQUFBO0FBQUEsTUFBQSxJQUFBLEdBQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFkLENBQUE7QUFBQSxNQUNBLFVBQUEsR0FBYTs7QUFBQztBQUFBO2FBQUEsMkNBQUE7MkJBQUE7QUFBQSx3QkFBQSxJQUFDLENBQUEsY0FBRCxDQUFnQixLQUFoQixFQUFBLENBQUE7QUFBQTs7bUJBQUQsQ0FBNEMsQ0FBQyxNQUE3QyxDQUFvRCxPQUFwRCxDQURiLENBQUE7YUFFQSxJQUFDLENBQUEsZUFBZ0IsQ0FBQSxJQUFBLENBQWpCLEdBQXlCLFdBSE47SUFBQSxDQXpPckI7QUFBQSxJQWdQQSxjQUFBLEVBQWdCLFNBQUMsSUFBRCxFQUFPLElBQVAsR0FBQTthQUNkLElBQUMsQ0FBQSxnQkFBRCxDQUFrQixJQUFsQixFQUF3QixJQUF4QixFQURjO0lBQUEsQ0FoUGhCO0FBQUEsSUFxUEEsU0FBQSxFQUFXLFNBQUMsSUFBRCxHQUFBO0FBRVQsVUFBQSw4Q0FBQTtBQUFBLE1BQUEsV0FBQSxHQUFjLElBQUMsQ0FBQSxZQUFELENBQWMsSUFBZCxDQUFkLENBQUE7QUFBQSxNQUNBLFdBQUEsR0FBYyxXQUFXLENBQUMsT0FEMUIsQ0FBQTtBQUFBLE1BRUEsUUFBQSxHQUFXLElBQUMsQ0FBQSxLQUFNLENBQUEsV0FBVyxDQUFDLFdBQVosQ0FGbEIsQ0FBQTtBQUFBLE1BS0EsSUFBQSxHQUFPLElBQUMsQ0FBQSxjQUFELENBQWdCLElBQWhCLEVBQXNCLFdBQVcsQ0FBQyxXQUFsQyxDQUxQLENBQUE7QUFBQSxNQU1BLElBQUksQ0FBQyxXQUFMLHFEQUE2QyxRQUFRLENBQUMsV0FOdEQsQ0FBQTtBQUFBLE1BT0EsSUFBSSxDQUFDLElBQUwsR0FBWSxXQVBaLENBQUE7QUFBQSxNQVFBLElBQUksQ0FBQyxXQUFMLEdBQW1CLFdBUm5CLENBQUE7QUFBQSxNQVNBLElBQUksQ0FBQyxJQUFMLEdBQVksT0FUWixDQUFBO0FBQUEsTUFVQSxJQUFJLENBQUMsVUFBTCxHQUFrQixNQVZsQixDQUFBO0FBQUEsTUFXQSxJQUFJLENBQUMsT0FBTCxHQUFlLFNBWGYsQ0FBQTtBQUFBLE1BY0EsSUFBSSxDQUFDLGFBQUwsR0FBcUIsUUFBUSxDQUFDLGFBZDlCLENBQUE7QUFBQSxNQWVBLElBQUksQ0FBQyxlQUFMLEdBQXVCLFFBQVEsQ0FBQyxlQWZoQyxDQUFBO0FBQUEsTUFnQkEsSUFBSSxDQUFDLFdBQUwsR0FBbUIsUUFBUSxDQUFDLFdBaEI1QixDQUFBO0FBQUEsTUFrQkEsSUFBQyxDQUFBLEtBQU0sQ0FBQSxXQUFBLENBQVAsR0FBc0IsSUFsQnRCLENBQUE7QUFtQkEsYUFBTyxJQUFQLENBckJTO0lBQUEsQ0FyUFg7QUFBQSxJQThRQSxXQUFBLEVBQWEsU0FBQSxHQUFBO0FBRVgsVUFBQSxrTEFBQTtBQUFBO0FBQUE7V0FBQSxZQUFBOzBCQUFBO0FBRUUsUUFBQSxJQUFHLElBQUksQ0FBQyxlQUFMLEtBQXdCLFdBQTNCO0FBQ0UsVUFBQSxTQUFBLEdBQVksSUFBSSxDQUFDLFdBQWpCLENBQUE7QUFBQSxVQUNBLFNBQUEsR0FBWTs7QUFBQztBQUFBO2lCQUFBLDRDQUFBOzRCQUFBO0FBQUEsNkJBQUEsSUFBQyxDQUFBLGNBQUQsQ0FBZ0IsQ0FBaEIsRUFBQSxDQUFBO0FBQUE7O3VCQUFELENBQ1YsQ0FBQyxNQURTLENBQ0YsT0FERSxDQURaLENBQUE7QUFBQSxVQUtBLFFBQUEsR0FBVyxJQUFDLENBQUEsS0FBTSxDQUFBLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBWixDQUxsQixDQUFBO0FBQUEsVUFNQSxJQUFJLENBQUMsV0FBTCxHQUFtQixRQUFRLENBQUMsV0FONUIsQ0FBQTtBQUFBLFVBT0EsSUFBSSxDQUFDLGVBQUwsR0FBdUIsUUFBUSxDQUFDLGVBUGhDLENBQUE7QUFBQSxVQVFBLElBQUksQ0FBQyxXQUFMLEdBQW1CLFFBQVEsQ0FBQyxXQVI1QixDQUFBO0FBQUEsVUFTQSxJQUFJLENBQUMsYUFBTCxHQUFxQixTQUFTLENBQUMsTUFBVixDQUFpQixRQUFRLENBQUMsYUFBMUIsQ0FUckIsQ0FBQTs7WUFVQSxJQUFJLENBQUMsY0FBZSxRQUFRLENBQUM7V0FWN0I7QUFBQSxVQVdBLElBQUksQ0FBQyxJQUFMLEdBQVksUUFBUSxDQUFDLElBWHJCLENBQUE7QUFBQSxVQVlBLElBQUksQ0FBQyxVQUFMLEdBQWtCLFFBQVEsQ0FBQyxVQVozQixDQURGO1NBQUEsTUFnQkssSUFBRyxJQUFJLENBQUMsZUFBTCxLQUF3QixPQUEzQjtBQUNILFVBQUEsU0FBQSxHQUFZLElBQUksQ0FBQyxXQUFqQixDQUFBO0FBQUEsVUFHQSxRQUFBLEdBQVcsSUFBQyxDQUFBLEtBQU0sQ0FBQSxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQVosQ0FIbEIsQ0FBQTtBQUFBLFVBSUEsSUFBSSxDQUFDLFdBQUwsR0FBbUIsUUFBUSxDQUFDLFdBSjVCLENBQUE7QUFBQSxVQUtBLElBQUksQ0FBQyxlQUFMLEdBQXVCLFFBQVEsQ0FBQyxlQUxoQyxDQURHO1NBQUEsTUFTQSxJQUFHLElBQUksQ0FBQyxlQUFMLEtBQXdCLE9BQTNCO0FBQ0gsVUFBQSxVQUFBLEdBQWEsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFmLENBQXFCLEdBQXJCLENBQWIsQ0FBQTtBQUFBLFVBQ0EsSUFBSSxDQUFDLGVBQUwsR0FBdUIsYUFEdkIsQ0FBQTtBQUVBLGVBQUEsaURBQUE7K0JBQUE7QUFDRSxZQUFBLFVBQUEsR0FBYSxJQUFDLENBQUEsS0FBTSxDQUFBLENBQUEsQ0FBcEIsQ0FBQTtBQUNBLFlBQUEsSUFBbUQsVUFBbkQ7QUFBQSxjQUFBLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBakIsQ0FBc0IsVUFBVSxDQUFDLFdBQVksQ0FBQSxDQUFBLENBQTdDLENBQUEsQ0FBQTthQUZGO0FBQUEsV0FIRztTQXpCTDtBQW1DQTtBQUFBLGFBQUEsOENBQUE7NEJBQUE7QUFDRSxVQUFBLElBQUcsS0FBSyxDQUFDLFNBQU4sS0FBbUIsT0FBdEI7QUFDRSxZQUFBLFFBQUEsR0FBVyxJQUFDLENBQUEsS0FBTSxDQUFBLEtBQUssQ0FBQyxHQUFOLENBQWxCLENBQUE7QUFBQSxZQUNBLElBQUksQ0FBQyxXQUFMLEdBQW1CLFFBQVEsQ0FBQyxXQUQ1QixDQUFBO0FBRUEsa0JBSEY7V0FERjtBQUFBLFNBbkNBO0FBQUEsUUEwQ0EsTUFBQTs7QUFBVTtBQUFBO2VBQUEsOENBQUE7NkJBQUE7Z0JBQTZDLElBQUksQ0FBQztBQUFsRCw2QkFBQSxJQUFJLENBQUMsSUFBTDthQUFBO0FBQUE7O1lBMUNWLENBQUE7QUFBQSxRQTJDQSxVQUFBLEdBQWEsRUEzQ2IsQ0FBQTtBQTRDQTtBQUFBLGFBQUEsOENBQUE7MkJBQUE7QUFDRSxVQUFBLElBQUcsSUFBSSxDQUFDLEdBQVI7QUFDRSxZQUFBLFVBQUEsR0FBYSxVQUFVLENBQUMsTUFBWCxDQUFrQixJQUFDLENBQUEsZUFBZ0IsQ0FBQSxJQUFJLENBQUMsR0FBTCxDQUFuQyxDQUFiLENBREY7V0FBQSxNQUFBO0FBR0UsWUFBQSxVQUFVLENBQUMsSUFBWCxDQUFnQixJQUFoQixDQUFBLENBSEY7V0FERjtBQUFBLFNBNUNBO0FBQUEsc0JBaURBLElBQUksQ0FBQyxhQUFMLEdBQXFCLFdBakRyQixDQUZGO0FBQUE7c0JBRlc7SUFBQSxDQTlRYjtHQWhDRixDQUFBO0FBQUEiCn0=

//# sourceURL=/home/shane/.atom/packages/autocomplete-xml/lib/xsdParser.coffee
