(function() {
  var Snippers, path;

  path = require('path');

  module.exports = Snippers = (function() {
    Snippers.snipperNames = ['coffee', 'default'];

    Snippers.prototype.snippers = new Map;

    function Snippers() {
      this.constructor.snipperNames.forEach((function(_this) {
        return function(name) {
          var Snipper, extension, snipper, _i, _len, _ref, _results;
          Snipper = require("./" + name);
          snipper = new Snipper;
          _ref = snipper.extensions;
          _results = [];
          for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            extension = _ref[_i];
            _results.push(_this.snippers.set(extension, snipper));
          }
          return _results;
        };
      })(this));
    }

    Snippers.prototype.generate = function(tag) {
      var fileExtension, filePath, snipper;
      filePath = tag.file;
      fileExtension = path.extname(filePath);
      fileExtension = fileExtension.substr(1);
      snipper = this.getSnipper({
        extension: fileExtension
      });
      if (!snipper) {
        return;
      }
      return snipper.generate(tag);
    };

    Snippers.prototype.getSnipper = function(_arg) {
      var extension;
      extension = _arg.extension;
      return this.snippers.get(extension);
    };

    return Snippers;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvYXV0b2NvbXBsZXRlLWN0YWdzL2xpYi9zbmlwcGVycy9pbmRleC5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLE1BQUEsY0FBQTs7QUFBQSxFQUFBLElBQUEsR0FBTyxPQUFBLENBQVEsTUFBUixDQUFQLENBQUE7O0FBQUEsRUFFQSxNQUFNLENBQUMsT0FBUCxHQUNNO0FBRUosSUFBQSxRQUFDLENBQUEsWUFBRCxHQUFnQixDQUNkLFFBRGMsRUFFZCxTQUZjLENBQWhCLENBQUE7O0FBQUEsdUJBS0EsUUFBQSxHQUFVLEdBQUEsQ0FBQSxHQUxWLENBQUE7O0FBT2EsSUFBQSxrQkFBQSxHQUFBO0FBQ1gsTUFBQSxJQUFDLENBQUEsV0FBVyxDQUFDLFlBQVksQ0FBQyxPQUExQixDQUFrQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxJQUFELEdBQUE7QUFDaEMsY0FBQSxxREFBQTtBQUFBLFVBQUEsT0FBQSxHQUFVLE9BQUEsQ0FBUyxJQUFBLEdBQUksSUFBYixDQUFWLENBQUE7QUFBQSxVQUNBLE9BQUEsR0FBVSxHQUFBLENBQUEsT0FEVixDQUFBO0FBRUE7QUFBQTtlQUFBLDJDQUFBO2lDQUFBO0FBQ0UsMEJBQUEsS0FBQyxDQUFBLFFBQVEsQ0FBQyxHQUFWLENBQWMsU0FBZCxFQUF5QixPQUF6QixFQUFBLENBREY7QUFBQTswQkFIZ0M7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFsQyxDQUFBLENBRFc7SUFBQSxDQVBiOztBQUFBLHVCQWVBLFFBQUEsR0FBVSxTQUFDLEdBQUQsR0FBQTtBQUNSLFVBQUEsZ0NBQUE7QUFBQSxNQUFPLFdBQVksSUFBbEIsSUFBRCxDQUFBO0FBQUEsTUFFQSxhQUFBLEdBQWdCLElBQUksQ0FBQyxPQUFMLENBQWEsUUFBYixDQUZoQixDQUFBO0FBQUEsTUFHQSxhQUFBLEdBQWdCLGFBQWEsQ0FBQyxNQUFkLENBQXFCLENBQXJCLENBSGhCLENBQUE7QUFBQSxNQUtBLE9BQUEsR0FBVSxJQUFDLENBQUEsVUFBRCxDQUFZO0FBQUEsUUFBQyxTQUFBLEVBQVcsYUFBWjtPQUFaLENBTFYsQ0FBQTtBQU1BLE1BQUEsSUFBQSxDQUFBLE9BQUE7QUFBQSxjQUFBLENBQUE7T0FOQTthQVFBLE9BQU8sQ0FBQyxRQUFSLENBQWlCLEdBQWpCLEVBVFE7SUFBQSxDQWZWLENBQUE7O0FBQUEsdUJBMEJBLFVBQUEsR0FBWSxTQUFDLElBQUQsR0FBQTtBQUNWLFVBQUEsU0FBQTtBQUFBLE1BRFksWUFBRCxLQUFDLFNBQ1osQ0FBQTthQUFBLElBQUMsQ0FBQSxRQUFRLENBQUMsR0FBVixDQUFjLFNBQWQsRUFEVTtJQUFBLENBMUJaLENBQUE7O29CQUFBOztNQUxGLENBQUE7QUFBQSIKfQ==

//# sourceURL=/home/shane/.atom/packages/autocomplete-ctags/lib/snippers/index.coffee
