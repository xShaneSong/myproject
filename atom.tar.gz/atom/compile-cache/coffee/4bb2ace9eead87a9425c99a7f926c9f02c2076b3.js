(function() {
  var Snipper;

  module.exports = Snipper = (function() {
    function Snipper() {}

    Snipper.prototype.extensions = [];

    Snipper.prototype.generate = function(tag) {
      return null;
    };

    return Snipper;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvYXV0b2NvbXBsZXRlLWN0YWdzL2xpYi9zbmlwcGVycy9zbmlwcGVyLmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSxPQUFBOztBQUFBLEVBQUEsTUFBTSxDQUFDLE9BQVAsR0FDTTt5QkFFSjs7QUFBQSxzQkFBQSxVQUFBLEdBQVksRUFBWixDQUFBOztBQUFBLHNCQUVBLFFBQUEsR0FBVSxTQUFDLEdBQUQsR0FBQTthQUNSLEtBRFE7SUFBQSxDQUZWLENBQUE7O21CQUFBOztNQUhGLENBQUE7QUFBQSIKfQ==

//# sourceURL=/home/shane/.atom/packages/autocomplete-ctags/lib/snippers/snipper.coffee
