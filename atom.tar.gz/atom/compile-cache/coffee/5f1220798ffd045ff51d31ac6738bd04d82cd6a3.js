(function() {
  var CompositeDisposable, Emitter, ScriptInputView, ScriptOptionsView, View, _ref,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  _ref = require('atom'), CompositeDisposable = _ref.CompositeDisposable, Emitter = _ref.Emitter;

  View = require('atom-space-pen-views').View;

  ScriptInputView = require('./script-input-view');

  module.exports = ScriptOptionsView = (function(_super) {
    __extends(ScriptOptionsView, _super);

    function ScriptOptionsView() {
      return ScriptOptionsView.__super__.constructor.apply(this, arguments);
    }

    ScriptOptionsView.content = function() {
      return this.div({
        "class": 'options-view'
      }, (function(_this) {
        return function() {
          _this.div({
            "class": 'panel-heading'
          }, 'Configure Run Options');
          _this.table(function() {
            _this.tr(function() {
              _this.td({
                "class": 'first'
              }, function() {
                return _this.label('Current Working Directory:');
              });
              return _this.td({
                "class": 'second'
              }, function() {
                return _this.tag('atom-text-editor', {
                  mini: '',
                  "class": 'editor mini',
                  outlet: 'inputCwd'
                });
              });
            });
            _this.tr(function() {
              _this.td(function() {
                return _this.label('Command');
              });
              return _this.td(function() {
                return _this.tag('atom-text-editor', {
                  mini: '',
                  "class": 'editor mini',
                  outlet: 'inputCommand'
                });
              });
            });
            _this.tr(function() {
              _this.td(function() {
                return _this.label('Command Arguments:');
              });
              return _this.td(function() {
                return _this.tag('atom-text-editor', {
                  mini: '',
                  "class": 'editor mini',
                  outlet: 'inputCommandArgs'
                });
              });
            });
            _this.tr(function() {
              _this.td(function() {
                return _this.label('Program Arguments:');
              });
              return _this.td(function() {
                return _this.tag('atom-text-editor', {
                  mini: '',
                  "class": 'editor mini',
                  outlet: 'inputScriptArgs'
                });
              });
            });
            return _this.tr(function() {
              _this.td(function() {
                return _this.label('Environment Variables:');
              });
              return _this.td(function() {
                return _this.tag('atom-text-editor', {
                  mini: '',
                  "class": 'editor mini',
                  outlet: 'inputEnv'
                });
              });
            });
          });
          return _this.div({
            "class": 'block buttons'
          }, function() {
            var css;
            css = 'btn inline-block-tight';
            _this.button({
              "class": "btn " + css + " cancel",
              outlet: 'buttonCancel',
              click: 'close'
            }, function() {
              return _this.span({
                "class": 'icon icon-x'
              }, 'Cancel');
            });
            return _this.span({
              "class": 'right-buttons'
            }, function() {
              _this.button({
                "class": "btn " + css + " save-profile",
                outlet: 'buttonSaveProfile',
                click: 'saveProfile'
              }, function() {
                return _this.span({
                  "class": 'icon icon-file-text'
                }, 'Save as profile');
              });
              return _this.button({
                "class": "btn " + css + " run",
                outlet: 'buttonRun',
                click: 'run'
              }, function() {
                return _this.span({
                  "class": 'icon icon-playback-play'
                }, 'Run');
              });
            });
          });
        };
      })(this));
    };

    ScriptOptionsView.prototype.initialize = function(runOptions) {
      this.runOptions = runOptions;
      this.emitter = new Emitter;
      this.subscriptions = new CompositeDisposable;
      this.subscriptions.add(atom.commands.add('atom-workspace', {
        'core:cancel': (function(_this) {
          return function() {
            return _this.hide();
          };
        })(this),
        'core:close': (function(_this) {
          return function() {
            return _this.hide();
          };
        })(this),
        'script:close-options': (function(_this) {
          return function() {
            return _this.hide();
          };
        })(this),
        'script:run-options': (function(_this) {
          return function() {
            if (_this.panel.isVisible()) {
              return _this.hide();
            } else {
              return _this.show();
            }
          };
        })(this),
        'script:save-options': (function(_this) {
          return function() {
            return _this.saveOptions();
          };
        })(this)
      }));
      this.find('atom-text-editor').on('keydown', (function(_this) {
        return function(e) {
          var row;
          if (!(e.keyCode === 9 || e.keyCode === 13)) {
            return true;
          }
          switch (e.keyCode) {
            case 9:
              e.preventDefault();
              e.stopPropagation();
              row = _this.find(e.target).parents('tr:first').nextAll('tr:first');
              if (row.length) {
                return row.find('atom-text-editor').focus();
              } else {
                return _this.buttonCancel.focus();
              }
              break;
            case 13:
              return _this.run();
          }
        };
      })(this));
      this.panel = atom.workspace.addModalPanel({
        item: this
      });
      return this.panel.hide();
    };

    ScriptOptionsView.prototype.splitArgs = function(element) {
      var args, argument, item, match, matches, part, regex, regexps, replacer, replaces, split, _i, _j, _k, _len, _len1, _len2, _results;
      args = element.get(0).getModel().getText().trim();
      if (args.indexOf('"') === -1 && args.indexOf("'") === -1) {
        return (function() {
          var _i, _len, _ref1, _results;
          _ref1 = args.split(' ');
          _results = [];
          for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
            item = _ref1[_i];
            if (item !== '') {
              _results.push(item);
            }
          }
          return _results;
        })();
      }
      replaces = {};
      regexps = [/"[^"]*"/ig, /'[^']*'/ig];
      for (_i = 0, _len = regexps.length; _i < _len; _i++) {
        regex = regexps[_i];
        matches = (matches != null ? matches : []).concat((args.match(regex)) || []);
      }
      for (_j = 0, _len1 = matches.length; _j < _len1; _j++) {
        match = matches[_j];
        replaces['`#match' + (Object.keys(replaces).length + 1) + '`'] = match;
      }
      args = (function() {
        var _results;
        _results = [];
        for (match in replaces) {
          part = replaces[match];
          _results.push(args.replace(new RegExp(part, 'g'), match));
        }
        return _results;
      })();
      split = (function() {
        var _k, _len2, _ref1, _results;
        _ref1 = args.split(' ');
        _results = [];
        for (_k = 0, _len2 = _ref1.length; _k < _len2; _k++) {
          item = _ref1[_k];
          if (item !== '') {
            _results.push(item);
          }
        }
        return _results;
      })();
      replacer = function(argument) {
        var replacement;
        argument = (function() {
          var _results;
          _results = [];
          for (match in replaces) {
            replacement = replaces[match];
            _results.push(argument.replace(match, replacement));
          }
          return _results;
        })();
        return argument;
      };
      _results = [];
      for (_k = 0, _len2 = split.length; _k < _len2; _k++) {
        argument = split[_k];
        _results.push(replacer(argument).replace(/"|'/g, ''));
      }
      return _results;
    };

    ScriptOptionsView.prototype.getOptions = function() {
      return {
        workingDirectory: this.inputCwd.get(0).getModel().getText(),
        cmd: this.inputCommand.get(0).getModel().getText(),
        cmdArgs: this.splitArgs(this.inputCommandArgs),
        env: this.inputEnv.get(0).getModel().getText(),
        scriptArgs: this.splitArgs(this.inputScriptArgs)
      };
    };

    ScriptOptionsView.prototype.saveOptions = function() {
      var key, value, _ref1, _results;
      _ref1 = this.getOptions();
      _results = [];
      for (key in _ref1) {
        value = _ref1[key];
        _results.push(this.runOptions[key] = value);
      }
      return _results;
    };

    ScriptOptionsView.prototype.onProfileSave = function(callback) {
      return this.emitter.on('on-profile-save', callback);
    };

    ScriptOptionsView.prototype.saveProfile = function() {
      var inputView, options;
      this.hide();
      options = this.getOptions();
      inputView = new ScriptInputView({
        caption: 'Enter profile name:'
      });
      inputView.onCancel((function(_this) {
        return function() {
          return _this.show();
        };
      })(this));
      inputView.onConfirm((function(_this) {
        return function(profileName) {
          var editor, _i, _len, _ref1;
          if (!profileName) {
            return;
          }
          _ref1 = _this.find('atom-text-editor');
          for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
            editor = _ref1[_i];
            editor.getModel().setText('');
          }
          _this.saveOptions();
          return _this.emitter.emit('on-profile-save', {
            name: profileName,
            options: options
          });
        };
      })(this));
      return inputView.show();
    };

    ScriptOptionsView.prototype.close = function() {
      return this.hide();
    };

    ScriptOptionsView.prototype.destroy = function() {
      var _ref1;
      return (_ref1 = this.subscriptions) != null ? _ref1.dispose() : void 0;
    };

    ScriptOptionsView.prototype.show = function() {
      this.panel.show();
      return this.inputCwd.focus();
    };

    ScriptOptionsView.prototype.hide = function() {
      this.panel.hide();
      return atom.workspace.getActivePane().activate();
    };

    ScriptOptionsView.prototype.run = function() {
      this.saveOptions();
      this.hide();
      return atom.commands.dispatch(this.workspaceView(), 'script:run');
    };

    ScriptOptionsView.prototype.workspaceView = function() {
      return atom.views.getView(atom.workspace);
    };

    return ScriptOptionsView;

  })(View);

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvc2NyaXB0L2xpYi9zY3JpcHQtb3B0aW9ucy12aWV3LmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSw0RUFBQTtJQUFBO21TQUFBOztBQUFBLEVBQUEsT0FBaUMsT0FBQSxDQUFRLE1BQVIsQ0FBakMsRUFBQywyQkFBQSxtQkFBRCxFQUFzQixlQUFBLE9BQXRCLENBQUE7O0FBQUEsRUFDQyxPQUFRLE9BQUEsQ0FBUSxzQkFBUixFQUFSLElBREQsQ0FBQTs7QUFBQSxFQUVBLGVBQUEsR0FBa0IsT0FBQSxDQUFRLHFCQUFSLENBRmxCLENBQUE7O0FBQUEsRUFJQSxNQUFNLENBQUMsT0FBUCxHQUNNO0FBRUosd0NBQUEsQ0FBQTs7OztLQUFBOztBQUFBLElBQUEsaUJBQUMsQ0FBQSxPQUFELEdBQVUsU0FBQSxHQUFBO2FBQ1IsSUFBQyxDQUFBLEdBQUQsQ0FBSztBQUFBLFFBQUEsT0FBQSxFQUFPLGNBQVA7T0FBTCxFQUE0QixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQSxHQUFBO0FBQzFCLFVBQUEsS0FBQyxDQUFBLEdBQUQsQ0FBSztBQUFBLFlBQUEsT0FBQSxFQUFPLGVBQVA7V0FBTCxFQUE2Qix1QkFBN0IsQ0FBQSxDQUFBO0FBQUEsVUFDQSxLQUFDLENBQUEsS0FBRCxDQUFPLFNBQUEsR0FBQTtBQUNMLFlBQUEsS0FBQyxDQUFBLEVBQUQsQ0FBSSxTQUFBLEdBQUE7QUFDRixjQUFBLEtBQUMsQ0FBQSxFQUFELENBQUk7QUFBQSxnQkFBQSxPQUFBLEVBQU8sT0FBUDtlQUFKLEVBQW9CLFNBQUEsR0FBQTt1QkFBRyxLQUFDLENBQUEsS0FBRCxDQUFPLDRCQUFQLEVBQUg7Y0FBQSxDQUFwQixDQUFBLENBQUE7cUJBQ0EsS0FBQyxDQUFBLEVBQUQsQ0FBSTtBQUFBLGdCQUFBLE9BQUEsRUFBTyxRQUFQO2VBQUosRUFBcUIsU0FBQSxHQUFBO3VCQUNuQixLQUFDLENBQUEsR0FBRCxDQUFLLGtCQUFMLEVBQXlCO0FBQUEsa0JBQUEsSUFBQSxFQUFNLEVBQU47QUFBQSxrQkFBVSxPQUFBLEVBQU8sYUFBakI7QUFBQSxrQkFBZ0MsTUFBQSxFQUFRLFVBQXhDO2lCQUF6QixFQURtQjtjQUFBLENBQXJCLEVBRkU7WUFBQSxDQUFKLENBQUEsQ0FBQTtBQUFBLFlBSUEsS0FBQyxDQUFBLEVBQUQsQ0FBSSxTQUFBLEdBQUE7QUFDRixjQUFBLEtBQUMsQ0FBQSxFQUFELENBQUksU0FBQSxHQUFBO3VCQUFHLEtBQUMsQ0FBQSxLQUFELENBQU8sU0FBUCxFQUFIO2NBQUEsQ0FBSixDQUFBLENBQUE7cUJBQ0EsS0FBQyxDQUFBLEVBQUQsQ0FBSSxTQUFBLEdBQUE7dUJBQ0YsS0FBQyxDQUFBLEdBQUQsQ0FBSyxrQkFBTCxFQUF5QjtBQUFBLGtCQUFBLElBQUEsRUFBTSxFQUFOO0FBQUEsa0JBQVUsT0FBQSxFQUFPLGFBQWpCO0FBQUEsa0JBQWdDLE1BQUEsRUFBUSxjQUF4QztpQkFBekIsRUFERTtjQUFBLENBQUosRUFGRTtZQUFBLENBQUosQ0FKQSxDQUFBO0FBQUEsWUFRQSxLQUFDLENBQUEsRUFBRCxDQUFJLFNBQUEsR0FBQTtBQUNGLGNBQUEsS0FBQyxDQUFBLEVBQUQsQ0FBSSxTQUFBLEdBQUE7dUJBQUcsS0FBQyxDQUFBLEtBQUQsQ0FBTyxvQkFBUCxFQUFIO2NBQUEsQ0FBSixDQUFBLENBQUE7cUJBQ0EsS0FBQyxDQUFBLEVBQUQsQ0FBSSxTQUFBLEdBQUE7dUJBQ0YsS0FBQyxDQUFBLEdBQUQsQ0FBSyxrQkFBTCxFQUF5QjtBQUFBLGtCQUFBLElBQUEsRUFBTSxFQUFOO0FBQUEsa0JBQVUsT0FBQSxFQUFPLGFBQWpCO0FBQUEsa0JBQWdDLE1BQUEsRUFBUSxrQkFBeEM7aUJBQXpCLEVBREU7Y0FBQSxDQUFKLEVBRkU7WUFBQSxDQUFKLENBUkEsQ0FBQTtBQUFBLFlBWUEsS0FBQyxDQUFBLEVBQUQsQ0FBSSxTQUFBLEdBQUE7QUFDRixjQUFBLEtBQUMsQ0FBQSxFQUFELENBQUksU0FBQSxHQUFBO3VCQUFHLEtBQUMsQ0FBQSxLQUFELENBQU8sb0JBQVAsRUFBSDtjQUFBLENBQUosQ0FBQSxDQUFBO3FCQUNBLEtBQUMsQ0FBQSxFQUFELENBQUksU0FBQSxHQUFBO3VCQUNGLEtBQUMsQ0FBQSxHQUFELENBQUssa0JBQUwsRUFBeUI7QUFBQSxrQkFBQSxJQUFBLEVBQU0sRUFBTjtBQUFBLGtCQUFVLE9BQUEsRUFBTyxhQUFqQjtBQUFBLGtCQUFnQyxNQUFBLEVBQVEsaUJBQXhDO2lCQUF6QixFQURFO2NBQUEsQ0FBSixFQUZFO1lBQUEsQ0FBSixDQVpBLENBQUE7bUJBZ0JBLEtBQUMsQ0FBQSxFQUFELENBQUksU0FBQSxHQUFBO0FBQ0YsY0FBQSxLQUFDLENBQUEsRUFBRCxDQUFJLFNBQUEsR0FBQTt1QkFBRyxLQUFDLENBQUEsS0FBRCxDQUFPLHdCQUFQLEVBQUg7Y0FBQSxDQUFKLENBQUEsQ0FBQTtxQkFDQSxLQUFDLENBQUEsRUFBRCxDQUFJLFNBQUEsR0FBQTt1QkFDRixLQUFDLENBQUEsR0FBRCxDQUFLLGtCQUFMLEVBQXlCO0FBQUEsa0JBQUEsSUFBQSxFQUFNLEVBQU47QUFBQSxrQkFBVSxPQUFBLEVBQU8sYUFBakI7QUFBQSxrQkFBZ0MsTUFBQSxFQUFRLFVBQXhDO2lCQUF6QixFQURFO2NBQUEsQ0FBSixFQUZFO1lBQUEsQ0FBSixFQWpCSztVQUFBLENBQVAsQ0FEQSxDQUFBO2lCQXNCQSxLQUFDLENBQUEsR0FBRCxDQUFLO0FBQUEsWUFBQSxPQUFBLEVBQU8sZUFBUDtXQUFMLEVBQTZCLFNBQUEsR0FBQTtBQUMzQixnQkFBQSxHQUFBO0FBQUEsWUFBQSxHQUFBLEdBQU0sd0JBQU4sQ0FBQTtBQUFBLFlBQ0EsS0FBQyxDQUFBLE1BQUQsQ0FBUTtBQUFBLGNBQUEsT0FBQSxFQUFRLE1BQUEsR0FBTSxHQUFOLEdBQVUsU0FBbEI7QUFBQSxjQUE0QixNQUFBLEVBQVEsY0FBcEM7QUFBQSxjQUFvRCxLQUFBLEVBQU8sT0FBM0Q7YUFBUixFQUE0RSxTQUFBLEdBQUE7cUJBQzFFLEtBQUMsQ0FBQSxJQUFELENBQU07QUFBQSxnQkFBQSxPQUFBLEVBQU8sYUFBUDtlQUFOLEVBQTRCLFFBQTVCLEVBRDBFO1lBQUEsQ0FBNUUsQ0FEQSxDQUFBO21CQUdBLEtBQUMsQ0FBQSxJQUFELENBQU07QUFBQSxjQUFBLE9BQUEsRUFBTyxlQUFQO2FBQU4sRUFBOEIsU0FBQSxHQUFBO0FBQzVCLGNBQUEsS0FBQyxDQUFBLE1BQUQsQ0FBUTtBQUFBLGdCQUFBLE9BQUEsRUFBUSxNQUFBLEdBQU0sR0FBTixHQUFVLGVBQWxCO0FBQUEsZ0JBQWtDLE1BQUEsRUFBUSxtQkFBMUM7QUFBQSxnQkFBK0QsS0FBQSxFQUFPLGFBQXRFO2VBQVIsRUFBNkYsU0FBQSxHQUFBO3VCQUMzRixLQUFDLENBQUEsSUFBRCxDQUFNO0FBQUEsa0JBQUEsT0FBQSxFQUFPLHFCQUFQO2lCQUFOLEVBQW9DLGlCQUFwQyxFQUQyRjtjQUFBLENBQTdGLENBQUEsQ0FBQTtxQkFFQSxLQUFDLENBQUEsTUFBRCxDQUFRO0FBQUEsZ0JBQUEsT0FBQSxFQUFRLE1BQUEsR0FBTSxHQUFOLEdBQVUsTUFBbEI7QUFBQSxnQkFBeUIsTUFBQSxFQUFRLFdBQWpDO0FBQUEsZ0JBQThDLEtBQUEsRUFBTyxLQUFyRDtlQUFSLEVBQW9FLFNBQUEsR0FBQTt1QkFDbEUsS0FBQyxDQUFBLElBQUQsQ0FBTTtBQUFBLGtCQUFBLE9BQUEsRUFBTyx5QkFBUDtpQkFBTixFQUF3QyxLQUF4QyxFQURrRTtjQUFBLENBQXBFLEVBSDRCO1lBQUEsQ0FBOUIsRUFKMkI7VUFBQSxDQUE3QixFQXZCMEI7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE1QixFQURRO0lBQUEsQ0FBVixDQUFBOztBQUFBLGdDQWtDQSxVQUFBLEdBQVksU0FBRSxVQUFGLEdBQUE7QUFDVixNQURXLElBQUMsQ0FBQSxhQUFBLFVBQ1osQ0FBQTtBQUFBLE1BQUEsSUFBQyxDQUFBLE9BQUQsR0FBVyxHQUFBLENBQUEsT0FBWCxDQUFBO0FBQUEsTUFFQSxJQUFDLENBQUEsYUFBRCxHQUFpQixHQUFBLENBQUEsbUJBRmpCLENBQUE7QUFBQSxNQUdBLElBQUMsQ0FBQSxhQUFhLENBQUMsR0FBZixDQUFtQixJQUFJLENBQUMsUUFBUSxDQUFDLEdBQWQsQ0FBa0IsZ0JBQWxCLEVBQ2pCO0FBQUEsUUFBQSxhQUFBLEVBQWUsQ0FBQSxTQUFBLEtBQUEsR0FBQTtpQkFBQSxTQUFBLEdBQUE7bUJBQUcsS0FBQyxDQUFBLElBQUQsQ0FBQSxFQUFIO1VBQUEsRUFBQTtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBZjtBQUFBLFFBQ0EsWUFBQSxFQUFjLENBQUEsU0FBQSxLQUFBLEdBQUE7aUJBQUEsU0FBQSxHQUFBO21CQUFHLEtBQUMsQ0FBQSxJQUFELENBQUEsRUFBSDtVQUFBLEVBQUE7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRGQ7QUFBQSxRQUVBLHNCQUFBLEVBQXdCLENBQUEsU0FBQSxLQUFBLEdBQUE7aUJBQUEsU0FBQSxHQUFBO21CQUFHLEtBQUMsQ0FBQSxJQUFELENBQUEsRUFBSDtVQUFBLEVBQUE7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRnhCO0FBQUEsUUFHQSxvQkFBQSxFQUFzQixDQUFBLFNBQUEsS0FBQSxHQUFBO2lCQUFBLFNBQUEsR0FBQTtBQUFHLFlBQUEsSUFBRyxLQUFDLENBQUEsS0FBSyxDQUFDLFNBQVAsQ0FBQSxDQUFIO3FCQUEyQixLQUFDLENBQUEsSUFBRCxDQUFBLEVBQTNCO2FBQUEsTUFBQTtxQkFBd0MsS0FBQyxDQUFBLElBQUQsQ0FBQSxFQUF4QzthQUFIO1VBQUEsRUFBQTtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FIdEI7QUFBQSxRQUlBLHFCQUFBLEVBQXVCLENBQUEsU0FBQSxLQUFBLEdBQUE7aUJBQUEsU0FBQSxHQUFBO21CQUFHLEtBQUMsQ0FBQSxXQUFELENBQUEsRUFBSDtVQUFBLEVBQUE7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBSnZCO09BRGlCLENBQW5CLENBSEEsQ0FBQTtBQUFBLE1BV0EsSUFBQyxDQUFBLElBQUQsQ0FBTSxrQkFBTixDQUF5QixDQUFDLEVBQTFCLENBQTZCLFNBQTdCLEVBQXdDLENBQUEsU0FBQSxLQUFBLEdBQUE7ZUFBQSxTQUFDLENBQUQsR0FBQTtBQUN0QyxjQUFBLEdBQUE7QUFBQSxVQUFBLElBQUEsQ0FBQSxDQUFtQixDQUFDLENBQUMsT0FBRixLQUFhLENBQWIsSUFBa0IsQ0FBQyxDQUFDLE9BQUYsS0FBYSxFQUFsRCxDQUFBO0FBQUEsbUJBQU8sSUFBUCxDQUFBO1dBQUE7QUFFQSxrQkFBTyxDQUFDLENBQUMsT0FBVDtBQUFBLGlCQUNPLENBRFA7QUFFSSxjQUFBLENBQUMsQ0FBQyxjQUFGLENBQUEsQ0FBQSxDQUFBO0FBQUEsY0FDQSxDQUFDLENBQUMsZUFBRixDQUFBLENBREEsQ0FBQTtBQUFBLGNBRUEsR0FBQSxHQUFNLEtBQUMsQ0FBQSxJQUFELENBQU0sQ0FBQyxDQUFDLE1BQVIsQ0FBZSxDQUFDLE9BQWhCLENBQXdCLFVBQXhCLENBQW1DLENBQUMsT0FBcEMsQ0FBNEMsVUFBNUMsQ0FGTixDQUFBO0FBR0EsY0FBQSxJQUFHLEdBQUcsQ0FBQyxNQUFQO3VCQUFtQixHQUFHLENBQUMsSUFBSixDQUFTLGtCQUFULENBQTRCLENBQUMsS0FBN0IsQ0FBQSxFQUFuQjtlQUFBLE1BQUE7dUJBQTZELEtBQUMsQ0FBQSxZQUFZLENBQUMsS0FBZCxDQUFBLEVBQTdEO2VBTEo7QUFDTztBQURQLGlCQU9PLEVBUFA7cUJBT2UsS0FBQyxDQUFBLEdBQUQsQ0FBQSxFQVBmO0FBQUEsV0FIc0M7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF4QyxDQVhBLENBQUE7QUFBQSxNQXVCQSxJQUFDLENBQUEsS0FBRCxHQUFTLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBZixDQUE2QjtBQUFBLFFBQUEsSUFBQSxFQUFNLElBQU47T0FBN0IsQ0F2QlQsQ0FBQTthQXdCQSxJQUFDLENBQUEsS0FBSyxDQUFDLElBQVAsQ0FBQSxFQXpCVTtJQUFBLENBbENaLENBQUE7O0FBQUEsZ0NBNkRBLFNBQUEsR0FBVyxTQUFDLE9BQUQsR0FBQTtBQUNULFVBQUEsK0hBQUE7QUFBQSxNQUFBLElBQUEsR0FBTyxPQUFPLENBQUMsR0FBUixDQUFZLENBQVosQ0FBYyxDQUFDLFFBQWYsQ0FBQSxDQUF5QixDQUFDLE9BQTFCLENBQUEsQ0FBbUMsQ0FBQyxJQUFwQyxDQUFBLENBQVAsQ0FBQTtBQUVBLE1BQUEsSUFBRyxJQUFJLENBQUMsT0FBTCxDQUFhLEdBQWIsQ0FBQSxLQUFxQixDQUFBLENBQXJCLElBQTRCLElBQUksQ0FBQyxPQUFMLENBQWEsR0FBYixDQUFBLEtBQXFCLENBQUEsQ0FBcEQ7QUFFRTs7QUFBUTtBQUFBO2VBQUEsNENBQUE7NkJBQUE7Z0JBQXFDLElBQUEsS0FBVTtBQUEvQyw0QkFBQSxLQUFBO2FBQUE7QUFBQTs7WUFBUixDQUZGO09BRkE7QUFBQSxNQU1BLFFBQUEsR0FBVyxFQU5YLENBQUE7QUFBQSxNQVFBLE9BQUEsR0FBVSxDQUFDLFdBQUQsRUFBYyxXQUFkLENBUlYsQ0FBQTtBQVdBLFdBQUEsOENBQUE7NEJBQUE7QUFBQSxRQUFBLE9BQUEsR0FBVSxDQUFJLGVBQUgsR0FBaUIsT0FBakIsR0FBOEIsRUFBL0IsQ0FBa0MsQ0FBQyxNQUFuQyxDQUEwQyxDQUFDLElBQUksQ0FBQyxLQUFMLENBQVcsS0FBWCxDQUFELENBQUEsSUFBc0IsRUFBaEUsQ0FBVixDQUFBO0FBQUEsT0FYQTtBQWNBLFdBQUEsZ0RBQUE7NEJBQUE7QUFBQSxRQUFDLFFBQVMsQ0FBQSxTQUFBLEdBQVksQ0FBQyxNQUFNLENBQUMsSUFBUCxDQUFZLFFBQVosQ0FBcUIsQ0FBQyxNQUF0QixHQUErQixDQUFoQyxDQUFaLEdBQWlELEdBQWpELENBQVQsR0FBaUUsS0FBbEUsQ0FBQTtBQUFBLE9BZEE7QUFBQSxNQWlCQSxJQUFBOztBQUFRO2FBQUEsaUJBQUE7aUNBQUE7QUFBQSx3QkFBQSxJQUFJLENBQUMsT0FBTCxDQUFpQixJQUFBLE1BQUEsQ0FBTyxJQUFQLEVBQWEsR0FBYixDQUFqQixFQUFvQyxLQUFwQyxFQUFBLENBQUE7QUFBQTs7VUFqQlIsQ0FBQTtBQUFBLE1Ba0JBLEtBQUE7O0FBQVM7QUFBQTthQUFBLDhDQUFBOzJCQUFBO2NBQXFDLElBQUEsS0FBVTtBQUEvQywwQkFBQSxLQUFBO1dBQUE7QUFBQTs7VUFsQlQsQ0FBQTtBQUFBLE1Bb0JBLFFBQUEsR0FBVyxTQUFDLFFBQUQsR0FBQTtBQUNULFlBQUEsV0FBQTtBQUFBLFFBQUEsUUFBQTs7QUFBWTtlQUFBLGlCQUFBOzBDQUFBO0FBQUEsMEJBQUEsUUFBUSxDQUFDLE9BQVQsQ0FBaUIsS0FBakIsRUFBd0IsV0FBeEIsRUFBQSxDQUFBO0FBQUE7O1lBQVosQ0FBQTtlQUNBLFNBRlM7TUFBQSxDQXBCWCxDQUFBO0FBeUJDO1dBQUEsOENBQUE7NkJBQUE7QUFBQSxzQkFBQSxRQUFBLENBQVMsUUFBVCxDQUFrQixDQUFDLE9BQW5CLENBQTJCLE1BQTNCLEVBQW1DLEVBQW5DLEVBQUEsQ0FBQTtBQUFBO3NCQTFCUTtJQUFBLENBN0RYLENBQUE7O0FBQUEsZ0NBeUZBLFVBQUEsR0FBWSxTQUFBLEdBQUE7YUFDVjtBQUFBLFFBQUEsZ0JBQUEsRUFBa0IsSUFBQyxDQUFBLFFBQVEsQ0FBQyxHQUFWLENBQWMsQ0FBZCxDQUFnQixDQUFDLFFBQWpCLENBQUEsQ0FBMkIsQ0FBQyxPQUE1QixDQUFBLENBQWxCO0FBQUEsUUFDQSxHQUFBLEVBQUssSUFBQyxDQUFBLFlBQVksQ0FBQyxHQUFkLENBQWtCLENBQWxCLENBQW9CLENBQUMsUUFBckIsQ0FBQSxDQUErQixDQUFDLE9BQWhDLENBQUEsQ0FETDtBQUFBLFFBRUEsT0FBQSxFQUFTLElBQUMsQ0FBQSxTQUFELENBQVcsSUFBQyxDQUFBLGdCQUFaLENBRlQ7QUFBQSxRQUdBLEdBQUEsRUFBSyxJQUFDLENBQUEsUUFBUSxDQUFDLEdBQVYsQ0FBYyxDQUFkLENBQWdCLENBQUMsUUFBakIsQ0FBQSxDQUEyQixDQUFDLE9BQTVCLENBQUEsQ0FITDtBQUFBLFFBSUEsVUFBQSxFQUFZLElBQUMsQ0FBQSxTQUFELENBQVcsSUFBQyxDQUFBLGVBQVosQ0FKWjtRQURVO0lBQUEsQ0F6RlosQ0FBQTs7QUFBQSxnQ0FnR0EsV0FBQSxHQUFhLFNBQUEsR0FBQTtBQUNYLFVBQUEsMkJBQUE7QUFBQTtBQUFBO1dBQUEsWUFBQTsyQkFBQTtBQUFBLHNCQUFBLElBQUMsQ0FBQSxVQUFXLENBQUEsR0FBQSxDQUFaLEdBQW1CLE1BQW5CLENBQUE7QUFBQTtzQkFEVztJQUFBLENBaEdiLENBQUE7O0FBQUEsZ0NBbUdBLGFBQUEsR0FBZSxTQUFDLFFBQUQsR0FBQTthQUFjLElBQUMsQ0FBQSxPQUFPLENBQUMsRUFBVCxDQUFZLGlCQUFaLEVBQStCLFFBQS9CLEVBQWQ7SUFBQSxDQW5HZixDQUFBOztBQUFBLGdDQXNHQSxXQUFBLEdBQWEsU0FBQSxHQUFBO0FBQ1gsVUFBQSxrQkFBQTtBQUFBLE1BQUEsSUFBQyxDQUFBLElBQUQsQ0FBQSxDQUFBLENBQUE7QUFBQSxNQUVBLE9BQUEsR0FBVSxJQUFDLENBQUEsVUFBRCxDQUFBLENBRlYsQ0FBQTtBQUFBLE1BSUEsU0FBQSxHQUFnQixJQUFBLGVBQUEsQ0FBZ0I7QUFBQSxRQUFBLE9BQUEsRUFBUyxxQkFBVDtPQUFoQixDQUpoQixDQUFBO0FBQUEsTUFLQSxTQUFTLENBQUMsUUFBVixDQUFtQixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQSxHQUFBO2lCQUNqQixLQUFDLENBQUEsSUFBRCxDQUFBLEVBRGlCO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBbkIsQ0FMQSxDQUFBO0FBQUEsTUFPQSxTQUFTLENBQUMsU0FBVixDQUFvQixDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxXQUFELEdBQUE7QUFDbEIsY0FBQSx1QkFBQTtBQUFBLFVBQUEsSUFBQSxDQUFBLFdBQUE7QUFBQSxrQkFBQSxDQUFBO1dBQUE7QUFDQTtBQUFBLGVBQUEsNENBQUE7K0JBQUE7QUFBQSxZQUFBLE1BQU0sQ0FBQyxRQUFQLENBQUEsQ0FBaUIsQ0FBQyxPQUFsQixDQUEwQixFQUExQixDQUFBLENBQUE7QUFBQSxXQURBO0FBQUEsVUFJQSxLQUFDLENBQUEsV0FBRCxDQUFBLENBSkEsQ0FBQTtpQkFPQSxLQUFDLENBQUEsT0FBTyxDQUFDLElBQVQsQ0FBYyxpQkFBZCxFQUFpQztBQUFBLFlBQUEsSUFBQSxFQUFNLFdBQU47QUFBQSxZQUFtQixPQUFBLEVBQVMsT0FBNUI7V0FBakMsRUFSa0I7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFwQixDQVBBLENBQUE7YUFpQkEsU0FBUyxDQUFDLElBQVYsQ0FBQSxFQWxCVztJQUFBLENBdEdiLENBQUE7O0FBQUEsZ0NBMEhBLEtBQUEsR0FBTyxTQUFBLEdBQUE7YUFDTCxJQUFDLENBQUEsSUFBRCxDQUFBLEVBREs7SUFBQSxDQTFIUCxDQUFBOztBQUFBLGdDQTZIQSxPQUFBLEdBQVMsU0FBQSxHQUFBO0FBQ1AsVUFBQSxLQUFBO3lEQUFjLENBQUUsT0FBaEIsQ0FBQSxXQURPO0lBQUEsQ0E3SFQsQ0FBQTs7QUFBQSxnQ0FnSUEsSUFBQSxHQUFNLFNBQUEsR0FBQTtBQUNKLE1BQUEsSUFBQyxDQUFBLEtBQUssQ0FBQyxJQUFQLENBQUEsQ0FBQSxDQUFBO2FBQ0EsSUFBQyxDQUFBLFFBQVEsQ0FBQyxLQUFWLENBQUEsRUFGSTtJQUFBLENBaElOLENBQUE7O0FBQUEsZ0NBb0lBLElBQUEsR0FBTSxTQUFBLEdBQUE7QUFDSixNQUFBLElBQUMsQ0FBQSxLQUFLLENBQUMsSUFBUCxDQUFBLENBQUEsQ0FBQTthQUNBLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBZixDQUFBLENBQThCLENBQUMsUUFBL0IsQ0FBQSxFQUZJO0lBQUEsQ0FwSU4sQ0FBQTs7QUFBQSxnQ0F3SUEsR0FBQSxHQUFLLFNBQUEsR0FBQTtBQUNILE1BQUEsSUFBQyxDQUFBLFdBQUQsQ0FBQSxDQUFBLENBQUE7QUFBQSxNQUNBLElBQUMsQ0FBQSxJQUFELENBQUEsQ0FEQSxDQUFBO2FBRUEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFkLENBQXVCLElBQUMsQ0FBQSxhQUFELENBQUEsQ0FBdkIsRUFBeUMsWUFBekMsRUFIRztJQUFBLENBeElMLENBQUE7O0FBQUEsZ0NBNklBLGFBQUEsR0FBZSxTQUFBLEdBQUE7YUFDYixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQVgsQ0FBbUIsSUFBSSxDQUFDLFNBQXhCLEVBRGE7SUFBQSxDQTdJZixDQUFBOzs2QkFBQTs7S0FGOEIsS0FMaEMsQ0FBQTtBQUFBIgp9

//# sourceURL=/home/shane/.atom/packages/script/lib/script-options-view.coffee
