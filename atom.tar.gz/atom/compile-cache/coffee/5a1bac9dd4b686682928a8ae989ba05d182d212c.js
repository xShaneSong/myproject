(function() {
  var CoffeeSnipper, Snipper,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Snipper = require('./snipper');

  module.exports = CoffeeSnipper = (function(_super) {
    __extends(CoffeeSnipper, _super);

    function CoffeeSnipper() {
      return CoffeeSnipper.__super__.constructor.apply(this, arguments);
    }

    CoffeeSnipper.prototype.extensions = ['coffee'];

    CoffeeSnipper.prototype.generate = function(tag) {
      var args, argsString, matches, snippetCount;
      if (tag.kind !== 'f') {
        return null;
      }
      argsString = '';
      matches = tag.pattern.match(/\(([^\(\)]*)\)/);
      if (matches) {
        argsString = matches[1].trim();
      }
      snippetCount = 1;
      args = [];
      if (argsString.match(/^[\{\[].+[\]\}]$/)) {
        argsString = argsString.replace(/([\{\}])/g, '\\$1');
        args = ["${" + (snippetCount++) + ":" + argsString + "}"];
      } else if (argsString.length > 0) {
        args = argsString.split(',').map(function(arg) {
          arg = arg.split('=', 1)[0];
          return "${" + (snippetCount++) + ":" + (arg.trim()) + "}";
        });
      }
      return "" + tag.name + "(" + (args.join(', ')) + ")${" + snippetCount + "}";
    };

    return CoffeeSnipper;

  })(Snipper);

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvYXV0b2NvbXBsZXRlLWN0YWdzL2xpYi9zbmlwcGVycy9jb2ZmZWUuY29mZmVlIgogIF0sCiAgIm5hbWVzIjogW10sCiAgIm1hcHBpbmdzIjogIkFBQUE7QUFBQSxNQUFBLHNCQUFBO0lBQUE7bVNBQUE7O0FBQUEsRUFBQSxPQUFBLEdBQVUsT0FBQSxDQUFRLFdBQVIsQ0FBVixDQUFBOztBQUFBLEVBRUEsTUFBTSxDQUFDLE9BQVAsR0FDTTtBQUVKLG9DQUFBLENBQUE7Ozs7S0FBQTs7QUFBQSw0QkFBQSxVQUFBLEdBQVksQ0FBQyxRQUFELENBQVosQ0FBQTs7QUFBQSw0QkFFQSxRQUFBLEdBQVUsU0FBQyxHQUFELEdBQUE7QUFDUixVQUFBLHVDQUFBO0FBQUEsTUFBQSxJQUFlLEdBQUcsQ0FBQyxJQUFKLEtBQWMsR0FBN0I7QUFBQSxlQUFPLElBQVAsQ0FBQTtPQUFBO0FBQUEsTUFFQSxVQUFBLEdBQWEsRUFGYixDQUFBO0FBQUEsTUFHQSxPQUFBLEdBQVUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFaLENBQWtCLGdCQUFsQixDQUhWLENBQUE7QUFJQSxNQUFBLElBQWtDLE9BQWxDO0FBQUEsUUFBQSxVQUFBLEdBQWEsT0FBUSxDQUFBLENBQUEsQ0FBRSxDQUFDLElBQVgsQ0FBQSxDQUFiLENBQUE7T0FKQTtBQUFBLE1BS0EsWUFBQSxHQUFlLENBTGYsQ0FBQTtBQUFBLE1BTUEsSUFBQSxHQUFPLEVBTlAsQ0FBQTtBQVFBLE1BQUEsSUFBRyxVQUFVLENBQUMsS0FBWCxDQUFpQixrQkFBakIsQ0FBSDtBQUVFLFFBQUEsVUFBQSxHQUFhLFVBQVUsQ0FBQyxPQUFYLENBQW1CLFdBQW5CLEVBQWdDLE1BQWhDLENBQWIsQ0FBQTtBQUFBLFFBQ0EsSUFBQSxHQUFPLENBQUUsSUFBQSxHQUFHLENBQUMsWUFBQSxFQUFELENBQUgsR0FBbUIsR0FBbkIsR0FBc0IsVUFBdEIsR0FBaUMsR0FBbkMsQ0FEUCxDQUZGO09BQUEsTUFJSyxJQUFHLFVBQVUsQ0FBQyxNQUFYLEdBQW9CLENBQXZCO0FBQ0gsUUFBQSxJQUFBLEdBQU8sVUFBVSxDQUFDLEtBQVgsQ0FBaUIsR0FBakIsQ0FBcUIsQ0FBQyxHQUF0QixDQUEwQixTQUFDLEdBQUQsR0FBQTtBQUMvQixVQUFDLE1BQU8sR0FBRyxDQUFDLEtBQUosQ0FBVSxHQUFWLEVBQWUsQ0FBZixJQUFSLENBQUE7aUJBQ0MsSUFBQSxHQUFHLENBQUMsWUFBQSxFQUFELENBQUgsR0FBbUIsR0FBbkIsR0FBcUIsQ0FBQyxHQUFHLENBQUMsSUFBSixDQUFBLENBQUQsQ0FBckIsR0FBaUMsSUFGSDtRQUFBLENBQTFCLENBQVAsQ0FERztPQVpMO2FBa0JBLEVBQUEsR0FBRyxHQUFHLENBQUMsSUFBUCxHQUFZLEdBQVosR0FBYyxDQUFDLElBQUksQ0FBQyxJQUFMLENBQVUsSUFBVixDQUFELENBQWQsR0FBK0IsS0FBL0IsR0FBb0MsWUFBcEMsR0FBaUQsSUFuQnpDO0lBQUEsQ0FGVixDQUFBOzt5QkFBQTs7S0FGMEIsUUFINUIsQ0FBQTtBQUFBIgp9

//# sourceURL=/home/shane/.atom/packages/autocomplete-ctags/lib/snippers/coffee.coffee
