(function() {
  var DefaultSnipper, Snipper,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Snipper = require('./snipper');

  module.exports = DefaultSnipper = (function(_super) {
    __extends(DefaultSnipper, _super);

    function DefaultSnipper() {
      return DefaultSnipper.__super__.constructor.apply(this, arguments);
    }

    DefaultSnipper.prototype.extensions = ['m'];

    DefaultSnipper.prototype.generate = function(tag) {
      var args, argsString, matches, snippetCount;
      if (tag.kind !== 'f') {
        return null;
      }
      argsString = '';
      matches = tag.pattern.match(/\(([^\(\)]*)\)/);
      if (matches) {
        argsString = matches[1].trim();
      }
      snippetCount = 1;
      args = [];
      if (argsString.length > 0) {
        args = argsString.split(',').map(function(arg) {
          arg = arg.split('=', 1)[0];
          return "${" + (snippetCount++) + ":" + (arg.trim()) + "}";
        });
      }
      return "" + tag.name + "(" + (args.join(', ')) + ")${" + snippetCount + "}";
    };

    return DefaultSnipper;

  })(Snipper);

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvYXV0b2NvbXBsZXRlLWN0YWdzL2xpYi9zbmlwcGVycy9kZWZhdWx0LmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSx1QkFBQTtJQUFBO21TQUFBOztBQUFBLEVBQUEsT0FBQSxHQUFVLE9BQUEsQ0FBUSxXQUFSLENBQVYsQ0FBQTs7QUFBQSxFQUVBLE1BQU0sQ0FBQyxPQUFQLEdBQ007QUFFSixxQ0FBQSxDQUFBOzs7O0tBQUE7O0FBQUEsNkJBQUEsVUFBQSxHQUFZLENBQUMsR0FBRCxDQUFaLENBQUE7O0FBQUEsNkJBRUEsUUFBQSxHQUFVLFNBQUMsR0FBRCxHQUFBO0FBQ1IsVUFBQSx1Q0FBQTtBQUFBLE1BQUEsSUFBZSxHQUFHLENBQUMsSUFBSixLQUFjLEdBQTdCO0FBQUEsZUFBTyxJQUFQLENBQUE7T0FBQTtBQUFBLE1BRUEsVUFBQSxHQUFhLEVBRmIsQ0FBQTtBQUFBLE1BR0EsT0FBQSxHQUFVLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBWixDQUFrQixnQkFBbEIsQ0FIVixDQUFBO0FBSUEsTUFBQSxJQUFrQyxPQUFsQztBQUFBLFFBQUEsVUFBQSxHQUFhLE9BQVEsQ0FBQSxDQUFBLENBQUUsQ0FBQyxJQUFYLENBQUEsQ0FBYixDQUFBO09BSkE7QUFBQSxNQUtBLFlBQUEsR0FBZSxDQUxmLENBQUE7QUFBQSxNQU1BLElBQUEsR0FBTyxFQU5QLENBQUE7QUFRQSxNQUFBLElBQUcsVUFBVSxDQUFDLE1BQVgsR0FBb0IsQ0FBdkI7QUFDRSxRQUFBLElBQUEsR0FBTyxVQUFVLENBQUMsS0FBWCxDQUFpQixHQUFqQixDQUFxQixDQUFDLEdBQXRCLENBQTBCLFNBQUMsR0FBRCxHQUFBO0FBQy9CLFVBQUMsTUFBTyxHQUFHLENBQUMsS0FBSixDQUFVLEdBQVYsRUFBZSxDQUFmLElBQVIsQ0FBQTtpQkFDQyxJQUFBLEdBQUcsQ0FBQyxZQUFBLEVBQUQsQ0FBSCxHQUFtQixHQUFuQixHQUFxQixDQUFDLEdBQUcsQ0FBQyxJQUFKLENBQUEsQ0FBRCxDQUFyQixHQUFpQyxJQUZIO1FBQUEsQ0FBMUIsQ0FBUCxDQURGO09BUkE7YUFjQSxFQUFBLEdBQUcsR0FBRyxDQUFDLElBQVAsR0FBWSxHQUFaLEdBQWMsQ0FBQyxJQUFJLENBQUMsSUFBTCxDQUFVLElBQVYsQ0FBRCxDQUFkLEdBQStCLEtBQS9CLEdBQW9DLFlBQXBDLEdBQWlELElBZnpDO0lBQUEsQ0FGVixDQUFBOzswQkFBQTs7S0FGMkIsUUFIN0IsQ0FBQTtBQUFBIgp9

//# sourceURL=/home/shane/.atom/packages/autocomplete-ctags/lib/snippers/default.coffee
