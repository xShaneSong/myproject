(function() {
  var FormatterClang;

  module.exports = FormatterClang = {
    config: {
      executablePath: {
        title: 'Path to the exectuable',
        type: 'string',
        "default": 'clang-format'
      },
      "arguments": {
        title: 'Arguments passed to the formatter',
        type: 'array',
        "default": []
      }
    },
    provideFormatter: function() {
      return [
        {
          selector: '.source.c',
          getNewText: this.format
        }, {
          selector: '.source.cpp',
          getNewText: this.format
        }, {
          selector: '.source.objc',
          getNewText: this.format
        }
      ];
    },
    format: function(text) {
      var child_process;
      child_process = require('child_process');
      return new Promise(function(resolve, reject) {
        var args, command, process, toReturn;
        command = atom.config.get('formatter-clang-format.executablePath');
        args = atom.config.get('formatter-clang-format.arguments');
        toReturn = [];
        process = child_process.spawn(command, args, {});
        process.stdout.on('data', function(data) {
          return toReturn.push(data);
        });
        process.stdin.write(text);
        process.stdin.end();
        return process.on('close', function() {
          return resolve(toReturn.join('\n'));
        });
      });
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvc2hhbmUvLmF0b20vcGFja2FnZXMvZm9ybWF0dGVyLWNsYW5nLWZvcm1hdC9saWIvbWFpbi5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLE1BQUEsY0FBQTs7QUFBQSxFQUFBLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLGNBQUEsR0FDZjtBQUFBLElBQUEsTUFBQSxFQUNFO0FBQUEsTUFBQSxjQUFBLEVBQ0U7QUFBQSxRQUFBLEtBQUEsRUFBTyx3QkFBUDtBQUFBLFFBQ0EsSUFBQSxFQUFNLFFBRE47QUFBQSxRQUVBLFNBQUEsRUFBUyxjQUZUO09BREY7QUFBQSxNQUlBLFdBQUEsRUFDRTtBQUFBLFFBQUEsS0FBQSxFQUFPLG1DQUFQO0FBQUEsUUFDQSxJQUFBLEVBQU0sT0FETjtBQUFBLFFBRUEsU0FBQSxFQUFTLEVBRlQ7T0FMRjtLQURGO0FBQUEsSUFVQSxnQkFBQSxFQUFrQixTQUFBLEdBQUE7YUFDaEI7UUFDRTtBQUFBLFVBQ0UsUUFBQSxFQUFVLFdBRFo7QUFBQSxVQUVFLFVBQUEsRUFBWSxJQUFDLENBQUEsTUFGZjtTQURGLEVBS0U7QUFBQSxVQUNFLFFBQUEsRUFBVSxhQURaO0FBQUEsVUFFRSxVQUFBLEVBQVksSUFBQyxDQUFBLE1BRmY7U0FMRixFQVNFO0FBQUEsVUFDRSxRQUFBLEVBQVUsY0FEWjtBQUFBLFVBRUUsVUFBQSxFQUFZLElBQUMsQ0FBQSxNQUZmO1NBVEY7UUFEZ0I7SUFBQSxDQVZsQjtBQUFBLElBMEJBLE1BQUEsRUFBUSxTQUFDLElBQUQsR0FBQTtBQUNOLFVBQUEsYUFBQTtBQUFBLE1BQUEsYUFBQSxHQUFnQixPQUFBLENBQVEsZUFBUixDQUFoQixDQUFBO0FBQ0EsYUFBVyxJQUFBLE9BQUEsQ0FBUSxTQUFDLE9BQUQsRUFBVSxNQUFWLEdBQUE7QUFDakIsWUFBQSxnQ0FBQTtBQUFBLFFBQUEsT0FBQSxHQUFVLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQix1Q0FBaEIsQ0FBVixDQUFBO0FBQUEsUUFDQSxJQUFBLEdBQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLGtDQUFoQixDQURQLENBQUE7QUFBQSxRQUVBLFFBQUEsR0FBVyxFQUZYLENBQUE7QUFBQSxRQUdBLE9BQUEsR0FBVSxhQUFhLENBQUMsS0FBZCxDQUFvQixPQUFwQixFQUE2QixJQUE3QixFQUFtQyxFQUFuQyxDQUhWLENBQUE7QUFBQSxRQUlBLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBZixDQUFrQixNQUFsQixFQUEwQixTQUFDLElBQUQsR0FBQTtpQkFBVSxRQUFRLENBQUMsSUFBVCxDQUFjLElBQWQsRUFBVjtRQUFBLENBQTFCLENBSkEsQ0FBQTtBQUFBLFFBS0EsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFkLENBQW9CLElBQXBCLENBTEEsQ0FBQTtBQUFBLFFBTUEsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFkLENBQUEsQ0FOQSxDQUFBO2VBT0EsT0FBTyxDQUFDLEVBQVIsQ0FBVyxPQUFYLEVBQW9CLFNBQUEsR0FBQTtpQkFDbEIsT0FBQSxDQUFRLFFBQVEsQ0FBQyxJQUFULENBQWMsSUFBZCxDQUFSLEVBRGtCO1FBQUEsQ0FBcEIsRUFSaUI7TUFBQSxDQUFSLENBQVgsQ0FGTTtJQUFBLENBMUJSO0dBREYsQ0FBQTtBQUFBIgp9

//# sourceURL=/home/shane/.atom/packages/formatter-clang-format/lib/main.coffee
