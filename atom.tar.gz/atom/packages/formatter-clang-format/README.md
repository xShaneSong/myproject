# formatter-clang-format
An Atom Formatter provider built for ClangFormat.

## Installation
Before installing anything for Atom, install [clang-format](http://clang.llvm.org/docs/ClangFormat.html).

In your terminal:
```
apm install formatter
apm install formatter-clang-format
```

In Atom, install `formatter` and `formatter-clang-format` from your settings view.
