// This is a comment, this will not return any errors.
#import "nothing.h"

int main(int argc, char const *argv[]) {
  /* code */
  return 0;
}
