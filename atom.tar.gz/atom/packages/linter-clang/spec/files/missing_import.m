// This is a comment is will not return an error
#include "nothing.h"

int main(int argc, char const *argv[]) {
  /* code */
  return 0;
}
