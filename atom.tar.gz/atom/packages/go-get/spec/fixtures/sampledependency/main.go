package sampledependency

// Noop is a no-op.
func Noop() {
}
