
1.2.1 / 2015-12-17
==================

  * Fix append() snippet

1.2.0 / 2015-11-25
==================

  * Add selector param for .on(), .off(), and .one() snippets

1.1.1 / 2015-11-24
==================

  * Remove extra opening paren in data() snippet

1.1.0 / 2015-11-15
==================

  * Add missing methods: $.ajaxPrefilter, $.ajaxTransport, detach, empty, position
  * Add "hidden" snippets for $. methods when expanding after typing "$." Complements bare method name expansions introduced in gh-2.
  * Add $. to appropriate utility snippets. (thanks, @ezmionline)
