#!/usr/bin/env bash

$SHELL -lc 'echo $PATH'
