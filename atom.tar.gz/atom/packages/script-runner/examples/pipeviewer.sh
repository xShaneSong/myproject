#!/usr/bin/env bash

./logo.rb | pv
