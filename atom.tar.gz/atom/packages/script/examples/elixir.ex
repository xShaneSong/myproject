IO.inspect Enum.map([1,2,3], fn(x) -> x * 2 end)
